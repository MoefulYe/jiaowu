import{x as en,en as ln,y as fn,d as de,q as a,f as Ae,z as M,A as $,B as Y,m as hn,K as se,i as nn,eo as Kn,v as k,av as ie,L as De,as as vn,ak as on,bc as Un,an as qe,dh as Ce,T as gn,C as q,a2 as Ye,aD as pn,F as H,r as P,ep as qn,I as ye,J as bn,aA as Gn,bK as Ge,p as rn,aq as Zn,eq as Jn,bk as Qn,bE as Yn,ar as Xn,br as Ee,aB as we,G as eo,er as no,es as an,Z as oo,E as sn,et as to,dk as io,am as lo,aE as ro,bm as ao,bn as so,bo as co,P as uo,Q as fo,bp as dn,S as ho,bq as vo,au as X}from"./index-3ae6663b.js";import{u as mn,a as go}from"./Suffix-a593eadd.js";import{p as po,N as bo}from"./Popover-3489f9b4.js";import{N as Ze}from"./Tag-13793c77.js";import{F as mo}from"./FocusDetector-3d1dedc7.js";import{i as tn,a as xo,u as Xe}from"./get-4c618113.js";function wo(e){switch(typeof e){case"string":return e||void 0;case"number":return String(e);default:return}}function Je(e){const o=e.filter(t=>t!==void 0);if(o.length!==0)return o.length===1?o[0]:t=>{e.forEach(d=>{d&&d(t)})}}function xn(e,o){o&&(en(()=>{const{value:t}=e;t&&ln.registerHandler(t,o)}),fn(()=>{const{value:t}=e;t&&ln.unregisterHandler(t)}))}const Co=de({name:"Checkmark",render(){return a("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},a("g",{fill:"none"},a("path",{d:"M14.046 3.486a.75.75 0 0 1-.032 1.06l-7.93 7.474a.85.85 0 0 1-1.188-.022l-2.68-2.72a.75.75 0 1 1 1.068-1.053l2.234 2.267l7.468-7.038a.75.75 0 0 1 1.06.032z",fill:"currentColor"})))}}),yo=de({name:"Empty",render(){return a("svg",{viewBox:"0 0 28 28",fill:"none",xmlns:"http://www.w3.org/2000/svg"},a("path",{d:"M26 7.5C26 11.0899 23.0899 14 19.5 14C15.9101 14 13 11.0899 13 7.5C13 3.91015 15.9101 1 19.5 1C23.0899 1 26 3.91015 26 7.5ZM16.8536 4.14645C16.6583 3.95118 16.3417 3.95118 16.1464 4.14645C15.9512 4.34171 15.9512 4.65829 16.1464 4.85355L18.7929 7.5L16.1464 10.1464C15.9512 10.3417 15.9512 10.6583 16.1464 10.8536C16.3417 11.0488 16.6583 11.0488 16.8536 10.8536L19.5 8.20711L22.1464 10.8536C22.3417 11.0488 22.6583 11.0488 22.8536 10.8536C23.0488 10.6583 23.0488 10.3417 22.8536 10.1464L20.2071 7.5L22.8536 4.85355C23.0488 4.65829 23.0488 4.34171 22.8536 4.14645C22.6583 3.95118 22.3417 3.95118 22.1464 4.14645L19.5 6.79289L16.8536 4.14645Z",fill:"currentColor"}),a("path",{d:"M25 22.75V12.5991C24.5572 13.0765 24.053 13.4961 23.5 13.8454V16H17.5L17.3982 16.0068C17.0322 16.0565 16.75 16.3703 16.75 16.75C16.75 18.2688 15.5188 19.5 14 19.5C12.4812 19.5 11.25 18.2688 11.25 16.75L11.2432 16.6482C11.1935 16.2822 10.8797 16 10.5 16H4.5V7.25C4.5 6.2835 5.2835 5.5 6.25 5.5H12.2696C12.4146 4.97463 12.6153 4.47237 12.865 4H6.25C4.45507 4 3 5.45507 3 7.25V22.75C3 24.5449 4.45507 26 6.25 26H21.75C23.5449 26 25 24.5449 25 22.75ZM4.5 22.75V17.5H9.81597L9.85751 17.7041C10.2905 19.5919 11.9808 21 14 21L14.215 20.9947C16.2095 20.8953 17.842 19.4209 18.184 17.5H23.5V22.75C23.5 23.7165 22.7165 24.5 21.75 24.5H6.25C5.2835 24.5 4.5 23.7165 4.5 22.75Z",fill:"currentColor"}))}}),So={iconSizeSmall:"34px",iconSizeMedium:"40px",iconSizeLarge:"46px",iconSizeHuge:"52px"},Fo=e=>{const{textColorDisabled:o,iconColor:t,textColor2:d,fontSizeSmall:u,fontSizeMedium:g,fontSizeLarge:h,fontSizeHuge:r}=e;return Object.assign(Object.assign({},So),{fontSizeSmall:u,fontSizeMedium:g,fontSizeLarge:h,fontSizeHuge:r,textColor:o,iconColor:t,extraTextColor:d})},Oo={name:"Empty",common:Ae,self:Fo},wn=Oo,Ro=M("empty",`
 display: flex;
 flex-direction: column;
 align-items: center;
 font-size: var(--n-font-size);
`,[$("icon",`
 width: var(--n-icon-size);
 height: var(--n-icon-size);
 font-size: var(--n-icon-size);
 line-height: var(--n-icon-size);
 color: var(--n-icon-color);
 transition:
 color .3s var(--n-bezier);
 `,[Y("+",[$("description",`
 margin-top: 8px;
 `)])]),$("description",`
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
 `),$("extra",`
 text-align: center;
 transition: color .3s var(--n-bezier);
 margin-top: 12px;
 color: var(--n-extra-text-color);
 `)]),zo=Object.assign(Object.assign({},se.props),{description:String,showDescription:{type:Boolean,default:!0},showIcon:{type:Boolean,default:!0},size:{type:String,default:"medium"},renderIcon:Function}),Mo=de({name:"Empty",props:zo,setup(e){const{mergedClsPrefixRef:o,inlineThemeDisabled:t}=hn(e),d=se("Empty","-empty",Ro,wn,e,o),{localeRef:u}=mn("Empty"),g=nn(Kn,null),h=k(()=>{var v,m,R;return(v=e.description)!==null&&v!==void 0?v:(R=(m=g==null?void 0:g.mergedComponentPropsRef.value)===null||m===void 0?void 0:m.Empty)===null||R===void 0?void 0:R.description}),r=k(()=>{var v,m;return((m=(v=g==null?void 0:g.mergedComponentPropsRef.value)===null||v===void 0?void 0:v.Empty)===null||m===void 0?void 0:m.renderIcon)||(()=>a(yo,null))}),w=k(()=>{const{size:v}=e,{common:{cubicBezierEaseInOut:m},self:{[ie("iconSize",v)]:R,[ie("fontSize",v)]:_,textColor:p,iconColor:T,extraTextColor:B}}=d.value;return{"--n-icon-size":R,"--n-font-size":_,"--n-bezier":m,"--n-text-color":p,"--n-icon-color":T,"--n-extra-text-color":B}}),C=t?De("empty",k(()=>{let v="";const{size:m}=e;return v+=m[0],v}),w,e):void 0;return{mergedClsPrefix:o,mergedRenderIcon:r,localizedDescription:k(()=>h.value||u.value.description),cssVars:t?void 0:w,themeClass:C==null?void 0:C.themeClass,onRender:C==null?void 0:C.onRender}},render(){const{$slots:e,mergedClsPrefix:o,onRender:t}=this;return t==null||t(),a("div",{class:[`${o}-empty`,this.themeClass],style:this.cssVars},this.showIcon?a("div",{class:`${o}-empty__icon`},e.icon?e.icon():a(vn,{clsPrefix:o},{default:this.mergedRenderIcon})):null,this.showDescription?a("div",{class:`${o}-empty__description`},e.default?e.default():this.localizedDescription):null,e.extra?a("div",{class:`${o}-empty__extra`},e.extra()):null)}}),To={height:"calc(var(--n-option-height) * 7.6)",paddingSmall:"4px 0",paddingMedium:"4px 0",paddingLarge:"4px 0",paddingHuge:"4px 0",optionPaddingSmall:"0 12px",optionPaddingMedium:"0 12px",optionPaddingLarge:"0 12px",optionPaddingHuge:"0 12px",loadingSize:"18px"},Po=e=>{const{borderRadius:o,popoverColor:t,textColor3:d,dividerColor:u,textColor2:g,primaryColorPressed:h,textColorDisabled:r,primaryColor:w,opacityDisabled:C,hoverColor:v,fontSizeSmall:m,fontSizeMedium:R,fontSizeLarge:_,fontSizeHuge:p,heightSmall:T,heightMedium:B,heightLarge:x,heightHuge:F}=e;return Object.assign(Object.assign({},To),{optionFontSizeSmall:m,optionFontSizeMedium:R,optionFontSizeLarge:_,optionFontSizeHuge:p,optionHeightSmall:T,optionHeightMedium:B,optionHeightLarge:x,optionHeightHuge:F,borderRadius:o,color:t,groupHeaderTextColor:d,actionDividerColor:u,optionTextColor:g,optionTextColorPressed:h,optionTextColorDisabled:r,optionTextColorActive:w,optionOpacityDisabled:C,optionCheckColor:w,optionColorPending:v,optionColorActive:"rgba(0, 0, 0, 0)",optionColorActivePending:v,actionTextColor:g,loadingColor:w})},ko=on({name:"InternalSelectMenu",common:Ae,peers:{Scrollbar:Un,Empty:wn},self:Po}),Cn=ko;function $o(e,o){return a(gn,{name:"fade-in-scale-up-transition"},{default:()=>e?a(vn,{clsPrefix:o,class:`${o}-base-select-option__check`},{default:()=>a(Co)}):null})}const cn=de({name:"NBaseSelectOption",props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0}},setup(e){const{valueRef:o,pendingTmNodeRef:t,multipleRef:d,valueSetRef:u,renderLabelRef:g,renderOptionRef:h,labelFieldRef:r,valueFieldRef:w,showCheckmarkRef:C,nodePropsRef:v,handleOptionClick:m,handleOptionMouseEnter:R}=nn(tn),_=qe(()=>{const{value:x}=t;return x?e.tmNode.key===x.key:!1});function p(x){const{tmNode:F}=e;F.disabled||m(x,F)}function T(x){const{tmNode:F}=e;F.disabled||R(x,F)}function B(x){const{tmNode:F}=e,{value:N}=_;F.disabled||N||R(x,F)}return{multiple:d,isGrouped:qe(()=>{const{tmNode:x}=e,{parent:F}=x;return F&&F.rawNode.type==="group"}),showCheckmark:C,nodeProps:v,isPending:_,isSelected:qe(()=>{const{value:x}=o,{value:F}=d;if(x===null)return!1;const N=e.tmNode.rawNode[w.value];if(F){const{value:j}=u;return j.has(N)}else return x===N}),labelField:r,renderLabel:g,renderOption:h,handleMouseMove:B,handleMouseEnter:T,handleClick:p}},render(){const{clsPrefix:e,tmNode:{rawNode:o},isSelected:t,isPending:d,isGrouped:u,showCheckmark:g,nodeProps:h,renderOption:r,renderLabel:w,handleClick:C,handleMouseEnter:v,handleMouseMove:m}=this,R=$o(t,e),_=w?[w(o,t),g&&R]:[Ce(o[this.labelField],o,t),g&&R],p=h==null?void 0:h(o),T=a("div",Object.assign({},p,{class:[`${e}-base-select-option`,o.class,p==null?void 0:p.class,{[`${e}-base-select-option--disabled`]:o.disabled,[`${e}-base-select-option--selected`]:t,[`${e}-base-select-option--grouped`]:u,[`${e}-base-select-option--pending`]:d,[`${e}-base-select-option--show-checkmark`]:g}],style:[(p==null?void 0:p.style)||"",o.style||""],onClick:Je([C,p==null?void 0:p.onClick]),onMouseenter:Je([v,p==null?void 0:p.onMouseenter]),onMousemove:Je([m,p==null?void 0:p.onMousemove])}),a("div",{class:`${e}-base-select-option__content`},_));return o.render?o.render({node:T,option:o,selected:t}):r?r({node:T,option:o,selected:t}):T}}),un=de({name:"NBaseSelectGroupHeader",props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0}},setup(){const{renderLabelRef:e,renderOptionRef:o,labelFieldRef:t,nodePropsRef:d}=nn(tn);return{labelField:t,nodeProps:d,renderLabel:e,renderOption:o}},render(){const{clsPrefix:e,renderLabel:o,renderOption:t,nodeProps:d,tmNode:{rawNode:u}}=this,g=d==null?void 0:d(u),h=o?o(u,!1):Ce(u[this.labelField],u,!1),r=a("div",Object.assign({},g,{class:[`${e}-base-select-group-header`,g==null?void 0:g.class]}),h);return u.render?u.render({node:r,option:u}):t?t({node:r,option:u,selected:!1}):r}}),_o=M("base-select-menu",`
 line-height: 1.5;
 outline: none;
 z-index: 0;
 position: relative;
 border-radius: var(--n-border-radius);
 transition:
 background-color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
 background-color: var(--n-color);
`,[M("scrollbar",`
 max-height: var(--n-height);
 `),M("virtual-list",`
 max-height: var(--n-height);
 `),M("base-select-option",`
 min-height: var(--n-option-height);
 font-size: var(--n-option-font-size);
 display: flex;
 align-items: center;
 `,[$("content",`
 z-index: 1;
 white-space: nowrap;
 text-overflow: ellipsis;
 overflow: hidden;
 `)]),M("base-select-group-header",`
 min-height: var(--n-option-height);
 font-size: .93em;
 display: flex;
 align-items: center;
 `),M("base-select-menu-option-wrapper",`
 position: relative;
 width: 100%;
 `),$("loading, empty",`
 display: flex;
 padding: 12px 32px;
 flex: 1;
 justify-content: center;
 `),$("loading",`
 color: var(--n-loading-color);
 font-size: var(--n-loading-size);
 `),$("action",`
 padding: 8px var(--n-option-padding-left);
 font-size: var(--n-option-font-size);
 transition: 
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 border-top: 1px solid var(--n-action-divider-color);
 color: var(--n-action-text-color);
 `),M("base-select-group-header",`
 position: relative;
 cursor: default;
 padding: var(--n-option-padding);
 color: var(--n-group-header-text-color);
 `),M("base-select-option",`
 cursor: pointer;
 position: relative;
 padding: var(--n-option-padding);
 transition:
 color .3s var(--n-bezier),
 opacity .3s var(--n-bezier);
 box-sizing: border-box;
 color: var(--n-option-text-color);
 opacity: 1;
 `,[q("show-checkmark",`
 padding-right: calc(var(--n-option-padding-right) + 20px);
 `),Y("&::before",`
 content: "";
 position: absolute;
 left: 4px;
 right: 4px;
 top: 0;
 bottom: 0;
 border-radius: var(--n-border-radius);
 transition: background-color .3s var(--n-bezier);
 `),Y("&:active",`
 color: var(--n-option-text-color-pressed);
 `),q("grouped",`
 padding-left: calc(var(--n-option-padding-left) * 1.5);
 `),q("pending",[Y("&::before",`
 background-color: var(--n-option-color-pending);
 `)]),q("selected",`
 color: var(--n-option-text-color-active);
 `,[Y("&::before",`
 background-color: var(--n-option-color-active);
 `),q("pending",[Y("&::before",`
 background-color: var(--n-option-color-active-pending);
 `)])]),q("disabled",`
 cursor: not-allowed;
 `,[Ye("selected",`
 color: var(--n-option-text-color-disabled);
 `),q("selected",`
 opacity: var(--n-option-opacity-disabled);
 `)]),$("check",`
 font-size: 16px;
 position: absolute;
 right: calc(var(--n-option-padding-right) - 4px);
 top: calc(50% - 7px);
 color: var(--n-option-check-color);
 transition: color .3s var(--n-bezier);
 `,[pn({enterScale:"0.5"})])])]),Io=de({name:"InternalSelectMenu",props:Object.assign(Object.assign({},se.props),{clsPrefix:{type:String,required:!0},scrollable:{type:Boolean,default:!0},treeMate:{type:Object,required:!0},multiple:Boolean,size:{type:String,default:"medium"},value:{type:[String,Number,Array],default:null},autoPending:Boolean,virtualScroll:{type:Boolean,default:!0},show:{type:Boolean,default:!0},labelField:{type:String,default:"label"},valueField:{type:String,default:"value"},loading:Boolean,focusable:Boolean,renderLabel:Function,renderOption:Function,nodeProps:Function,showCheckmark:{type:Boolean,default:!0},onMousedown:Function,onScroll:Function,onFocus:Function,onBlur:Function,onKeyup:Function,onKeydown:Function,onTabOut:Function,onMouseenter:Function,onMouseleave:Function,onResize:Function,resetMenuOnOptionsChange:{type:Boolean,default:!0},inlineThemeDisabled:Boolean,onToggle:Function}),setup(e){const o=se("InternalSelectMenu","-internal-select-menu",_o,Cn,e,H(e,"clsPrefix")),t=P(null),d=P(null),u=P(null),g=k(()=>e.treeMate.getFlattenedNodes()),h=k(()=>qn(g.value)),r=P(null);function w(){const{treeMate:l}=e;let c=null;const{value:E}=e;E===null?c=l.getFirstAvailableNode():(e.multiple?c=l.getNode((E||[])[(E||[]).length-1]):c=l.getNode(E),(!c||c.disabled)&&(c=l.getFirstAvailableNode())),K(c||null)}function C(){const{value:l}=r;l&&!e.treeMate.getNode(l.key)&&(r.value=null)}let v;ye(()=>e.show,l=>{l?v=ye(()=>e.treeMate,()=>{e.resetMenuOnOptionsChange?(e.autoPending?w():C(),bn(A)):C()},{immediate:!0}):v==null||v()},{immediate:!0}),fn(()=>{v==null||v()});const m=k(()=>Gn(o.value.self[ie("optionHeight",e.size)])),R=k(()=>Ge(o.value.self[ie("padding",e.size)])),_=k(()=>e.multiple&&Array.isArray(e.value)?new Set(e.value):new Set),p=k(()=>{const l=g.value;return l&&l.length===0});function T(l){const{onToggle:c}=e;c&&c(l)}function B(l){const{onScroll:c}=e;c&&c(l)}function x(l){var c;(c=u.value)===null||c===void 0||c.sync(),B(l)}function F(){var l;(l=u.value)===null||l===void 0||l.sync()}function N(){const{value:l}=r;return l||null}function j(l,c){c.disabled||K(c,!1)}function W(l,c){c.disabled||T(c)}function L(l){var c;Ee(l,"action")||(c=e.onKeyup)===null||c===void 0||c.call(e,l)}function V(l){var c;Ee(l,"action")||(c=e.onKeydown)===null||c===void 0||c.call(e,l)}function G(l){var c;(c=e.onMousedown)===null||c===void 0||c.call(e,l),!e.focusable&&l.preventDefault()}function ee(){const{value:l}=r;l&&K(l.getNext({loop:!0}),!0)}function Z(){const{value:l}=r;l&&K(l.getPrev({loop:!0}),!0)}function K(l,c=!1){r.value=l,c&&A()}function A(){var l,c;const E=r.value;if(!E)return;const oe=h.value(E.key);oe!==null&&(e.virtualScroll?(l=d.value)===null||l===void 0||l.scrollTo({index:oe}):(c=u.value)===null||c===void 0||c.scrollTo({index:oe,elSize:m.value}))}function ce(l){var c,E;!((c=t.value)===null||c===void 0)&&c.contains(l.target)&&((E=e.onFocus)===null||E===void 0||E.call(e,l))}function ve(l){var c,E;!((c=t.value)===null||c===void 0)&&c.contains(l.relatedTarget)||(E=e.onBlur)===null||E===void 0||E.call(e,l)}rn(tn,{handleOptionMouseEnter:j,handleOptionClick:W,valueSetRef:_,pendingTmNodeRef:r,nodePropsRef:H(e,"nodeProps"),showCheckmarkRef:H(e,"showCheckmark"),multipleRef:H(e,"multiple"),valueRef:H(e,"value"),renderLabelRef:H(e,"renderLabel"),renderOptionRef:H(e,"renderOption"),labelFieldRef:H(e,"labelField"),valueFieldRef:H(e,"valueField")}),rn(xo,t),en(()=>{const{value:l}=u;l&&l.sync()});const ue=k(()=>{const{size:l}=e,{common:{cubicBezierEaseInOut:c},self:{height:E,borderRadius:oe,color:Se,groupHeaderTextColor:Fe,actionDividerColor:Oe,optionTextColorPressed:ge,optionTextColor:pe,optionTextColorDisabled:te,optionTextColorActive:U,optionOpacityDisabled:be,optionCheckColor:re,actionTextColor:Re,optionColorPending:fe,optionColorActive:he,loadingColor:ze,loadingSize:Me,optionColorActivePending:Te,[ie("optionFontSize",l)]:me,[ie("optionHeight",l)]:xe,[ie("optionPadding",l)]:J}}=o.value;return{"--n-height":E,"--n-action-divider-color":Oe,"--n-action-text-color":Re,"--n-bezier":c,"--n-border-radius":oe,"--n-color":Se,"--n-option-font-size":me,"--n-group-header-text-color":Fe,"--n-option-check-color":re,"--n-option-color-pending":fe,"--n-option-color-active":he,"--n-option-color-active-pending":Te,"--n-option-height":xe,"--n-option-opacity-disabled":be,"--n-option-text-color":pe,"--n-option-text-color-active":U,"--n-option-text-color-disabled":te,"--n-option-text-color-pressed":ge,"--n-option-padding":J,"--n-option-padding-left":Ge(J,"left"),"--n-option-padding-right":Ge(J,"right"),"--n-loading-color":ze,"--n-loading-size":Me}}),{inlineThemeDisabled:ne}=e,Q=ne?De("internal-select-menu",k(()=>e.size[0]),ue,e):void 0,le={selfRef:t,next:ee,prev:Z,getPendingTmNode:N};return xn(t,e.onResize),Object.assign({mergedTheme:o,virtualListRef:d,scrollbarRef:u,itemSize:m,padding:R,flattenedNodes:g,empty:p,virtualListContainer(){const{value:l}=d;return l==null?void 0:l.listElRef},virtualListContent(){const{value:l}=d;return l==null?void 0:l.itemsElRef},doScroll:B,handleFocusin:ce,handleFocusout:ve,handleKeyUp:L,handleKeyDown:V,handleMouseDown:G,handleVirtualListResize:F,handleVirtualListScroll:x,cssVars:ne?void 0:ue,themeClass:Q==null?void 0:Q.themeClass,onRender:Q==null?void 0:Q.onRender},le)},render(){const{$slots:e,virtualScroll:o,clsPrefix:t,mergedTheme:d,themeClass:u,onRender:g}=this;return g==null||g(),a("div",{ref:"selfRef",tabindex:this.focusable?0:-1,class:[`${t}-base-select-menu`,u,this.multiple&&`${t}-base-select-menu--multiple`],style:this.cssVars,onFocusin:this.handleFocusin,onFocusout:this.handleFocusout,onKeyup:this.handleKeyUp,onKeydown:this.handleKeyDown,onMousedown:this.handleMouseDown,onMouseenter:this.onMouseenter,onMouseleave:this.onMouseleave},this.loading?a("div",{class:`${t}-base-select-menu__loading`},a(Jn,{clsPrefix:t,strokeWidth:20})):this.empty?a("div",{class:`${t}-base-select-menu__empty`,"data-empty":!0},Xn(e.empty,()=>[a(Mo,{theme:d.peers.Empty,themeOverrides:d.peerOverrides.Empty})])):a(Qn,{ref:"scrollbarRef",theme:d.peers.Scrollbar,themeOverrides:d.peerOverrides.Scrollbar,scrollable:this.scrollable,container:o?this.virtualListContainer:void 0,content:o?this.virtualListContent:void 0,onScroll:o?void 0:this.doScroll},{default:()=>o?a(Yn,{ref:"virtualListRef",class:`${t}-virtual-list`,items:this.flattenedNodes,itemSize:this.itemSize,showScrollbar:!1,paddingTop:this.padding.top,paddingBottom:this.padding.bottom,onResize:this.handleVirtualListResize,onScroll:this.handleVirtualListScroll,itemResizable:!0},{default:({item:h})=>h.isGroup?a(un,{key:h.key,clsPrefix:t,tmNode:h}):h.ignored?null:a(cn,{clsPrefix:t,key:h.key,tmNode:h})}):a("div",{class:`${t}-base-select-menu-option-wrapper`,style:{paddingTop:this.padding.top,paddingBottom:this.padding.bottom}},this.flattenedNodes.map(h=>h.isGroup?a(un,{key:h.key,clsPrefix:t,tmNode:h}):a(cn,{clsPrefix:t,key:h.key,tmNode:h})))}),Zn(e.action,h=>h&&[a("div",{class:`${t}-base-select-menu__action`,"data-action":!0,key:"action"},h),a(mo,{onFocus:this.onTabOut,key:"focus-detector"})]))}}),Bo={paddingSingle:"0 26px 0 12px",paddingMultiple:"3px 26px 0 12px",clearSize:"16px",arrowSize:"16px"},Eo=e=>{const{borderRadius:o,textColor2:t,textColorDisabled:d,inputColor:u,inputColorDisabled:g,primaryColor:h,primaryColorHover:r,warningColor:w,warningColorHover:C,errorColor:v,errorColorHover:m,borderColor:R,iconColor:_,iconColorDisabled:p,clearColor:T,clearColorHover:B,clearColorPressed:x,placeholderColor:F,placeholderColorDisabled:N,fontSizeTiny:j,fontSizeSmall:W,fontSizeMedium:L,fontSizeLarge:V,heightTiny:G,heightSmall:ee,heightMedium:Z,heightLarge:K}=e;return Object.assign(Object.assign({},Bo),{fontSizeTiny:j,fontSizeSmall:W,fontSizeMedium:L,fontSizeLarge:V,heightTiny:G,heightSmall:ee,heightMedium:Z,heightLarge:K,borderRadius:o,textColor:t,textColorDisabled:d,placeholderColor:F,placeholderColorDisabled:N,color:u,colorDisabled:g,colorActive:u,border:`1px solid ${R}`,borderHover:`1px solid ${r}`,borderActive:`1px solid ${h}`,borderFocus:`1px solid ${r}`,boxShadowHover:"none",boxShadowActive:`0 0 0 2px ${we(h,{alpha:.2})}`,boxShadowFocus:`0 0 0 2px ${we(h,{alpha:.2})}`,caretColor:h,arrowColor:_,arrowColorDisabled:p,loadingColor:h,borderWarning:`1px solid ${w}`,borderHoverWarning:`1px solid ${C}`,borderActiveWarning:`1px solid ${w}`,borderFocusWarning:`1px solid ${C}`,boxShadowHoverWarning:"none",boxShadowActiveWarning:`0 0 0 2px ${we(w,{alpha:.2})}`,boxShadowFocusWarning:`0 0 0 2px ${we(w,{alpha:.2})}`,colorActiveWarning:u,caretColorWarning:w,borderError:`1px solid ${v}`,borderHoverError:`1px solid ${m}`,borderActiveError:`1px solid ${v}`,borderFocusError:`1px solid ${m}`,boxShadowHoverError:"none",boxShadowActiveError:`0 0 0 2px ${we(v,{alpha:.2})}`,boxShadowFocusError:`0 0 0 2px ${we(v,{alpha:.2})}`,colorActiveError:u,caretColorError:v,clearColor:T,clearColorHover:B,clearColorPressed:x})},Lo=on({name:"InternalSelection",common:Ae,peers:{Popover:po},self:Eo}),yn=Lo,Ao=Y([M("base-selection",`
 position: relative;
 z-index: auto;
 box-shadow: none;
 width: 100%;
 max-width: 100%;
 display: inline-block;
 vertical-align: bottom;
 border-radius: var(--n-border-radius);
 min-height: var(--n-height);
 line-height: 1.5;
 font-size: var(--n-font-size);
 `,[M("base-loading",`
 color: var(--n-loading-color);
 `),M("base-selection-tags","min-height: var(--n-height);"),$("border, state-border",`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 pointer-events: none;
 border: var(--n-border);
 border-radius: inherit;
 transition:
 box-shadow .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `),$("state-border",`
 z-index: 1;
 border-color: #0000;
 `),M("base-suffix",`
 cursor: pointer;
 position: absolute;
 top: 50%;
 transform: translateY(-50%);
 right: 10px;
 `,[$("arrow",`
 font-size: var(--n-arrow-size);
 color: var(--n-arrow-color);
 transition: color .3s var(--n-bezier);
 `)]),M("base-selection-overlay",`
 display: flex;
 align-items: center;
 white-space: nowrap;
 pointer-events: none;
 position: absolute;
 top: 0;
 right: 0;
 bottom: 0;
 left: 0;
 padding: var(--n-padding-single);
 transition: color .3s var(--n-bezier);
 `,[$("wrapper",`
 flex-basis: 0;
 flex-grow: 1;
 overflow: hidden;
 text-overflow: ellipsis;
 `)]),M("base-selection-placeholder",`
 color: var(--n-placeholder-color);
 `,[$("inner",`
 max-width: 100%;
 overflow: hidden;
 `)]),M("base-selection-tags",`
 cursor: pointer;
 outline: none;
 box-sizing: border-box;
 position: relative;
 z-index: auto;
 display: flex;
 padding: var(--n-padding-multiple);
 flex-wrap: wrap;
 align-items: center;
 width: 100%;
 vertical-align: bottom;
 background-color: var(--n-color);
 border-radius: inherit;
 transition:
 color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `),M("base-selection-label",`
 height: var(--n-height);
 display: inline-flex;
 width: 100%;
 vertical-align: bottom;
 cursor: pointer;
 outline: none;
 z-index: auto;
 box-sizing: border-box;
 position: relative;
 transition:
 color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 border-radius: inherit;
 background-color: var(--n-color);
 align-items: center;
 `,[M("base-selection-input",`
 font-size: inherit;
 line-height: inherit;
 outline: none;
 cursor: pointer;
 box-sizing: border-box;
 border:none;
 width: 100%;
 padding: var(--n-padding-single);
 background-color: #0000;
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 caret-color: var(--n-caret-color);
 `,[$("content",`
 text-overflow: ellipsis;
 overflow: hidden;
 white-space: nowrap; 
 `)]),$("render-label",`
 color: var(--n-text-color);
 `)]),Ye("disabled",[Y("&:hover",[$("state-border",`
 box-shadow: var(--n-box-shadow-hover);
 border: var(--n-border-hover);
 `)]),q("focus",[$("state-border",`
 box-shadow: var(--n-box-shadow-focus);
 border: var(--n-border-focus);
 `)]),q("active",[$("state-border",`
 box-shadow: var(--n-box-shadow-active);
 border: var(--n-border-active);
 `),M("base-selection-label","background-color: var(--n-color-active);"),M("base-selection-tags","background-color: var(--n-color-active);")])]),q("disabled","cursor: not-allowed;",[$("arrow",`
 color: var(--n-arrow-color-disabled);
 `),M("base-selection-label",`
 cursor: not-allowed;
 background-color: var(--n-color-disabled);
 `,[M("base-selection-input",`
 cursor: not-allowed;
 color: var(--n-text-color-disabled);
 `),$("render-label",`
 color: var(--n-text-color-disabled);
 `)]),M("base-selection-tags",`
 cursor: not-allowed;
 background-color: var(--n-color-disabled);
 `),M("base-selection-placeholder",`
 cursor: not-allowed;
 color: var(--n-placeholder-color-disabled);
 `)]),M("base-selection-input-tag",`
 height: calc(var(--n-height) - 6px);
 line-height: calc(var(--n-height) - 6px);
 outline: none;
 display: none;
 position: relative;
 margin-bottom: 3px;
 max-width: 100%;
 vertical-align: bottom;
 `,[$("input",`
 font-size: inherit;
 font-family: inherit;
 min-width: 1px;
 padding: 0;
 background-color: #0000;
 outline: none;
 border: none;
 max-width: 100%;
 overflow: hidden;
 width: 1em;
 line-height: inherit;
 cursor: pointer;
 color: var(--n-text-color);
 caret-color: var(--n-caret-color);
 `),$("mirror",`
 position: absolute;
 left: 0;
 top: 0;
 white-space: pre;
 visibility: hidden;
 user-select: none;
 -webkit-user-select: none;
 opacity: 0;
 `)]),["warning","error"].map(e=>q(`${e}-status`,[$("state-border",`border: var(--n-border-${e});`),Ye("disabled",[Y("&:hover",[$("state-border",`
 box-shadow: var(--n-box-shadow-hover-${e});
 border: var(--n-border-hover-${e});
 `)]),q("active",[$("state-border",`
 box-shadow: var(--n-box-shadow-active-${e});
 border: var(--n-border-active-${e});
 `),M("base-selection-label",`background-color: var(--n-color-active-${e});`),M("base-selection-tags",`background-color: var(--n-color-active-${e});`)]),q("focus",[$("state-border",`
 box-shadow: var(--n-box-shadow-focus-${e});
 border: var(--n-border-focus-${e});
 `)])])]))]),M("base-selection-popover",`
 margin-bottom: -3px;
 display: flex;
 flex-wrap: wrap;
 margin-right: -8px;
 `),M("base-selection-tag-wrapper",`
 max-width: 100%;
 display: inline-flex;
 padding: 0 7px 3px 0;
 `,[Y("&:last-child","padding-right: 0;"),M("tag",`
 font-size: 14px;
 max-width: 100%;
 `,[$("content",`
 line-height: 1.25;
 text-overflow: ellipsis;
 overflow: hidden;
 `)])])]),Do=de({name:"InternalSelection",props:Object.assign(Object.assign({},se.props),{clsPrefix:{type:String,required:!0},bordered:{type:Boolean,default:void 0},active:Boolean,pattern:{type:String,default:""},placeholder:String,selectedOption:{type:Object,default:null},selectedOptions:{type:Array,default:null},labelField:{type:String,default:"label"},valueField:{type:String,default:"value"},multiple:Boolean,filterable:Boolean,clearable:Boolean,disabled:Boolean,size:{type:String,default:"medium"},loading:Boolean,autofocus:Boolean,showArrow:{type:Boolean,default:!0},inputProps:Object,focused:Boolean,renderTag:Function,onKeydown:Function,onClick:Function,onBlur:Function,onFocus:Function,onDeleteOption:Function,maxTagCount:[String,Number],onClear:Function,onPatternInput:Function,onPatternFocus:Function,onPatternBlur:Function,renderLabel:Function,status:String,inlineThemeDisabled:Boolean,ignoreComposition:{type:Boolean,default:!0},onResize:Function}),setup(e){const o=P(null),t=P(null),d=P(null),u=P(null),g=P(null),h=P(null),r=P(null),w=P(null),C=P(null),v=P(null),m=P(!1),R=P(!1),_=P(!1),p=se("InternalSelection","-internal-selection",Ao,yn,e,H(e,"clsPrefix")),T=k(()=>e.clearable&&!e.disabled&&(_.value||e.active)),B=k(()=>e.selectedOption?e.renderTag?e.renderTag({option:e.selectedOption,handleClose:()=>{}}):e.renderLabel?e.renderLabel(e.selectedOption,!0):Ce(e.selectedOption[e.labelField],e.selectedOption,!0):e.placeholder),x=k(()=>{const i=e.selectedOption;if(i)return i[e.labelField]}),F=k(()=>e.multiple?!!(Array.isArray(e.selectedOptions)&&e.selectedOptions.length):e.selectedOption!==null);function N(){var i;const{value:f}=o;if(f){const{value:I}=t;I&&(I.style.width=`${f.offsetWidth}px`,e.maxTagCount!=="responsive"&&((i=C.value)===null||i===void 0||i.sync()))}}function j(){const{value:i}=v;i&&(i.style.display="none")}function W(){const{value:i}=v;i&&(i.style.display="inline-block")}ye(H(e,"active"),i=>{i||j()}),ye(H(e,"pattern"),()=>{e.multiple&&bn(N)});function L(i){const{onFocus:f}=e;f&&f(i)}function V(i){const{onBlur:f}=e;f&&f(i)}function G(i){const{onDeleteOption:f}=e;f&&f(i)}function ee(i){const{onClear:f}=e;f&&f(i)}function Z(i){const{onPatternInput:f}=e;f&&f(i)}function K(i){var f;(!i.relatedTarget||!(!((f=d.value)===null||f===void 0)&&f.contains(i.relatedTarget)))&&L(i)}function A(i){var f;!((f=d.value)===null||f===void 0)&&f.contains(i.relatedTarget)||V(i)}function ce(i){ee(i)}function ve(){_.value=!0}function ue(){_.value=!1}function ne(i){!e.active||!e.filterable||i.target!==t.value&&i.preventDefault()}function Q(i){G(i)}function le(i){if(i.key==="Backspace"&&!l.value&&!e.pattern.length){const{selectedOptions:f}=e;f!=null&&f.length&&Q(f[f.length-1])}}const l=P(!1);let c=null;function E(i){const{value:f}=o;if(f){const I=i.target.value;f.textContent=I,N()}e.ignoreComposition&&l.value?c=i:Z(i)}function oe(){l.value=!0}function Se(){l.value=!1,e.ignoreComposition&&Z(c),c=null}function Fe(i){var f;R.value=!0,(f=e.onPatternFocus)===null||f===void 0||f.call(e,i)}function Oe(i){var f;R.value=!1,(f=e.onPatternBlur)===null||f===void 0||f.call(e,i)}function ge(){var i,f;if(e.filterable)R.value=!1,(i=h.value)===null||i===void 0||i.blur(),(f=t.value)===null||f===void 0||f.blur();else if(e.multiple){const{value:I}=u;I==null||I.blur()}else{const{value:I}=g;I==null||I.blur()}}function pe(){var i,f,I;e.filterable?(R.value=!1,(i=h.value)===null||i===void 0||i.focus()):e.multiple?(f=u.value)===null||f===void 0||f.focus():(I=g.value)===null||I===void 0||I.focus()}function te(){const{value:i}=t;i&&(W(),i.focus())}function U(){const{value:i}=t;i&&i.blur()}function be(i){const{value:f}=r;f&&f.setTextContent(`+${i}`)}function re(){const{value:i}=w;return i}function Re(){return t.value}let fe=null;function he(){fe!==null&&window.clearTimeout(fe)}function ze(){e.disabled||e.active||(he(),fe=window.setTimeout(()=>{F.value&&(m.value=!0)},100))}function Me(){he()}function Te(i){i||(he(),m.value=!1)}ye(F,i=>{i||(m.value=!1)}),en(()=>{eo(()=>{const i=h.value;i&&(i.tabIndex=e.disabled||R.value?-1:0)})}),xn(d,e.onResize);const{inlineThemeDisabled:me}=e,xe=k(()=>{const{size:i}=e,{common:{cubicBezierEaseInOut:f},self:{borderRadius:I,color:Pe,placeholderColor:Ne,textColor:Ve,paddingSingle:He,paddingMultiple:je,caretColor:ke,colorDisabled:$e,textColorDisabled:_e,placeholderColorDisabled:We,colorActive:Ke,boxShadowFocus:Ie,boxShadowActive:ae,boxShadowHover:n,border:s,borderFocus:b,borderHover:z,borderActive:y,arrowColor:O,arrowColorDisabled:S,loadingColor:D,colorActiveWarning:Be,boxShadowFocusWarning:Ue,boxShadowActiveWarning:Fn,boxShadowHoverWarning:On,borderWarning:Rn,borderFocusWarning:zn,borderHoverWarning:Mn,borderActiveWarning:Tn,colorActiveError:Pn,boxShadowFocusError:kn,boxShadowActiveError:$n,boxShadowHoverError:_n,borderError:In,borderFocusError:Bn,borderHoverError:En,borderActiveError:Ln,clearColor:An,clearColorHover:Dn,clearColorPressed:Nn,clearSize:Vn,arrowSize:Hn,[ie("height",i)]:jn,[ie("fontSize",i)]:Wn}}=p.value;return{"--n-bezier":f,"--n-border":s,"--n-border-active":y,"--n-border-focus":b,"--n-border-hover":z,"--n-border-radius":I,"--n-box-shadow-active":ae,"--n-box-shadow-focus":Ie,"--n-box-shadow-hover":n,"--n-caret-color":ke,"--n-color":Pe,"--n-color-active":Ke,"--n-color-disabled":$e,"--n-font-size":Wn,"--n-height":jn,"--n-padding-single":He,"--n-padding-multiple":je,"--n-placeholder-color":Ne,"--n-placeholder-color-disabled":We,"--n-text-color":Ve,"--n-text-color-disabled":_e,"--n-arrow-color":O,"--n-arrow-color-disabled":S,"--n-loading-color":D,"--n-color-active-warning":Be,"--n-box-shadow-focus-warning":Ue,"--n-box-shadow-active-warning":Fn,"--n-box-shadow-hover-warning":On,"--n-border-warning":Rn,"--n-border-focus-warning":zn,"--n-border-hover-warning":Mn,"--n-border-active-warning":Tn,"--n-color-active-error":Pn,"--n-box-shadow-focus-error":kn,"--n-box-shadow-active-error":$n,"--n-box-shadow-hover-error":_n,"--n-border-error":In,"--n-border-focus-error":Bn,"--n-border-hover-error":En,"--n-border-active-error":Ln,"--n-clear-size":Vn,"--n-clear-color":An,"--n-clear-color-hover":Dn,"--n-clear-color-pressed":Nn,"--n-arrow-size":Hn}}),J=me?De("internal-selection",k(()=>e.size[0]),xe,e):void 0;return{mergedTheme:p,mergedClearable:T,patternInputFocused:R,filterablePlaceholder:B,label:x,selected:F,showTagsPanel:m,isComposing:l,counterRef:r,counterWrapperRef:w,patternInputMirrorRef:o,patternInputRef:t,selfRef:d,multipleElRef:u,singleElRef:g,patternInputWrapperRef:h,overflowRef:C,inputTagElRef:v,handleMouseDown:ne,handleFocusin:K,handleClear:ce,handleMouseEnter:ve,handleMouseLeave:ue,handleDeleteOption:Q,handlePatternKeyDown:le,handlePatternInputInput:E,handlePatternInputBlur:Oe,handlePatternInputFocus:Fe,handleMouseEnterCounter:ze,handleMouseLeaveCounter:Me,handleFocusout:A,handleCompositionEnd:Se,handleCompositionStart:oe,onPopoverUpdateShow:Te,focus:pe,focusInput:te,blur:ge,blurInput:U,updateCounter:be,getCounter:re,getTail:Re,renderLabel:e.renderLabel,cssVars:me?void 0:xe,themeClass:J==null?void 0:J.themeClass,onRender:J==null?void 0:J.onRender}},render(){const{status:e,multiple:o,size:t,disabled:d,filterable:u,maxTagCount:g,bordered:h,clsPrefix:r,onRender:w,renderTag:C,renderLabel:v}=this;w==null||w();const m=g==="responsive",R=typeof g=="number",_=m||R,p=a(no,null,{default:()=>a(go,{clsPrefix:r,loading:this.loading,showArrow:this.showArrow,showClear:this.mergedClearable&&this.selected,onClear:this.handleClear},{default:()=>{var B,x;return(x=(B=this.$slots).arrow)===null||x===void 0?void 0:x.call(B)}})});let T;if(o){const{labelField:B}=this,x=A=>a("div",{class:`${r}-base-selection-tag-wrapper`,key:A.value},C?C({option:A,handleClose:()=>{this.handleDeleteOption(A)}}):a(Ze,{size:t,closable:!A.disabled,disabled:d,onClose:()=>{this.handleDeleteOption(A)},internalCloseIsButtonTag:!1,internalCloseFocusable:!1},{default:()=>v?v(A,!0):Ce(A[B],A,!0)})),F=()=>(R?this.selectedOptions.slice(0,g):this.selectedOptions).map(x),N=u?a("div",{class:`${r}-base-selection-input-tag`,ref:"inputTagElRef",key:"__input-tag__"},a("input",Object.assign({},this.inputProps,{ref:"patternInputRef",tabindex:-1,disabled:d,value:this.pattern,autofocus:this.autofocus,class:`${r}-base-selection-input-tag__input`,onBlur:this.handlePatternInputBlur,onFocus:this.handlePatternInputFocus,onKeydown:this.handlePatternKeyDown,onInput:this.handlePatternInputInput,onCompositionstart:this.handleCompositionStart,onCompositionend:this.handleCompositionEnd})),a("span",{ref:"patternInputMirrorRef",class:`${r}-base-selection-input-tag__mirror`},this.pattern)):null,j=m?()=>a("div",{class:`${r}-base-selection-tag-wrapper`,ref:"counterWrapperRef"},a(Ze,{size:t,ref:"counterRef",onMouseenter:this.handleMouseEnterCounter,onMouseleave:this.handleMouseLeaveCounter,disabled:d})):void 0;let W;if(R){const A=this.selectedOptions.length-g;A>0&&(W=a("div",{class:`${r}-base-selection-tag-wrapper`,key:"__counter__"},a(Ze,{size:t,ref:"counterRef",onMouseenter:this.handleMouseEnterCounter,disabled:d},{default:()=>`+${A}`})))}const L=m?u?a(an,{ref:"overflowRef",updateCounter:this.updateCounter,getCounter:this.getCounter,getTail:this.getTail,style:{width:"100%",display:"flex",overflow:"hidden"}},{default:F,counter:j,tail:()=>N}):a(an,{ref:"overflowRef",updateCounter:this.updateCounter,getCounter:this.getCounter,style:{width:"100%",display:"flex",overflow:"hidden"}},{default:F,counter:j}):R?F().concat(W):F(),V=_?()=>a("div",{class:`${r}-base-selection-popover`},m?F():this.selectedOptions.map(x)):void 0,G=_?{show:this.showTagsPanel,trigger:"hover",overlap:!0,placement:"top",width:"trigger",onUpdateShow:this.onPopoverUpdateShow,theme:this.mergedTheme.peers.Popover,themeOverrides:this.mergedTheme.peerOverrides.Popover}:null,Z=(this.selected?!1:this.active?!this.pattern&&!this.isComposing:!0)?a("div",{class:`${r}-base-selection-placeholder ${r}-base-selection-overlay`},a("div",{class:`${r}-base-selection-placeholder__inner`},this.placeholder)):null,K=u?a("div",{ref:"patternInputWrapperRef",class:`${r}-base-selection-tags`},L,m?null:N,p):a("div",{ref:"multipleElRef",class:`${r}-base-selection-tags`,tabindex:d?void 0:0},L,p);T=a(oo,null,_?a(bo,Object.assign({},G,{scrollable:!0,style:"max-height: calc(var(--v-target-height) * 6.6);"}),{trigger:()=>K,default:V}):K,Z)}else if(u){const B=this.pattern||this.isComposing,x=this.active?!B:!this.selected,F=this.active?!1:this.selected;T=a("div",{ref:"patternInputWrapperRef",class:`${r}-base-selection-label`},a("input",Object.assign({},this.inputProps,{ref:"patternInputRef",class:`${r}-base-selection-input`,value:this.active?this.pattern:"",placeholder:"",readonly:d,disabled:d,tabindex:-1,autofocus:this.autofocus,onFocus:this.handlePatternInputFocus,onBlur:this.handlePatternInputBlur,onInput:this.handlePatternInputInput,onCompositionstart:this.handleCompositionStart,onCompositionend:this.handleCompositionEnd})),F?a("div",{class:`${r}-base-selection-label__render-label ${r}-base-selection-overlay`,key:"input"},a("div",{class:`${r}-base-selection-overlay__wrapper`},C?C({option:this.selectedOption,handleClose:()=>{}}):v?v(this.selectedOption,!0):Ce(this.label,this.selectedOption,!0))):null,x?a("div",{class:`${r}-base-selection-placeholder ${r}-base-selection-overlay`,key:"placeholder"},a("div",{class:`${r}-base-selection-overlay__wrapper`},this.filterablePlaceholder)):null,p)}else T=a("div",{ref:"singleElRef",class:`${r}-base-selection-label`,tabindex:this.disabled?void 0:0},this.label!==void 0?a("div",{class:`${r}-base-selection-input`,title:wo(this.label),key:"input"},a("div",{class:`${r}-base-selection-input__content`},C?C({option:this.selectedOption,handleClose:()=>{}}):v?v(this.selectedOption,!0):Ce(this.label,this.selectedOption,!0))):a("div",{class:`${r}-base-selection-placeholder ${r}-base-selection-overlay`,key:"placeholder"},a("div",{class:`${r}-base-selection-placeholder__inner`},this.placeholder)),p);return a("div",{ref:"selfRef",class:[`${r}-base-selection`,this.themeClass,e&&`${r}-base-selection--${e}-status`,{[`${r}-base-selection--active`]:this.active,[`${r}-base-selection--selected`]:this.selected||this.active&&this.pattern,[`${r}-base-selection--disabled`]:this.disabled,[`${r}-base-selection--multiple`]:this.multiple,[`${r}-base-selection--focus`]:this.focused}],style:this.cssVars,onClick:this.onClick,onMouseenter:this.handleMouseEnter,onMouseleave:this.handleMouseLeave,onKeydown:this.onKeydown,onFocusin:this.handleFocusin,onFocusout:this.handleFocusout,onMousedown:this.handleMouseDown},T,h?a("div",{class:`${r}-base-selection__border`}):null,h?a("div",{class:`${r}-base-selection__state-border`}):null)}});function Le(e){return e.type==="group"}function Sn(e){return e.type==="ignored"}function Qe(e,o){try{return!!(1+o.toString().toLowerCase().indexOf(e.trim().toLowerCase()))}catch{return!1}}function No(e,o){return{getIsGroup:Le,getIgnored:Sn,getKey(d){return Le(d)?d.name||d.key||"key-required":d[e]},getChildren(d){return d[o]}}}function Vo(e,o,t,d){if(!o)return e;function u(g){if(!Array.isArray(g))return[];const h=[];for(const r of g)if(Le(r)){const w=u(r[d]);w.length&&h.push(Object.assign({},r,{[d]:w}))}else{if(Sn(r))continue;o(t,r)&&h.push(r)}return h}return u(e)}function Ho(e,o,t){const d=new Map;return e.forEach(u=>{Le(u)?u[t].forEach(g=>{d.set(g[o],g)}):d.set(u[o],u)}),d}function jo(e){const{boxShadow2:o}=e;return{menuBoxShadow:o}}const Wo=on({name:"Select",common:Ae,peers:{InternalSelection:yn,InternalSelectMenu:Cn},self:jo}),Ko=Wo,Uo=Y([M("select",`
 z-index: auto;
 outline: none;
 width: 100%;
 position: relative;
 `),M("select-menu",`
 margin: 4px 0;
 box-shadow: var(--n-menu-box-shadow);
 `,[pn({originalTransition:"background-color .3s var(--n-bezier), box-shadow .3s var(--n-bezier)"})])]),qo=Object.assign(Object.assign({},se.props),{to:Xe.propTo,bordered:{type:Boolean,default:void 0},clearable:Boolean,clearFilterAfterSelect:{type:Boolean,default:!0},options:{type:Array,default:()=>[]},defaultValue:{type:[String,Number,Array],default:null},keyboard:{type:Boolean,default:!0},value:[String,Number,Array],placeholder:String,menuProps:Object,multiple:Boolean,size:String,filterable:Boolean,disabled:{type:Boolean,default:void 0},remote:Boolean,loading:Boolean,filter:Function,placement:{type:String,default:"bottom-start"},widthMode:{type:String,default:"trigger"},tag:Boolean,onCreate:Function,fallbackOption:{type:[Function,Boolean],default:void 0},show:{type:Boolean,default:void 0},showArrow:{type:Boolean,default:!0},maxTagCount:[Number,String],consistentMenuWidth:{type:Boolean,default:!0},virtualScroll:{type:Boolean,default:!0},labelField:{type:String,default:"label"},valueField:{type:String,default:"value"},childrenField:{type:String,default:"children"},renderLabel:Function,renderOption:Function,renderTag:Function,"onUpdate:value":[Function,Array],inputProps:Object,nodeProps:Function,ignoreComposition:{type:Boolean,default:!0},showOnFocus:Boolean,onUpdateValue:[Function,Array],onBlur:[Function,Array],onClear:[Function,Array],onFocus:[Function,Array],onScroll:[Function,Array],onSearch:[Function,Array],onUpdateShow:[Function,Array],"onUpdate:show":[Function,Array],displayDirective:{type:String,default:"show"},resetMenuOnOptionsChange:{type:Boolean,default:!0},status:String,showCheckmark:{type:Boolean,default:!0},onChange:[Function,Array],items:Array}),et=de({name:"Select",props:qo,setup(e){const{mergedClsPrefixRef:o,mergedBorderedRef:t,namespaceRef:d,inlineThemeDisabled:u}=hn(e),g=se("Select","-select",Uo,Ko,e,o),h=P(e.defaultValue),r=H(e,"value"),w=sn(r,h),C=P(!1),v=P(""),m=k(()=>{const{valueField:n,childrenField:s}=e,b=No(n,s);return to(A.value,b)}),R=k(()=>Ho(Z.value,e.valueField,e.childrenField)),_=P(!1),p=sn(H(e,"show"),_),T=P(null),B=P(null),x=P(null),{localeRef:F}=mn("Select"),N=k(()=>{var n;return(n=e.placeholder)!==null&&n!==void 0?n:F.value.placeholder}),j=io(e,["items","options"]),W=[],L=P([]),V=P([]),G=P(new Map),ee=k(()=>{const{fallbackOption:n}=e;if(n===void 0){const{labelField:s,valueField:b}=e;return z=>({[s]:String(z),[b]:z})}return n===!1?!1:s=>Object.assign(n(s),{value:s})}),Z=k(()=>V.value.concat(L.value).concat(j.value)),K=k(()=>{const{filter:n}=e;if(n)return n;const{labelField:s,valueField:b}=e;return(z,y)=>{if(!y)return!1;const O=y[s];if(typeof O=="string")return Qe(z,O);const S=y[b];return typeof S=="string"?Qe(z,S):typeof S=="number"?Qe(z,String(S)):!1}}),A=k(()=>{if(e.remote)return j.value;{const{value:n}=Z,{value:s}=v;return!s.length||!e.filterable?n:Vo(n,K.value,s,e.childrenField)}});function ce(n){const s=e.remote,{value:b}=G,{value:z}=R,{value:y}=ee,O=[];return n.forEach(S=>{if(z.has(S))O.push(z.get(S));else if(s&&b.has(S))O.push(b.get(S));else if(y){const D=y(S);D&&O.push(D)}}),O}const ve=k(()=>{if(e.multiple){const{value:n}=w;return Array.isArray(n)?ce(n):[]}return null}),ue=k(()=>{const{value:n}=w;return!e.multiple&&!Array.isArray(n)?n===null?null:ce([n])[0]||null:null}),ne=lo(e),{mergedSizeRef:Q,mergedDisabledRef:le,mergedStatusRef:l}=ne;function c(n,s){const{onChange:b,"onUpdate:value":z,onUpdateValue:y}=e,{nTriggerFormChange:O,nTriggerFormInput:S}=ne;b&&X(b,n,s),y&&X(y,n,s),z&&X(z,n,s),h.value=n,O(),S()}function E(n){const{onBlur:s}=e,{nTriggerFormBlur:b}=ne;s&&X(s,n),b()}function oe(){const{onClear:n}=e;n&&X(n)}function Se(n){const{onFocus:s,showOnFocus:b}=e,{nTriggerFormFocus:z}=ne;s&&X(s,n),z(),b&&te()}function Fe(n){const{onSearch:s}=e;s&&X(s,n)}function Oe(n){const{onScroll:s}=e;s&&X(s,n)}function ge(){var n;const{remote:s,multiple:b}=e;if(s){const{value:z}=G;if(b){const{valueField:y}=e;(n=ve.value)===null||n===void 0||n.forEach(O=>{z.set(O[y],O)})}else{const y=ue.value;y&&z.set(y[e.valueField],y)}}}function pe(n){const{onUpdateShow:s,"onUpdate:show":b}=e;s&&X(s,n),b&&X(b,n),_.value=n}function te(){le.value||(pe(!0),_.value=!0,e.filterable&&_e())}function U(){pe(!1)}function be(){v.value="",V.value=W}const re=P(!1);function Re(){e.filterable&&(re.value=!0)}function fe(){e.filterable&&(re.value=!1,p.value||be())}function he(){le.value||(p.value?e.filterable?_e():U():te())}function ze(n){var s,b;!((b=(s=x.value)===null||s===void 0?void 0:s.selfRef)===null||b===void 0)&&b.contains(n.relatedTarget)||(C.value=!1,E(n),U())}function Me(n){Se(n),C.value=!0}function Te(n){C.value=!0}function me(n){var s;!((s=T.value)===null||s===void 0)&&s.$el.contains(n.relatedTarget)||(C.value=!1,E(n),U())}function xe(){var n;(n=T.value)===null||n===void 0||n.focus(),U()}function J(n){var s;p.value&&(!((s=T.value)===null||s===void 0)&&s.$el.contains(ho(n))||U())}function i(n){if(!Array.isArray(n))return[];if(ee.value)return Array.from(n);{const{remote:s}=e,{value:b}=R;if(s){const{value:z}=G;return n.filter(y=>b.has(y)||z.has(y))}else return n.filter(z=>b.has(z))}}function f(n){I(n.rawNode)}function I(n){if(le.value)return;const{tag:s,remote:b,clearFilterAfterSelect:z,valueField:y}=e;if(s&&!b){const{value:O}=V,S=O[0]||null;if(S){const D=L.value;D.length?D.push(S):L.value=[S],V.value=W}}if(b&&G.value.set(n[y],n),e.multiple){const O=i(w.value),S=O.findIndex(D=>D===n[y]);if(~S){if(O.splice(S,1),s&&!b){const D=Pe(n[y]);~D&&(L.value.splice(D,1),z&&(v.value=""))}}else O.push(n[y]),z&&(v.value="");c(O,ce(O))}else{if(s&&!b){const O=Pe(n[y]);~O?L.value=[L.value[O]]:L.value=W}$e(),U(),c(n[y],n)}}function Pe(n){return L.value.findIndex(b=>b[e.valueField]===n)}function Ne(n){p.value||te();const{value:s}=n.target;v.value=s;const{tag:b,remote:z}=e;if(Fe(s),b&&!z){if(!s){V.value=W;return}const{onCreate:y}=e,O=y?y(s):{[e.labelField]:s,[e.valueField]:s},{valueField:S}=e;j.value.some(D=>D[S]===O[S])||L.value.some(D=>D[S]===O[S])?V.value=W:V.value=[O]}}function Ve(n){n.stopPropagation();const{multiple:s}=e;!s&&e.filterable&&U(),oe(),s?c([],[]):c(null,null)}function He(n){!Ee(n,"action")&&!Ee(n,"empty")&&n.preventDefault()}function je(n){Oe(n)}function ke(n){var s,b,z,y,O;if(!e.keyboard){n.preventDefault();return}switch(n.key){case" ":if(e.filterable)break;n.preventDefault();case"Enter":if(!(!((s=T.value)===null||s===void 0)&&s.isComposing)){if(p.value){const S=(b=x.value)===null||b===void 0?void 0:b.getPendingTmNode();S?f(S):e.filterable||(U(),$e())}else if(te(),e.tag&&re.value){const S=V.value[0];if(S){const D=S[e.valueField],{value:Be}=w;e.multiple&&Array.isArray(Be)&&Be.some(Ue=>Ue===D)||I(S)}}}n.preventDefault();break;case"ArrowUp":if(n.preventDefault(),e.loading)return;p.value&&((z=x.value)===null||z===void 0||z.prev());break;case"ArrowDown":if(n.preventDefault(),e.loading)return;p.value?(y=x.value)===null||y===void 0||y.next():te();break;case"Escape":p.value&&(vo(n),U()),(O=T.value)===null||O===void 0||O.focus();break}}function $e(){var n;(n=T.value)===null||n===void 0||n.focus()}function _e(){var n;(n=T.value)===null||n===void 0||n.focusInput()}function We(){var n;p.value&&((n=B.value)===null||n===void 0||n.syncPosition())}ge(),ye(H(e,"options"),ge);const Ke={focus:()=>{var n;(n=T.value)===null||n===void 0||n.focus()},blur:()=>{var n;(n=T.value)===null||n===void 0||n.blur()}},Ie=k(()=>{const{self:{menuBoxShadow:n}}=g.value;return{"--n-menu-box-shadow":n}}),ae=u?De("select",void 0,Ie,e):void 0;return Object.assign(Object.assign({},Ke),{mergedStatus:l,mergedClsPrefix:o,mergedBordered:t,namespace:d,treeMate:m,isMounted:ro(),triggerRef:T,menuRef:x,pattern:v,uncontrolledShow:_,mergedShow:p,adjustedTo:Xe(e),uncontrolledValue:h,mergedValue:w,followerRef:B,localizedPlaceholder:N,selectedOption:ue,selectedOptions:ve,mergedSize:Q,mergedDisabled:le,focused:C,activeWithoutMenuOpen:re,inlineThemeDisabled:u,onTriggerInputFocus:Re,onTriggerInputBlur:fe,handleTriggerOrMenuResize:We,handleMenuFocus:Te,handleMenuBlur:me,handleMenuTabOut:xe,handleTriggerClick:he,handleToggle:f,handleDeleteOption:I,handlePatternInput:Ne,handleClear:Ve,handleTriggerBlur:ze,handleTriggerFocus:Me,handleKeydown:ke,handleMenuAfterLeave:be,handleMenuClickOutside:J,handleMenuScroll:je,handleMenuKeydown:ke,handleMenuMousedown:He,mergedTheme:g,cssVars:u?void 0:Ie,themeClass:ae==null?void 0:ae.themeClass,onRender:ae==null?void 0:ae.onRender})},render(){return a("div",{class:`${this.mergedClsPrefix}-select`},a(ao,null,{default:()=>[a(so,null,{default:()=>a(Do,{ref:"triggerRef",inlineThemeDisabled:this.inlineThemeDisabled,status:this.mergedStatus,inputProps:this.inputProps,clsPrefix:this.mergedClsPrefix,showArrow:this.showArrow,maxTagCount:this.maxTagCount,bordered:this.mergedBordered,active:this.activeWithoutMenuOpen||this.mergedShow,pattern:this.pattern,placeholder:this.localizedPlaceholder,selectedOption:this.selectedOption,selectedOptions:this.selectedOptions,multiple:this.multiple,renderTag:this.renderTag,renderLabel:this.renderLabel,filterable:this.filterable,clearable:this.clearable,disabled:this.mergedDisabled,size:this.mergedSize,theme:this.mergedTheme.peers.InternalSelection,labelField:this.labelField,valueField:this.valueField,themeOverrides:this.mergedTheme.peerOverrides.InternalSelection,loading:this.loading,focused:this.focused,onClick:this.handleTriggerClick,onDeleteOption:this.handleDeleteOption,onPatternInput:this.handlePatternInput,onClear:this.handleClear,onBlur:this.handleTriggerBlur,onFocus:this.handleTriggerFocus,onKeydown:this.handleKeydown,onPatternBlur:this.onTriggerInputBlur,onPatternFocus:this.onTriggerInputFocus,onResize:this.handleTriggerOrMenuResize,ignoreComposition:this.ignoreComposition},{arrow:()=>{var e,o;return[(o=(e=this.$slots).arrow)===null||o===void 0?void 0:o.call(e)]}})}),a(co,{ref:"followerRef",show:this.mergedShow,to:this.adjustedTo,teleportDisabled:this.adjustedTo===Xe.tdkey,containerClass:this.namespace,width:this.consistentMenuWidth?"target":void 0,minWidth:"target",placement:this.placement},{default:()=>a(gn,{name:"fade-in-scale-up-transition",appear:this.isMounted,onAfterLeave:this.handleMenuAfterLeave},{default:()=>{var e,o,t;return this.mergedShow||this.displayDirective==="show"?((e=this.onRender)===null||e===void 0||e.call(this),uo(a(Io,Object.assign({},this.menuProps,{ref:"menuRef",onResize:this.handleTriggerOrMenuResize,inlineThemeDisabled:this.inlineThemeDisabled,virtualScroll:this.consistentMenuWidth&&this.virtualScroll,class:[`${this.mergedClsPrefix}-select-menu`,this.themeClass,(o=this.menuProps)===null||o===void 0?void 0:o.class],clsPrefix:this.mergedClsPrefix,focusable:!0,labelField:this.labelField,valueField:this.valueField,autoPending:!0,nodeProps:this.nodeProps,theme:this.mergedTheme.peers.InternalSelectMenu,themeOverrides:this.mergedTheme.peerOverrides.InternalSelectMenu,treeMate:this.treeMate,multiple:this.multiple,size:"medium",renderOption:this.renderOption,renderLabel:this.renderLabel,value:this.mergedValue,style:[(t=this.menuProps)===null||t===void 0?void 0:t.style,this.cssVars],onToggle:this.handleToggle,onScroll:this.handleMenuScroll,onFocus:this.handleMenuFocus,onBlur:this.handleMenuBlur,onKeydown:this.handleMenuKeydown,onTabOut:this.handleMenuTabOut,onMousedown:this.handleMenuMousedown,show:this.mergedShow,showCheckmark:this.showCheckmark,resetMenuOnOptionsChange:this.resetMenuOnOptionsChange}),{empty:()=>{var d,u;return[(u=(d=this.$slots).empty)===null||u===void 0?void 0:u.call(d)]},action:()=>{var d,u;return[(u=(d=this.$slots).action)===null||u===void 0?void 0:u.call(d)]}}),this.displayDirective==="show"?[[fo,this.mergedShow],[dn,this.handleMenuClickOutside,void 0,{capture:!0}]]:[[dn,this.handleMenuClickOutside,void 0,{capture:!0}]])):null}})})]}))}});export{et as N};
