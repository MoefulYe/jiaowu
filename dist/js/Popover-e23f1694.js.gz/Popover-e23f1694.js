import{aX as me,d as Ge,r as F,i as Ze,x as Ke,m as j,aH as Se,cz as er,C as rr,q as nr,z as tr,v as q,E as $e,p as Y,j as S,T as or,aG as ar,cA as ir,a7 as sr,B as Ue,J as lr,aD as ur,s as dr,a6 as Ae,cy as fr,e as cr,cB as vr,cC as hr,aF as gr,aE as pr}from"./index-73e16628.js";import{c as wr,t as ge,d as ke,g as br,e as yr,f as te,u as V,p as mr,h as Sr,j as $r}from"./fade-in-scale-up.cssr-78bea9d3.js";import{s as re,t as ne,v as Ar,w as Or,x as pe,y as _r,z as W,A as G,B as je,M as de,C as Tr,S as Oe,D as Pr,U as _e,E as Te,F as Q,G as xr,H as Pe,I as Cr,J as Er,K as Mr,L as Rr,N as Br,O as Ir,c as Dr,d as D,a as B,i as oe,b as ae,e as Z,P as Fr,u as Lr,f as we,g as zr,Q as xe,l as ie,n as X}from"./light-07aa199c.js";import{a as Nr}from"./Icon-9eb33163.js";import{X as Hr}from"./Suffix-32192c0b.js";import{f as Wr}from"./flatten-e16b8b2d.js";import{k as Gr}from"./keep-8a3aab3e.js";function Ce(e,r="default",n=void 0){const t=e[r];if(!t)return me("getFirstSlotVNode",`slot[${r}] is empty`),null;const a=Wr(t(n));return a.length===1?a[0]:(me("getFirstSlotVNode",`slot[${r}] should have exactly one child`),null)}let se;function Kr(){return se===void 0&&(se=navigator.userAgent.includes("Node.js")||navigator.userAgent.includes("jsdom")),se}var Ur=re(ne,"WeakMap");const fe=Ur;var kr=Ar(Object.keys,Object);const jr=kr;var Xr=Object.prototype,Jr=Xr.hasOwnProperty;function qr(e){if(!Or(e))return jr(e);var r=[];for(var n in Object(e))Jr.call(e,n)&&n!="constructor"&&r.push(n);return r}function be(e){return pe(e)?_r(e):qr(e)}function Yr(e,r){for(var n=-1,t=r.length,a=e.length;++n<t;)e[a+n]=r[n];return e}function Qr(e,r){for(var n=-1,t=e==null?0:e.length,a=0,o=[];++n<t;){var s=e[n];r(s,n,e)&&(o[a++]=s)}return o}function Vr(){return[]}var Zr=Object.prototype,en=Zr.propertyIsEnumerable,Ee=Object.getOwnPropertySymbols,rn=Ee?function(e){return e==null?[]:(e=Object(e),Qr(Ee(e),function(r){return en.call(e,r)}))}:Vr;const nn=rn;function tn(e,r,n){var t=r(e);return W(e)?t:Yr(t,n(e))}function Me(e){return tn(e,be,nn)}var on=re(ne,"DataView");const ce=on;var an=re(ne,"Promise");const ve=an;var sn=re(ne,"Set");const he=sn;var Re="[object Map]",ln="[object Object]",Be="[object Promise]",Ie="[object Set]",De="[object WeakMap]",Fe="[object DataView]",un=G(ce),dn=G(de),fn=G(ve),cn=G(he),vn=G(fe),L=je;(ce&&L(new ce(new ArrayBuffer(1)))!=Fe||de&&L(new de)!=Re||ve&&L(ve.resolve())!=Be||he&&L(new he)!=Ie||fe&&L(new fe)!=De)&&(L=function(e){var r=je(e),n=r==ln?e.constructor:void 0,t=n?G(n):"";if(t)switch(t){case un:return Fe;case dn:return Re;case fn:return Be;case cn:return Ie;case vn:return De}return r});const Le=L;var hn="__lodash_hash_undefined__";function gn(e){return this.__data__.set(e,hn),this}function pn(e){return this.__data__.has(e)}function ee(e){var r=-1,n=e==null?0:e.length;for(this.__data__=new Tr;++r<n;)this.add(e[r])}ee.prototype.add=ee.prototype.push=gn;ee.prototype.has=pn;function wn(e,r){for(var n=-1,t=e==null?0:e.length;++n<t;)if(r(e[n],n,e))return!0;return!1}function bn(e,r){return e.has(r)}var yn=1,mn=2;function Xe(e,r,n,t,a,o){var s=n&yn,i=e.length,l=r.length;if(i!=l&&!(s&&l>i))return!1;var d=o.get(e),c=o.get(r);if(d&&c)return d==r&&c==e;var p=-1,v=!0,y=n&mn?new ee:void 0;for(o.set(e,r),o.set(r,e);++p<i;){var m=e[p],f=r[p];if(t)var P=s?t(f,m,p,r,e,o):t(m,f,p,e,r,o);if(P!==void 0){if(P)continue;v=!1;break}if(y){if(!wn(r,function(A,O){if(!bn(y,O)&&(m===A||a(m,A,n,t,o)))return y.push(O)})){v=!1;break}}else if(!(m===f||a(m,f,n,t,o))){v=!1;break}}return o.delete(e),o.delete(r),v}function Sn(e){var r=-1,n=Array(e.size);return e.forEach(function(t,a){n[++r]=[a,t]}),n}function $n(e){var r=-1,n=Array(e.size);return e.forEach(function(t){n[++r]=t}),n}var An=1,On=2,_n="[object Boolean]",Tn="[object Date]",Pn="[object Error]",xn="[object Map]",Cn="[object Number]",En="[object RegExp]",Mn="[object Set]",Rn="[object String]",Bn="[object Symbol]",In="[object ArrayBuffer]",Dn="[object DataView]",ze=Oe?Oe.prototype:void 0,le=ze?ze.valueOf:void 0;function Fn(e,r,n,t,a,o,s){switch(n){case Dn:if(e.byteLength!=r.byteLength||e.byteOffset!=r.byteOffset)return!1;e=e.buffer,r=r.buffer;case In:return!(e.byteLength!=r.byteLength||!o(new _e(e),new _e(r)));case _n:case Tn:case Cn:return Pr(+e,+r);case Pn:return e.name==r.name&&e.message==r.message;case En:case Rn:return e==r+"";case xn:var i=Sn;case Mn:var l=t&An;if(i||(i=$n),e.size!=r.size&&!l)return!1;var d=s.get(e);if(d)return d==r;t|=On,s.set(e,r);var c=Xe(i(e),i(r),t,a,o,s);return s.delete(e),c;case Bn:if(le)return le.call(e)==le.call(r)}return!1}var Ln=1,zn=Object.prototype,Nn=zn.hasOwnProperty;function Hn(e,r,n,t,a,o){var s=n&Ln,i=Me(e),l=i.length,d=Me(r),c=d.length;if(l!=c&&!s)return!1;for(var p=l;p--;){var v=i[p];if(!(s?v in r:Nn.call(r,v)))return!1}var y=o.get(e),m=o.get(r);if(y&&m)return y==r&&m==e;var f=!0;o.set(e,r),o.set(r,e);for(var P=s;++p<l;){v=i[p];var A=e[v],O=r[v];if(t)var z=s?t(O,A,v,r,e,o):t(A,O,v,e,r,o);if(!(z===void 0?A===O||a(A,O,n,t,o):z)){f=!1;break}P||(P=v=="constructor")}if(f&&!P){var E=e.constructor,C=r.constructor;E!=C&&"constructor"in e&&"constructor"in r&&!(typeof E=="function"&&E instanceof E&&typeof C=="function"&&C instanceof C)&&(f=!1)}return o.delete(e),o.delete(r),f}var Wn=1,Ne="[object Arguments]",He="[object Array]",J="[object Object]",Gn=Object.prototype,We=Gn.hasOwnProperty;function Kn(e,r,n,t,a,o){var s=W(e),i=W(r),l=s?He:Le(e),d=i?He:Le(r);l=l==Ne?J:l,d=d==Ne?J:d;var c=l==J,p=d==J,v=l==d;if(v&&Te(e)){if(!Te(r))return!1;s=!0,c=!1}if(v&&!c)return o||(o=new Q),s||xr(e)?Xe(e,r,n,t,a,o):Fn(e,r,l,n,t,a,o);if(!(n&Wn)){var y=c&&We.call(e,"__wrapped__"),m=p&&We.call(r,"__wrapped__");if(y||m){var f=y?e.value():e,P=m?r.value():r;return o||(o=new Q),a(f,P,n,t,o)}}return v?(o||(o=new Q),Hn(e,r,n,t,a,o)):!1}function ye(e,r,n,t,a){return e===r?!0:e==null||r==null||!Pe(e)&&!Pe(r)?e!==e&&r!==r:Kn(e,r,n,t,ye,a)}var Un=1,kn=2;function jn(e,r,n,t){var a=n.length,o=a,s=!t;if(e==null)return!o;for(e=Object(e);a--;){var i=n[a];if(s&&i[2]?i[1]!==e[i[0]]:!(i[0]in e))return!1}for(;++a<o;){i=n[a];var l=i[0],d=e[l],c=i[1];if(s&&i[2]){if(d===void 0&&!(l in e))return!1}else{var p=new Q;if(t)var v=t(d,c,l,e,r,p);if(!(v===void 0?ye(c,d,Un|kn,t,p):v))return!1}}return!0}function Je(e){return e===e&&!Cr(e)}function Xn(e){for(var r=be(e),n=r.length;n--;){var t=r[n],a=e[t];r[n]=[t,a,Je(a)]}return r}function qe(e,r){return function(n){return n==null?!1:n[e]===r&&(r!==void 0||e in Object(n))}}function Jn(e){var r=Xn(e);return r.length==1&&r[0][2]?qe(r[0][0],r[0][1]):function(n){return n===e||jn(n,e,r)}}function qn(e,r){return e!=null&&r in Object(e)}function Yn(e,r,n){r=wr(r,e);for(var t=-1,a=r.length,o=!1;++t<a;){var s=ge(r[t]);if(!(o=e!=null&&n(e,s)))break;e=e[s]}return o||++t!=a?o:(a=e==null?0:e.length,!!a&&Er(a)&&Mr(s,a)&&(W(e)||Rr(e)))}function Qn(e,r){return e!=null&&Yn(e,r,qn)}var Vn=1,Zn=2;function et(e,r){return ke(e)&&Je(r)?qe(ge(e),r):function(n){var t=br(n,e);return t===void 0&&t===r?Qn(n,e):ye(r,t,Vn|Zn)}}function rt(e){return function(r){return r==null?void 0:r[e]}}function nt(e){return function(r){return yr(r,e)}}function tt(e){return ke(e)?rt(ge(e)):nt(e)}function ot(e){return typeof e=="function"?e:e==null?Br:typeof e=="object"?W(e)?et(e[0],e[1]):Jn(e):tt(e)}function at(e,r){return e&&Ir(e,r,be)}function it(e,r){return function(n,t){if(n==null)return n;if(!pe(n))return e(n,t);for(var a=n.length,o=r?a:-1,s=Object(n);(r?o--:++o<a)&&t(s[o],o,s)!==!1;);return n}}var st=it(at);const lt=st;function ut(e,r){var n=-1,t=pe(e)?Array(e.length):[];return lt(e,function(a,o,s){t[++n]=r(a,o,s)}),t}function dt(e,r){var n=W(e)?Nr:ut;return n(e,ot(r))}const ft={space:"6px",spaceArrow:"10px",arrowOffset:"10px",arrowOffsetVertical:"10px",arrowHeight:"6px",padding:"8px 14px"},ct=e=>{const{boxShadow2:r,popoverColor:n,textColor2:t,borderRadius:a,fontSize:o,dividerColor:s}=e;return Object.assign(Object.assign({},ft),{fontSize:o,borderRadius:a,color:n,dividerColor:s,textColor:t,boxShadow:r})},vt={name:"Popover",common:Dr,self:ct},ht=vt,ue={top:"bottom",bottom:"top",left:"right",right:"left"},b="var(--n-arrow-height) * 1.414",gt=D([B("popover",`
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 position: relative;
 font-size: var(--n-font-size);
 color: var(--n-text-color);
 box-shadow: var(--n-box-shadow);
 word-break: break-word;
 `,[D(">",[B("scrollbar",`
 height: inherit;
 max-height: inherit;
 `)]),oe("raw",`
 background-color: var(--n-color);
 border-radius: var(--n-border-radius);
 `,[oe("scrollable",[oe("show-header-or-footer","padding: var(--n-padding);")])]),ae("header",`
 padding: var(--n-padding);
 border-bottom: 1px solid var(--n-divider-color);
 transition: border-color .3s var(--n-bezier);
 `),ae("footer",`
 padding: var(--n-padding);
 border-top: 1px solid var(--n-divider-color);
 transition: border-color .3s var(--n-bezier);
 `),Z("scrollable, show-header-or-footer",[ae("content",`
 padding: var(--n-padding);
 `)])]),B("popover-shared",`
 transform-origin: inherit;
 `,[B("popover-arrow-wrapper",`
 position: absolute;
 overflow: hidden;
 pointer-events: none;
 `,[B("popover-arrow",`
 transition: background-color .3s var(--n-bezier);
 position: absolute;
 display: block;
 width: calc(${b});
 height: calc(${b});
 box-shadow: 0 0 8px 0 rgba(0, 0, 0, .12);
 transform: rotate(45deg);
 background-color: var(--n-color);
 pointer-events: all;
 `)]),D("&.popover-transition-enter-from, &.popover-transition-leave-to",`
 opacity: 0;
 transform: scale(.85);
 `),D("&.popover-transition-enter-to, &.popover-transition-leave-from",`
 transform: scale(1);
 opacity: 1;
 `),D("&.popover-transition-enter-active",`
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier),
 opacity .15s var(--n-bezier-ease-out),
 transform .15s var(--n-bezier-ease-out);
 `),D("&.popover-transition-leave-active",`
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier),
 opacity .15s var(--n-bezier-ease-in),
 transform .15s var(--n-bezier-ease-in);
 `)]),x("top-start",`
 top: calc(${b} / -2);
 left: calc(${R("top-start")} - var(--v-offset-left));
 `),x("top",`
 top: calc(${b} / -2);
 transform: translateX(calc(${b} / -2)) rotate(45deg);
 left: 50%;
 `),x("top-end",`
 top: calc(${b} / -2);
 right: calc(${R("top-end")} + var(--v-offset-left));
 `),x("bottom-start",`
 bottom: calc(${b} / -2);
 left: calc(${R("bottom-start")} - var(--v-offset-left));
 `),x("bottom",`
 bottom: calc(${b} / -2);
 transform: translateX(calc(${b} / -2)) rotate(45deg);
 left: 50%;
 `),x("bottom-end",`
 bottom: calc(${b} / -2);
 right: calc(${R("bottom-end")} + var(--v-offset-left));
 `),x("left-start",`
 left: calc(${b} / -2);
 top: calc(${R("left-start")} - var(--v-offset-top));
 `),x("left",`
 left: calc(${b} / -2);
 transform: translateY(calc(${b} / -2)) rotate(45deg);
 top: 50%;
 `),x("left-end",`
 left: calc(${b} / -2);
 bottom: calc(${R("left-end")} + var(--v-offset-top));
 `),x("right-start",`
 right: calc(${b} / -2);
 top: calc(${R("right-start")} - var(--v-offset-top));
 `),x("right",`
 right: calc(${b} / -2);
 transform: translateY(calc(${b} / -2)) rotate(45deg);
 top: 50%;
 `),x("right-end",`
 right: calc(${b} / -2);
 bottom: calc(${R("right-end")} + var(--v-offset-top));
 `),...dt({top:["right-start","left-start"],right:["top-end","bottom-end"],bottom:["right-end","left-end"],left:["top-start","bottom-start"]},(e,r)=>{const n=["right","left"].includes(r),t=n?"width":"height";return e.map(a=>{const o=a.split("-")[1]==="end",i=`calc((${`var(--v-target-${t}, 0px)`} - ${b}) / 2)`,l=R(a);return D(`[v-placement="${a}"] >`,[B("popover-shared",[Z("center-arrow",[B("popover-arrow",`${r}: calc(max(${i}, ${l}) ${o?"+":"-"} var(--v-offset-${n?"left":"top"}));`)])])])})})]);function R(e){return["top","bottom"].includes(e.split("-")[0])?"var(--n-arrow-offset)":"var(--n-arrow-offset-vertical)"}function x(e,r){const n=e.split("-")[0],t=["top","bottom"].includes(n)?"height: var(--n-space-arrow);":"width: var(--n-space-arrow);";return D(`[v-placement="${e}"] >`,[B("popover-shared",`
 margin-${ue[n]}: var(--n-space);
 `,[Z("show-arrow",`
 margin-${ue[n]}: var(--n-space-arrow);
 `),Z("overlap",`
 margin: 0;
 `),Fr("popover-arrow-wrapper",`
 right: 0;
 left: 0;
 top: 0;
 bottom: 0;
 ${n}: 100%;
 ${ue[n]}: auto;
 ${t}
 `,[B("popover-arrow",r)])])])}const Ye=Object.assign(Object.assign({},we.props),{to:V.propTo,show:Boolean,trigger:String,showArrow:Boolean,delay:Number,duration:Number,raw:Boolean,arrowPointToCenter:Boolean,arrowStyle:[String,Object],displayDirective:String,x:Number,y:Number,flip:Boolean,overlap:Boolean,placement:String,width:[Number,String],keepAliveOnHover:Boolean,scrollable:Boolean,contentStyle:[Object,String],headerStyle:[Object,String],footerStyle:[Object,String],internalDeactivateImmediately:Boolean,animated:Boolean,onClickoutside:Function,internalTrapFocus:Boolean,internalOnAfterLeave:Function,minWidth:Number,maxWidth:Number}),pt=({arrowStyle:e,clsPrefix:r})=>S("div",{key:"__popover-arrow__",class:`${r}-popover-arrow-wrapper`},S("div",{class:`${r}-popover-arrow`,style:e})),wt=Ge({name:"PopoverBody",inheritAttrs:!1,props:Ye,setup(e,{slots:r,attrs:n}){const{namespaceRef:t,mergedClsPrefixRef:a,inlineThemeDisabled:o}=Lr(e),s=we("Popover","-popover",gt,ht,e,a),i=F(null),l=Ze("NPopover"),d=F(null),c=F(e.show),p=F(!1);Ke(()=>{const{show:h}=e;h&&!Kr()&&!e.internalDeactivateImmediately&&(p.value=!0)});const v=j(()=>{const{trigger:h,onClickoutside:$}=e,_=[],{positionManuallyRef:{value:g}}=l;return g||(h==="click"&&!$&&_.push([Se,E,void 0,{capture:!0}]),h==="hover"&&_.push([er,z])),$&&_.push([Se,E,void 0,{capture:!0}]),(e.displayDirective==="show"||e.animated&&p.value)&&_.push([rr,e.show]),_}),y=j(()=>{const h=e.width==="trigger"?void 0:te(e.width),$=[];h&&$.push({width:h});const{maxWidth:_,minWidth:g}=e;return _&&$.push({maxWidth:te(_)}),g&&$.push({maxWidth:te(g)}),o||$.push(m.value),$}),m=j(()=>{const{common:{cubicBezierEaseInOut:h,cubicBezierEaseIn:$,cubicBezierEaseOut:_},self:{space:g,spaceArrow:U,padding:k,fontSize:I,textColor:u,dividerColor:w,color:T,boxShadow:N,borderRadius:H,arrowHeight:M,arrowOffset:Qe,arrowOffsetVertical:Ve}}=s.value;return{"--n-box-shadow":N,"--n-bezier":h,"--n-bezier-ease-in":$,"--n-bezier-ease-out":_,"--n-font-size":I,"--n-text-color":u,"--n-color":T,"--n-divider-color":w,"--n-border-radius":H,"--n-arrow-height":M,"--n-arrow-offset":Qe,"--n-arrow-offset-vertical":Ve,"--n-padding":k,"--n-space":g,"--n-space-arrow":U}}),f=o?zr("popover",void 0,m,e):void 0;l.setBodyInstance({syncPosition:P}),nr(()=>{l.setBodyInstance(null)}),tr(q(e,"show"),h=>{e.animated||(h?c.value=!0:c.value=!1)});function P(){var h;(h=i.value)===null||h===void 0||h.syncPosition()}function A(h){e.trigger==="hover"&&e.keepAliveOnHover&&e.show&&l.handleMouseEnter(h)}function O(h){e.trigger==="hover"&&e.keepAliveOnHover&&l.handleMouseLeave(h)}function z(h){e.trigger==="hover"&&!C().contains($e(h))&&l.handleMouseMoveOutside(h)}function E(h){(e.trigger==="click"&&!C().contains($e(h))||e.onClickoutside)&&l.handleClickOutside(h)}function C(){return l.getTriggerElement()}Y(mr,d),Y(Sr,null),Y($r,null);function K(){if(f==null||f.onRender(),!(e.displayDirective==="show"||e.show||e.animated&&p.value))return null;let $;const _=l.internalRenderBodyRef.value,{value:g}=a;if(_)$=_([`${g}-popover-shared`,f==null?void 0:f.themeClass.value,e.overlap&&`${g}-popover-shared--overlap`,e.showArrow&&`${g}-popover-shared--show-arrow`,e.arrowPointToCenter&&`${g}-popover-shared--center-arrow`],d,y.value,A,O);else{const{value:U}=l.extraClassRef,{internalTrapFocus:k}=e,I=!xe(r.header)||!xe(r.footer),u=()=>{var w;const T=I?S(lr,null,ie(r.header,M=>M?S("div",{class:`${g}-popover__header`,style:e.headerStyle},M):null),ie(r.default,M=>M?S("div",{class:`${g}-popover__content`,style:e.contentStyle},r):null),ie(r.footer,M=>M?S("div",{class:`${g}-popover__footer`,style:e.footerStyle},M):null)):e.scrollable?(w=r.default)===null||w===void 0?void 0:w.call(r):S("div",{class:`${g}-popover__content`,style:e.contentStyle},r),N=e.scrollable?S(Hr,{contentClass:I?void 0:`${g}-popover__content`,contentStyle:I?void 0:e.contentStyle},{default:()=>T}):T,H=e.showArrow?pt({arrowStyle:e.arrowStyle,clsPrefix:g}):null;return[N,H]};$=S("div",sr({class:[`${g}-popover`,`${g}-popover-shared`,f==null?void 0:f.themeClass.value,U.map(w=>`${g}-${w}`),{[`${g}-popover--scrollable`]:e.scrollable,[`${g}-popover--show-header-or-footer`]:I,[`${g}-popover--raw`]:e.raw,[`${g}-popover-shared--overlap`]:e.overlap,[`${g}-popover-shared--show-arrow`]:e.showArrow,[`${g}-popover-shared--center-arrow`]:e.arrowPointToCenter}],ref:d,style:y.value,onKeydown:l.handleKeydown,onMouseenter:A,onMouseleave:O},n),k?S(ir,{active:e.show,autoFocus:!0},{default:u}):u())}return Ue($,v.value)}return{displayed:p,namespace:t,isMounted:l.isMountedRef,zIndex:l.zIndexRef,followerRef:i,adjustedTo:V(e),followerEnabled:c,renderContentNode:K}},render(){return S(ar,{ref:"followerRef",zIndex:this.zIndex,show:this.show,enabled:this.followerEnabled,to:this.adjustedTo,x:this.x,y:this.y,flip:this.flip,placement:this.placement,containerClass:this.namespace,overlap:this.overlap,width:this.width==="trigger"?"target":void 0,teleportDisabled:this.adjustedTo===V.tdkey},{default:()=>this.animated?S(or,{name:"popover-transition",appear:this.isMounted,onEnter:()=>{this.followerEnabled=!0},onAfterLeave:()=>{var e;(e=this.internalOnAfterLeave)===null||e===void 0||e.call(this),this.followerEnabled=!1,this.displayed=!1}},{default:this.renderContentNode}):this.renderContentNode()})}}),bt=Object.keys(Ye),yt={focus:["onFocus","onBlur"],click:["onClick"],hover:["onMouseenter","onMouseleave"],manual:[],nested:["onFocus","onBlur","onMouseenter","onMouseleave","onClick"]};function mt(e,r,n){yt[r].forEach(t=>{e.props?e.props=Object.assign({},e.props):e.props={};const a=e.props[t],o=n[t];a?e.props[t]=(...s)=>{a(...s),o(...s)}:e.props[t]=o})}const St={show:{type:Boolean,default:void 0},defaultShow:Boolean,showArrow:{type:Boolean,default:!0},trigger:{type:String,default:"hover"},delay:{type:Number,default:100},duration:{type:Number,default:100},raw:Boolean,placement:{type:String,default:"top"},x:Number,y:Number,arrowPointToCenter:Boolean,disabled:Boolean,getDisabled:Function,displayDirective:{type:String,default:"if"},arrowStyle:[String,Object],flip:{type:Boolean,default:!0},animated:{type:Boolean,default:!0},width:{type:[Number,String],default:void 0},overlap:Boolean,keepAliveOnHover:{type:Boolean,default:!0},zIndex:Number,to:V.propTo,scrollable:Boolean,contentStyle:[Object,String],headerStyle:[Object,String],footerStyle:[Object,String],onClickoutside:Function,"onUpdate:show":[Function,Array],onUpdateShow:[Function,Array],internalDeactivateImmediately:Boolean,internalSyncTargetWithParent:Boolean,internalInheritedEventHandlers:{type:Array,default:()=>[]},internalTrapFocus:Boolean,internalExtraClass:{type:Array,default:()=>[]},onShow:[Function,Array],onHide:[Function,Array],arrow:{type:Boolean,default:void 0},minWidth:Number,maxWidth:Number},$t=Object.assign(Object.assign(Object.assign({},we.props),St),{internalOnAfterLeave:Function,internalRenderBody:Function}),Et=Ge({name:"Popover",inheritAttrs:!1,props:$t,__popover__:!0,setup(e){const r=ur(),n=F(null),t=j(()=>e.show),a=F(e.defaultShow),o=dr(t,a),s=Ae(()=>e.disabled?!1:o.value),i=()=>{if(e.disabled)return!0;const{getDisabled:u}=e;return!!(u!=null&&u())},l=()=>i()?!1:o.value,d=fr(e,["arrow","showArrow"]),c=j(()=>e.overlap?!1:d.value);let p=null;const v=F(null),y=F(null),m=Ae(()=>e.x!==void 0&&e.y!==void 0);function f(u){const{"onUpdate:show":w,onUpdateShow:T,onShow:N,onHide:H}=e;a.value=u,w&&X(w,u),T&&X(T,u),u&&N&&X(N,!0),u&&H&&X(H,!1)}function P(){p&&p.syncPosition()}function A(){const{value:u}=v;u&&(window.clearTimeout(u),v.value=null)}function O(){const{value:u}=y;u&&(window.clearTimeout(u),y.value=null)}function z(){const u=i();if(e.trigger==="focus"&&!u){if(l())return;f(!0)}}function E(){const u=i();if(e.trigger==="focus"&&!u){if(!l())return;f(!1)}}function C(){const u=i();if(e.trigger==="hover"&&!u){if(O(),v.value!==null||l())return;const w=()=>{f(!0),v.value=null},{delay:T}=e;T===0?w():v.value=window.setTimeout(w,T)}}function K(){const u=i();if(e.trigger==="hover"&&!u){if(A(),y.value!==null||!l())return;const w=()=>{f(!1),y.value=null},{duration:T}=e;T===0?w():y.value=window.setTimeout(w,T)}}function h(){K()}function $(u){var w;l()&&(e.trigger==="click"&&(A(),O(),f(!1)),(w=e.onClickoutside)===null||w===void 0||w.call(e,u))}function _(){if(e.trigger==="click"&&!i()){A(),O();const u=!l();f(u)}}function g(u){e.internalTrapFocus&&u.key==="Escape"&&(A(),O(),f(!1))}function U(u){a.value=u}function k(){var u;return(u=n.value)===null||u===void 0?void 0:u.targetRef}function I(u){p=u}return Y("NPopover",{getTriggerElement:k,handleKeydown:g,handleMouseEnter:C,handleMouseLeave:K,handleClickOutside:$,handleMouseMoveOutside:h,setBodyInstance:I,positionManuallyRef:m,isMountedRef:r,zIndexRef:q(e,"zIndex"),extraClassRef:q(e,"internalExtraClass"),internalRenderBodyRef:q(e,"internalRenderBody")}),Ke(()=>{o.value&&i()&&f(!1)}),{binderInstRef:n,positionManually:m,mergedShowConsideringDisabledProp:s,uncontrolledShow:a,mergedShowArrow:c,getMergedShow:l,setShow:U,handleClick:_,handleMouseEnter:C,handleMouseLeave:K,handleFocus:z,handleBlur:E,syncPosition:P}},render(){var e;const{positionManually:r,$slots:n}=this;let t,a=!1;if(!r&&(n.activator?t=Ce(n,"activator"):t=Ce(n,"trigger"),t)){t=cr(t),t=t.type===vr?S("span",[t]):t;const o={onClick:this.handleClick,onMouseenter:this.handleMouseEnter,onMouseleave:this.handleMouseLeave,onFocus:this.handleFocus,onBlur:this.handleBlur};if(!((e=t.type)===null||e===void 0)&&e.__popover__)a=!0,t.props||(t.props={internalSyncTargetWithParent:!0,internalInheritedEventHandlers:[]}),t.props.internalSyncTargetWithParent=!0,t.props.internalInheritedEventHandlers?t.props.internalInheritedEventHandlers=[o,...t.props.internalInheritedEventHandlers]:t.props.internalInheritedEventHandlers=[o];else{const{internalInheritedEventHandlers:s}=this,i=[o,...s],l={onBlur:d=>{i.forEach(c=>{c.onBlur(d)})},onFocus:d=>{i.forEach(c=>{c.onFocus(d)})},onClick:d=>{i.forEach(c=>{c.onClick(d)})},onMouseenter:d=>{i.forEach(c=>{c.onMouseenter(d)})},onMouseleave:d=>{i.forEach(c=>{c.onMouseleave(d)})}};mt(t,s?"nested":r?"manual":this.trigger,l)}}return S(pr,{ref:"binderInstRef",syncTarget:!a,syncTargetWithParent:this.internalSyncTargetWithParent},{default:()=>{this.mergedShowConsideringDisabledProp;const o=this.getMergedShow();return[this.internalTrapFocus&&o?Ue(S("div",{style:{position:"fixed",inset:0}}),[[hr,{enabled:o,zIndex:this.zIndex}]]):null,r?null:S(gr,null,{default:()=>t}),S(wt,Gr(this.$props,bt,Object.assign(Object.assign({},this.$attrs),{showArrow:this.mergedShowArrow,show:o})),{default:()=>{var s,i;return(i=(s=this.$slots).default)===null||i===void 0?void 0:i.call(s)},header:()=>{var s,i;return(i=(s=this.$slots).header)===null||i===void 0?void 0:i.call(s)},footer:()=>{var s,i;return(i=(s=this.$slots).footer)===null||i===void 0?void 0:i.call(s)}})]}})}});export{Et as N,St as a,ht as p};
