import{f as dt,d as ie,i as we,t as bt,j as c,m as K,a7 as ct,J as ft,r as B,cy as ge,s as pt,z as Z,A as ee,p as ut,v as O,cI as gt,x as vt,a_ as X,V as ve,cJ as xt,B as ht,C as mt,cD as yt,e as Ct}from"./index-73e16628.js";import{i as St,N as wt}from"./Icon-9eb33163.js";import{A as Pt}from"./Add-be454b30.js";import{r as Tt}from"./render-d93ede5d.js";import{a as Rt}from"./Card-47c76d51.js";import{I as q,t as zt,c as Lt,a as n,e as s,d as P,b as W,i as $t,u as Bt,f as Pe,j,g as Wt,l as xe,n as J}from"./light-07aa199c.js";import{f as te}from"./flatten-e16b8b2d.js";function At(e,r=[],o){const b={};return Object.getOwnPropertyNames(e).forEach(y=>{r.includes(y)||(b[y]=e[y])}),Object.assign(b,o)}var _t=/\s/;function Et(e){for(var r=e.length;r--&&_t.test(e.charAt(r)););return r}var Vt=/^\s+/;function jt(e){return e&&e.slice(0,Et(e)+1).replace(Vt,"")}var he=0/0,It=/^[-+]0x[0-9a-f]+$/i,kt=/^0b[01]+$/i,Mt=/^0o[0-7]+$/i,Ot=parseInt;function me(e){if(typeof e=="number")return e;if(St(e))return he;if(q(e)){var r=typeof e.valueOf=="function"?e.valueOf():e;e=q(r)?r+"":r}if(typeof e!="string")return e===0?e:+e;e=jt(e);var o=kt.test(e);return o||Mt.test(e)?Ot(e.slice(2),o?2:8):It.test(e)?he:+e}var Gt=function(){return zt.Date.now()};const ae=Gt;var Ht="Expected a function",Ft=Math.max,Dt=Math.min;function Nt(e,r,o){var b,f,y,u,p,m,x=0,C=!1,S=!1,h=!0;if(typeof e!="function")throw new TypeError(Ht);r=me(r)||0,q(o)&&(C=!!o.leading,S="maxWait"in o,y=S?Ft(me(o.maxWait)||0,r):y,h="trailing"in o?!!o.trailing:h);function v(d){var L=b,I=f;return b=f=void 0,x=d,u=e.apply(I,L),u}function w(d){return x=d,p=setTimeout(A,r),C?v(d):u}function R(d){var L=d-m,I=d-x,M=r-L;return S?Dt(M,y-I):M}function T(d){var L=d-m,I=d-x;return m===void 0||L>=r||L<0||S&&I>=y}function A(){var d=ae();if(T(d))return z(d);p=setTimeout(A,R(d))}function z(d){return p=void 0,h&&b?v(d):(b=f=void 0,u)}function _(){p!==void 0&&clearTimeout(p),x=0,b=m=f=p=void 0}function V(){return p===void 0?u:z(ae())}function g(){var d=ae(),L=T(d);if(b=arguments,f=this,m=d,L){if(p===void 0)return w(m);if(S)return clearTimeout(p),p=setTimeout(A,r),v(m)}return p===void 0&&(p=setTimeout(A,r)),u}return g.cancel=_,g.flush=V,g}var Ut="Expected a function";function re(e,r,o){var b=!0,f=!0;if(typeof e!="function")throw new TypeError(Ut);return q(o)&&(b="leading"in o?!!o.leading:b,f="trailing"in o?!!o.trailing:f),Nt(e,r,{leading:b,maxWait:r,trailing:f})}const Xt={tabFontSizeSmall:"14px",tabFontSizeMedium:"14px",tabFontSizeLarge:"16px",tabGapSmallLine:"36px",tabGapMediumLine:"36px",tabGapLargeLine:"36px",tabGapSmallLineVertical:"8px",tabGapMediumLineVertical:"8px",tabGapLargeLineVertical:"8px",tabPaddingSmallLine:"6px 0",tabPaddingMediumLine:"10px 0",tabPaddingLargeLine:"14px 0",tabPaddingVerticalSmallLine:"6px 12px",tabPaddingVerticalMediumLine:"8px 16px",tabPaddingVerticalLargeLine:"10px 20px",tabGapSmallBar:"36px",tabGapMediumBar:"36px",tabGapLargeBar:"36px",tabGapSmallBarVertical:"8px",tabGapMediumBarVertical:"8px",tabGapLargeBarVertical:"8px",tabPaddingSmallBar:"4px 0",tabPaddingMediumBar:"6px 0",tabPaddingLargeBar:"10px 0",tabPaddingVerticalSmallBar:"6px 12px",tabPaddingVerticalMediumBar:"8px 16px",tabPaddingVerticalLargeBar:"10px 20px",tabGapSmallCard:"4px",tabGapMediumCard:"4px",tabGapLargeCard:"4px",tabGapSmallCardVertical:"4px",tabGapMediumCardVertical:"4px",tabGapLargeCardVertical:"4px",tabPaddingSmallCard:"8px 16px",tabPaddingMediumCard:"10px 20px",tabPaddingLargeCard:"12px 24px",tabPaddingSmallSegment:"4px 0",tabPaddingMediumSegment:"6px 0",tabPaddingLargeSegment:"8px 0",tabPaddingVerticalLargeSegment:"0 8px",tabPaddingVerticalSmallCard:"8px 12px",tabPaddingVerticalMediumCard:"10px 16px",tabPaddingVerticalLargeCard:"12px 20px",tabPaddingVerticalSmallSegment:"0 4px",tabPaddingVerticalMediumSegment:"0 6px",tabGapSmallSegment:"0",tabGapMediumSegment:"0",tabGapLargeSegment:"0",tabGapSmallSegmentVertical:"0",tabGapMediumSegmentVertical:"0",tabGapLargeSegmentVertical:"0",panePaddingSmall:"8px 0 0 0",panePaddingMedium:"12px 0 0 0",panePaddingLarge:"16px 0 0 0",closeSize:"18px",closeIconSize:"14px"},Jt=e=>{const{textColor2:r,primaryColor:o,textColorDisabled:b,closeIconColor:f,closeIconColorHover:y,closeIconColorPressed:u,closeColorHover:p,closeColorPressed:m,tabColor:x,baseColor:C,dividerColor:S,fontWeight:h,textColor1:v,borderRadius:w,fontSize:R,fontWeightStrong:T}=e;return Object.assign(Object.assign({},Xt),{colorSegment:x,tabFontSizeCard:R,tabTextColorLine:v,tabTextColorActiveLine:o,tabTextColorHoverLine:o,tabTextColorDisabledLine:b,tabTextColorSegment:v,tabTextColorActiveSegment:r,tabTextColorHoverSegment:r,tabTextColorDisabledSegment:b,tabTextColorBar:v,tabTextColorActiveBar:o,tabTextColorHoverBar:o,tabTextColorDisabledBar:b,tabTextColorCard:v,tabTextColorHoverCard:v,tabTextColorActiveCard:o,tabTextColorDisabledCard:b,barColor:o,closeIconColor:f,closeIconColorHover:y,closeIconColorPressed:u,closeColorHover:p,closeColorPressed:m,closeBorderRadius:w,tabColor:x,tabColorSegment:C,tabBorderColor:S,tabFontWeightActive:h,tabFontWeight:h,tabBorderRadius:w,paneTextColor:r,fontWeightStrong:T})},Kt={name:"Tabs",common:Lt,self:Jt},qt=Kt,se=dt("n-tabs"),Te={tab:[String,Number,Object,Function],name:{type:[String,Number],required:!0},disabled:Boolean,displayDirective:{type:String,default:"if"},closable:{type:Boolean,default:void 0},tabProps:Object,label:[String,Number,Object,Function]},sa=ie({__TAB_PANE__:!0,name:"TabPane",alias:["TabPanel"],props:Te,setup(e){const r=we(se,null);return r||bt("tab-pane","`n-tab-pane` must be placed inside `n-tabs`."),{style:r.paneStyleRef,class:r.paneClassRef,mergedClsPrefix:r.mergedClsPrefixRef}},render(){return c("div",{class:[`${this.mergedClsPrefix}-tab-pane`,this.class],style:this.style},this.$slots)}}),Qt=Object.assign({internalLeftPadded:Boolean,internalAddable:Boolean,internalCreatedByPane:Boolean},At(Te,["displayDirective"])),oe=ie({__TAB__:!0,inheritAttrs:!1,name:"Tab",props:Qt,setup(e){const{mergedClsPrefixRef:r,valueRef:o,typeRef:b,closableRef:f,tabStyleRef:y,tabChangeIdRef:u,onBeforeLeaveRef:p,triggerRef:m,handleAdd:x,activateTab:C,handleClose:S}=we(se);return{trigger:m,mergedClosable:K(()=>{if(e.internalAddable)return!1;const{closable:h}=e;return h===void 0?f.value:h}),style:y,clsPrefix:r,value:o,type:b,handleClose(h){h.stopPropagation(),!e.disabled&&S(e.name)},activateTab(){if(e.disabled)return;if(e.internalAddable){x();return}const{name:h}=e,v=++u.id;if(h!==o.value){const{value:w}=p;w?Promise.resolve(w(e.name,o.value)).then(R=>{R&&u.id===v&&C(h)}):C(h)}}}},render(){const{internalAddable:e,clsPrefix:r,name:o,disabled:b,label:f,tab:y,value:u,mergedClosable:p,style:m,trigger:x,$slots:{default:C}}=this,S=f??y;return c("div",{class:`${r}-tabs-tab-wrapper`},this.internalLeftPadded?c("div",{class:`${r}-tabs-tab-pad`}):null,c("div",Object.assign({key:o,"data-name":o,"data-disabled":b?!0:void 0},ct({class:[`${r}-tabs-tab`,u===o&&`${r}-tabs-tab--active`,b&&`${r}-tabs-tab--disabled`,p&&`${r}-tabs-tab--closable`,e&&`${r}-tabs-tab--addable`],onClick:x==="click"?this.activateTab:void 0,onMouseenter:x==="hover"?this.activateTab:void 0,style:e?void 0:m},this.internalCreatedByPane?this.tabProps||{}:this.$attrs)),c("span",{class:`${r}-tabs-tab__label`},e?c(ft,null,c("div",{class:`${r}-tabs-tab__height-placeholder`}," "),c(wt,{clsPrefix:r},{default:()=>c(Pt,null)})):C?C():typeof S=="object"?S:Tt(S??o)),p&&this.type==="card"?c(Rt,{clsPrefix:r,class:`${r}-tabs-tab__close`,onClick:this.handleClose,disabled:b}):null))}}),Yt=n("tabs",`
 box-sizing: border-box;
 width: 100%;
 display: flex;
 flex-direction: column;
 transition:
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
`,[s("segment-type",[n("tabs-rail",[P("&.transition-disabled","color: red;",[n("tabs-tab",`
 transition: none;
 `)])])]),s("top",[n("tab-pane",`
 padding: var(--n-pane-padding-top) var(--n-pane-padding-right) var(--n-pane-padding-bottom) var(--n-pane-padding-left);
 `)]),s("left",[n("tab-pane",`
 padding: var(--n-pane-padding-right) var(--n-pane-padding-bottom) var(--n-pane-padding-left) var(--n-pane-padding-top);
 `)]),s("left, right",`
 flex-direction: row;
 `,[n("tabs-bar",`
 width: 2px;
 right: 0;
 transition:
 top .2s var(--n-bezier),
 max-height .2s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `),n("tabs-tab",`
 padding: var(--n-tab-padding-vertical); 
 `)]),s("right",`
 flex-direction: row-reverse;
 `,[n("tab-pane",`
 padding: var(--n-pane-padding-left) var(--n-pane-padding-top) var(--n-pane-padding-right) var(--n-pane-padding-bottom);
 `),n("tabs-bar",`
 left: 0;
 `)]),s("bottom",`
 flex-direction: column-reverse;
 justify-content: flex-end;
 `,[n("tab-pane",`
 padding: var(--n-pane-padding-bottom) var(--n-pane-padding-right) var(--n-pane-padding-top) var(--n-pane-padding-left);
 `),n("tabs-bar",`
 top: 0;
 `)]),n("tabs-rail",`
 padding: 3px;
 border-radius: var(--n-tab-border-radius);
 width: 100%;
 background-color: var(--n-color-segment);
 transition: background-color .3s var(--n-bezier);
 display: flex;
 align-items: center;
 `,[n("tabs-tab-wrapper",`
 flex-basis: 0;
 flex-grow: 1;
 display: flex;
 align-items: center;
 justify-content: center;
 `,[n("tabs-tab",`
 overflow: hidden;
 border-radius: var(--n-tab-border-radius);
 width: 100%;
 display: flex;
 align-items: center;
 justify-content: center;
 `,[s("active",`
 font-weight: var(--n-font-weight-strong);
 color: var(--n-tab-text-color-active);
 background-color: var(--n-tab-color-segment);
 box-shadow: 0 1px 3px 0 rgba(0, 0, 0, .08);
 `),P("&:hover",`
 color: var(--n-tab-text-color-hover);
 `)])])]),s("flex",[n("tabs-nav",{width:"100%"},[n("tabs-wrapper",{width:"100%"},[n("tabs-tab",{marginRight:0})])])]),n("tabs-nav",`
 box-sizing: border-box;
 line-height: 1.5;
 display: flex;
 transition: border-color .3s var(--n-bezier);
 `,[W("prefix, suffix",`
 display: flex;
 align-items: center;
 `),W("prefix","padding-right: 16px;"),W("suffix","padding-left: 16px;")]),s("top, bottom",[n("tabs-nav-scroll-wrapper",[P("&::before",`
 top: 0;
 bottom: 0;
 left: 0;
 width: 20px;
 `),P("&::after",`
 top: 0;
 bottom: 0;
 right: 0;
 width: 20px;
 `),s("shadow-start",[P("&::before",`
 box-shadow: inset 10px 0 8px -8px rgba(0, 0, 0, .12);
 `)]),s("shadow-end",[P("&::after",`
 box-shadow: inset -10px 0 8px -8px rgba(0, 0, 0, .12);
 `)])])]),s("left, right",[n("tabs-nav-scroll-wrapper",[P("&::before",`
 top: 0;
 left: 0;
 right: 0;
 height: 20px;
 `),P("&::after",`
 bottom: 0;
 left: 0;
 right: 0;
 height: 20px;
 `),s("shadow-start",[P("&::before",`
 box-shadow: inset 0 10px 8px -8px rgba(0, 0, 0, .12);
 `)]),s("shadow-end",[P("&::after",`
 box-shadow: inset 0 -10px 8px -8px rgba(0, 0, 0, .12);
 `)])])]),n("tabs-nav-scroll-wrapper",`
 flex: 1;
 position: relative;
 overflow: hidden;
 `,[n("tabs-nav-y-scroll",`
 height: 100%;
 width: 100%;
 overflow-y: auto; 
 scrollbar-width: none;
 `,[P("&::-webkit-scrollbar",`
 width: 0;
 height: 0;
 `)]),P("&::before, &::after",`
 transition: box-shadow .3s var(--n-bezier);
 pointer-events: none;
 content: "";
 position: absolute;
 z-index: 1;
 `)]),n("tabs-nav-scroll-content",`
 display: flex;
 position: relative;
 min-width: 100%;
 width: fit-content;
 box-sizing: border-box;
 `),n("tabs-wrapper",`
 display: inline-flex;
 flex-wrap: nowrap;
 position: relative;
 `),n("tabs-tab-wrapper",`
 display: flex;
 flex-wrap: nowrap;
 flex-shrink: 0;
 flex-grow: 0;
 `),n("tabs-tab",`
 cursor: pointer;
 white-space: nowrap;
 flex-wrap: nowrap;
 display: inline-flex;
 align-items: center;
 color: var(--n-tab-text-color);
 font-size: var(--n-tab-font-size);
 background-clip: padding-box;
 padding: var(--n-tab-padding);
 transition:
 box-shadow .3s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[s("disabled",{cursor:"not-allowed"}),W("close",`
 margin-left: 6px;
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `),W("label",`
 display: flex;
 align-items: center;
 `)]),n("tabs-bar",`
 position: absolute;
 bottom: 0;
 height: 2px;
 border-radius: 1px;
 background-color: var(--n-bar-color);
 transition:
 left .2s var(--n-bezier),
 max-width .2s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `,[P("&.transition-disabled",`
 transition: none;
 `),s("disabled",`
 background-color: var(--n-tab-text-color-disabled)
 `)]),n("tabs-pane-wrapper",`
 position: relative;
 overflow: hidden;
 transition: max-height .2s var(--n-bezier);
 `),n("tab-pane",`
 color: var(--n-pane-text-color);
 width: 100%;
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 opacity .2s var(--n-bezier);
 left: 0;
 right: 0;
 top: 0;
 `,[P("&.next-transition-leave-active, &.prev-transition-leave-active, &.next-transition-enter-active, &.prev-transition-enter-active",`
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 transform .2s var(--n-bezier),
 opacity .2s var(--n-bezier);
 `),P("&.next-transition-leave-active, &.prev-transition-leave-active",`
 position: absolute;
 `),P("&.next-transition-enter-from, &.prev-transition-leave-to",`
 transform: translateX(32px);
 opacity: 0;
 `),P("&.next-transition-leave-to, &.prev-transition-enter-from",`
 transform: translateX(-32px);
 opacity: 0;
 `),P("&.next-transition-leave-from, &.next-transition-enter-to, &.prev-transition-leave-from, &.prev-transition-enter-to",`
 transform: translateX(0);
 opacity: 1;
 `)]),n("tabs-tab-pad",`
 box-sizing: border-box;
 width: var(--n-tab-gap);
 flex-grow: 0;
 flex-shrink: 0;
 `),s("line-type, bar-type",[n("tabs-tab",`
 font-weight: var(--n-tab-font-weight);
 box-sizing: border-box;
 vertical-align: bottom;
 `,[P("&:hover",{color:"var(--n-tab-text-color-hover)"}),s("active",`
 color: var(--n-tab-text-color-active);
 font-weight: var(--n-tab-font-weight-active);
 `),s("disabled",{color:"var(--n-tab-text-color-disabled)"})])]),n("tabs-nav",[s("line-type",[s("top",[W("prefix, suffix",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `),n("tabs-nav-scroll-content",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `),n("tabs-bar",`
 bottom: -1px;
 `)]),s("left",[W("prefix, suffix",`
 border-right: 1px solid var(--n-tab-border-color);
 `),n("tabs-nav-scroll-content",`
 border-right: 1px solid var(--n-tab-border-color);
 `),n("tabs-bar",`
 right: -1px;
 `)]),s("right",[W("prefix, suffix",`
 border-left: 1px solid var(--n-tab-border-color);
 `),n("tabs-nav-scroll-content",`
 border-left: 1px solid var(--n-tab-border-color);
 `),n("tabs-bar",`
 left: -1px;
 `)]),s("bottom",[W("prefix, suffix",`
 border-top: 1px solid var(--n-tab-border-color);
 `),n("tabs-nav-scroll-content",`
 border-top: 1px solid var(--n-tab-border-color);
 `),n("tabs-bar",`
 top: -1px;
 `)]),W("prefix, suffix",`
 transition: border-color .3s var(--n-bezier);
 `),n("tabs-nav-scroll-content",`
 transition: border-color .3s var(--n-bezier);
 `),n("tabs-bar",`
 border-radius: 0;
 `)]),s("card-type",[W("prefix, suffix",`
 transition: border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-tab-border-color);
 `),n("tabs-pad",`
 flex-grow: 1;
 transition: border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-tab-border-color);
 `),n("tabs-tab-pad",`
 transition: border-color .3s var(--n-bezier);
 `),n("tabs-tab",`
 font-weight: var(--n-tab-font-weight);
 border: 1px solid var(--n-tab-border-color);
 background-color: var(--n-tab-color);
 box-sizing: border-box;
 position: relative;
 vertical-align: bottom;
 display: flex;
 justify-content: space-between;
 font-size: var(--n-tab-font-size);
 color: var(--n-tab-text-color);
 `,[s("addable",`
 padding-left: 8px;
 padding-right: 8px;
 font-size: 16px;
 `,[W("height-placeholder",`
 width: 0;
 font-size: var(--n-tab-font-size);
 `),$t("disabled",[P("&:hover",`
 color: var(--n-tab-text-color-hover);
 `)])]),s("closable","padding-right: 8px;"),s("active",`
 background-color: #0000;
 font-weight: var(--n-tab-font-weight-active);
 color: var(--n-tab-text-color-active);
 `),s("disabled","color: var(--n-tab-text-color-disabled);")]),n("tabs-scroll-padding","border-bottom: 1px solid var(--n-tab-border-color);")]),s("left, right",[n("tabs-wrapper",`
 flex-direction: column;
 `,[n("tabs-tab-wrapper",`
 flex-direction: column;
 `,[n("tabs-tab-pad",`
 height: var(--n-tab-gap-vertical);
 width: 100%;
 `)])])]),s("top",[s("card-type",[n("tabs-tab",`
 border-top-left-radius: var(--n-tab-border-radius);
 border-top-right-radius: var(--n-tab-border-radius);
 `,[s("active",`
 border-bottom: 1px solid #0000;
 `)]),n("tabs-tab-pad",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `)])]),s("left",[s("card-type",[n("tabs-tab",`
 border-top-left-radius: var(--n-tab-border-radius);
 border-bottom-left-radius: var(--n-tab-border-radius);
 `,[s("active",`
 border-right: 1px solid #0000;
 `)]),n("tabs-tab-pad",`
 border-right: 1px solid var(--n-tab-border-color);
 `)])]),s("right",[s("card-type",[n("tabs-tab",`
 border-top-right-radius: var(--n-tab-border-radius);
 border-bottom-right-radius: var(--n-tab-border-radius);
 `,[s("active",`
 border-left: 1px solid #0000;
 `)]),n("tabs-tab-pad",`
 border-left: 1px solid var(--n-tab-border-color);
 `)])]),s("bottom",[s("card-type",[n("tabs-tab",`
 border-bottom-left-radius: var(--n-tab-border-radius);
 border-bottom-right-radius: var(--n-tab-border-radius);
 `,[s("active",`
 border-top: 1px solid #0000;
 `)]),n("tabs-tab-pad",`
 border-top: 1px solid var(--n-tab-border-color);
 `)])])])]),Zt=Object.assign(Object.assign({},Pe.props),{value:[String,Number],defaultValue:[String,Number],trigger:{type:String,default:"click"},type:{type:String,default:"bar"},closable:Boolean,justifyContent:String,size:{type:String,default:"medium"},placement:{type:String,default:"top"},tabStyle:[String,Object],barWidth:Number,paneClass:String,paneStyle:[String,Object],paneWrapperClass:String,paneWrapperStyle:[String,Object],addable:[Boolean,Object],tabsPadding:{type:Number,default:0},animated:Boolean,onBeforeLeave:Function,onAdd:Function,"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],onClose:[Function,Array],labelSize:String,activeName:[String,Number],onActiveNameChange:[Function,Array]}),la=ie({name:"Tabs",props:Zt,setup(e,{slots:r}){var o,b,f,y;const{mergedClsPrefixRef:u,inlineThemeDisabled:p}=Bt(e),m=Pe("Tabs","-tabs",Yt,qt,e,u),x=B(null),C=B(null),S=B(null),h=B(null),v=B(null),w=B(!0),R=B(!0),T=ge(e,["labelSize","size"]),A=ge(e,["activeName","value"]),z=B((b=(o=A.value)!==null&&o!==void 0?o:e.defaultValue)!==null&&b!==void 0?b:r.default?(y=(f=te(r.default())[0])===null||f===void 0?void 0:f.props)===null||y===void 0?void 0:y.name:null),_=pt(A,z),V={id:0},g=K(()=>{if(!(!e.justifyContent||e.type==="card"))return{display:"flex",justifyContent:e.justifyContent}});Z(_,()=>{V.id=0,M(),le()});function d(){var t;const{value:a}=_;return a===null?null:(t=x.value)===null||t===void 0?void 0:t.querySelector(`[data-name="${a}"]`)}function L(t){if(e.type==="card")return;const{value:a}=C;if(a&&t){const i=`${u.value}-tabs-bar--disabled`,{barWidth:l,placement:$}=e;if(t.dataset.disabled==="true"?a.classList.add(i):a.classList.remove(i),["top","bottom"].includes($)){if(I(["top","maxHeight","height"]),typeof l=="number"&&t.offsetWidth>=l){const E=Math.floor((t.offsetWidth-l)/2)+t.offsetLeft;a.style.left=`${E}px`,a.style.maxWidth=`${l}px`}else a.style.left=`${t.offsetLeft}px`,a.style.maxWidth=`${t.offsetWidth}px`;a.style.width="8192px",a.offsetWidth}else{if(I(["left","maxWidth","width"]),typeof l=="number"&&t.offsetHeight>=l){const E=Math.floor((t.offsetHeight-l)/2)+t.offsetTop;a.style.top=`${E}px`,a.style.maxHeight=`${l}px`}else a.style.top=`${t.offsetTop}px`,a.style.maxHeight=`${t.offsetHeight}px`;a.style.height="8192px",a.offsetHeight}}}function I(t){const{value:a}=C;if(a)for(const i of t)a.style[i]=""}function M(){if(e.type==="card")return;const t=d();t&&L(t)}function le(t){var a;const i=(a=v.value)===null||a===void 0?void 0:a.$el;if(!i)return;const l=d();if(!l)return;const{scrollLeft:$,offsetWidth:E}=i,{offsetLeft:H,offsetWidth:N}=l;$>H?i.scrollTo({top:0,left:H,behavior:"smooth"}):H+N>$+E&&i.scrollTo({top:0,left:H+N-E,behavior:"smooth"})}const F=B(null);let Q=0,k=null;function Re(t){const a=F.value;if(a){Q=t.getBoundingClientRect().height;const i=`${Q}px`,l=()=>{a.style.height=i,a.style.maxHeight=i};k?(l(),k(),k=null):k=l}}function ze(t){const a=F.value;if(a){const i=t.getBoundingClientRect().height,l=()=>{document.body.offsetHeight,a.style.maxHeight=`${i}px`,a.style.height=`${Math.max(Q,i)}px`};k?(k(),k=null,l()):k=l}}function Le(){const t=F.value;t&&(t.style.maxHeight="",t.style.height="")}const de={value:[]},be=B("next");function $e(t){const a=_.value;let i="next";for(const l of de.value){if(l===a)break;if(l===t){i="prev";break}}be.value=i,Be(t)}function Be(t){const{onActiveNameChange:a,onUpdateValue:i,"onUpdate:value":l}=e;a&&J(a,t),i&&J(i,t),l&&J(l,t),z.value=t}function We(t){const{onClose:a}=e;a&&J(a,t)}function ce(){const{value:t}=C;if(!t)return;const a="transition-disabled";t.classList.add(a),M(),t.classList.remove(a)}let fe=0;function Ae(t){var a;if(t.contentRect.width===0&&t.contentRect.height===0||fe===t.contentRect.width)return;fe=t.contentRect.width;const{type:i}=e;(i==="line"||i==="bar")&&ce(),i!=="segment"&&Y((a=v.value)===null||a===void 0?void 0:a.$el)}const _e=re(Ae,64);Z([()=>e.justifyContent,()=>e.size],()=>{ee(()=>{const{type:t}=e;(t==="line"||t==="bar")&&ce()})});const D=B(!1);function Ee(t){var a;const{target:i,contentRect:{width:l}}=t,$=i.parentElement.offsetWidth;if(!D.value)$<l&&(D.value=!0);else{const{value:E}=h;if(!E)return;$-l>E.$el.offsetWidth&&(D.value=!1)}Y((a=v.value)===null||a===void 0?void 0:a.$el)}const Ve=re(Ee,64);function je(){const{onAdd:t}=e;t&&t(),ee(()=>{const a=d(),{value:i}=v;!a||!i||i.scrollTo({left:a.offsetLeft,top:0,behavior:"smooth"})})}function Y(t){if(!t)return;const{placement:a}=e;if(a==="top"||a==="bottom"){const{scrollLeft:i,scrollWidth:l,offsetWidth:$}=t;w.value=i<=0,R.value=i+$>=l}else{const{scrollTop:i,scrollHeight:l,offsetHeight:$}=t;w.value=i<=0,R.value=i+$>=l}}const Ie=re(t=>{Y(t.target)},64);ut(se,{triggerRef:O(e,"trigger"),tabStyleRef:O(e,"tabStyle"),paneClassRef:O(e,"paneClass"),paneStyleRef:O(e,"paneStyle"),mergedClsPrefixRef:u,typeRef:O(e,"type"),closableRef:O(e,"closable"),valueRef:_,tabChangeIdRef:V,onBeforeLeaveRef:O(e,"onBeforeLeave"),activateTab:$e,handleClose:We,handleAdd:je}),gt(()=>{M(),le()}),vt(()=>{const{value:t}=S;if(!t)return;const{value:a}=u,i=`${a}-tabs-nav-scroll-wrapper--shadow-start`,l=`${a}-tabs-nav-scroll-wrapper--shadow-end`;w.value?t.classList.remove(i):t.classList.add(i),R.value?t.classList.remove(l):t.classList.add(l)});const pe=B(null);Z(_,()=>{if(e.type==="segment"){const t=pe.value;t&&ee(()=>{t.classList.add("transition-disabled"),t.offsetWidth,t.classList.remove("transition-disabled")})}});const ke={syncBarPosition:()=>{M()}},ue=K(()=>{const{value:t}=T,{type:a}=e,i={card:"Card",bar:"Bar",line:"Line",segment:"Segment"}[a],l=`${t}${i}`,{self:{barColor:$,closeIconColor:E,closeIconColorHover:H,closeIconColorPressed:N,tabColor:Me,tabBorderColor:Oe,paneTextColor:Ge,tabFontWeight:He,tabBorderRadius:Fe,tabFontWeightActive:De,colorSegment:Ne,fontWeightStrong:Ue,tabColorSegment:Xe,closeSize:Je,closeIconSize:Ke,closeColorHover:qe,closeColorPressed:Qe,closeBorderRadius:Ye,[j("panePadding",t)]:U,[j("tabPadding",l)]:Ze,[j("tabPaddingVertical",l)]:et,[j("tabGap",l)]:tt,[j("tabGap",`${l}Vertical`)]:at,[j("tabTextColor",a)]:rt,[j("tabTextColorActive",a)]:nt,[j("tabTextColorHover",a)]:ot,[j("tabTextColorDisabled",a)]:it,[j("tabFontSize",t)]:st},common:{cubicBezierEaseInOut:lt}}=m.value;return{"--n-bezier":lt,"--n-color-segment":Ne,"--n-bar-color":$,"--n-tab-font-size":st,"--n-tab-text-color":rt,"--n-tab-text-color-active":nt,"--n-tab-text-color-disabled":it,"--n-tab-text-color-hover":ot,"--n-pane-text-color":Ge,"--n-tab-border-color":Oe,"--n-tab-border-radius":Fe,"--n-close-size":Je,"--n-close-icon-size":Ke,"--n-close-color-hover":qe,"--n-close-color-pressed":Qe,"--n-close-border-radius":Ye,"--n-close-icon-color":E,"--n-close-icon-color-hover":H,"--n-close-icon-color-pressed":N,"--n-tab-color":Me,"--n-tab-font-weight":He,"--n-tab-font-weight-active":De,"--n-tab-padding":Ze,"--n-tab-padding-vertical":et,"--n-tab-gap":tt,"--n-tab-gap-vertical":at,"--n-pane-padding-left":X(U,"left"),"--n-pane-padding-right":X(U,"right"),"--n-pane-padding-top":X(U,"top"),"--n-pane-padding-bottom":X(U,"bottom"),"--n-font-weight-strong":Ue,"--n-tab-color-segment":Xe}}),G=p?Wt("tabs",K(()=>`${T.value[0]}${e.type[0]}`),ue,e):void 0;return Object.assign({mergedClsPrefix:u,mergedValue:_,renderedNames:new Set,tabsRailElRef:pe,tabsPaneWrapperRef:F,tabsElRef:x,barElRef:C,addTabInstRef:h,xScrollInstRef:v,scrollWrapperElRef:S,addTabFixed:D,tabWrapperStyle:g,handleNavResize:_e,mergedSize:T,handleScroll:Ie,handleTabsResize:Ve,cssVars:p?void 0:ue,themeClass:G==null?void 0:G.themeClass,animationDirection:be,renderNameListRef:de,onAnimationBeforeLeave:Re,onAnimationEnter:ze,onAnimationAfterEnter:Le,onRender:G==null?void 0:G.onRender},ke)},render(){const{mergedClsPrefix:e,type:r,placement:o,addTabFixed:b,addable:f,mergedSize:y,renderNameListRef:u,onRender:p,paneWrapperClass:m,paneWrapperStyle:x,$slots:{default:C,prefix:S,suffix:h}}=this;p==null||p();const v=C?te(C()).filter(g=>g.type.__TAB_PANE__===!0):[],w=C?te(C()).filter(g=>g.type.__TAB__===!0):[],R=!w.length,T=r==="card",A=r==="segment",z=!T&&!A&&this.justifyContent;u.value=[];const _=()=>{const g=c("div",{style:this.tabWrapperStyle,class:[`${e}-tabs-wrapper`]},z?null:c("div",{class:`${e}-tabs-scroll-padding`,style:{width:`${this.tabsPadding}px`}}),R?v.map((d,L)=>(u.value.push(d.props.name),ne(c(oe,Object.assign({},d.props,{internalCreatedByPane:!0,internalLeftPadded:L!==0&&(!z||z==="center"||z==="start"||z==="end")}),d.children?{default:d.children.tab}:void 0)))):w.map((d,L)=>(u.value.push(d.props.name),ne(L!==0&&!z?Se(d):d))),!b&&f&&T?Ce(f,(R?v.length:w.length)!==0):null,z?null:c("div",{class:`${e}-tabs-scroll-padding`,style:{width:`${this.tabsPadding}px`}}));return c("div",{ref:"tabsElRef",class:`${e}-tabs-nav-scroll-content`},T&&f?c(ve,{onResize:this.handleTabsResize},{default:()=>g}):g,T?c("div",{class:`${e}-tabs-pad`}):null,T?null:c("div",{ref:"barElRef",class:`${e}-tabs-bar`}))},V=A?"top":o;return c("div",{class:[`${e}-tabs`,this.themeClass,`${e}-tabs--${r}-type`,`${e}-tabs--${y}-size`,z&&`${e}-tabs--flex`,`${e}-tabs--${V}`],style:this.cssVars},c("div",{class:[`${e}-tabs-nav--${r}-type`,`${e}-tabs-nav--${V}`,`${e}-tabs-nav`]},xe(S,g=>g&&c("div",{class:`${e}-tabs-nav__prefix`},g)),A?c("div",{class:`${e}-tabs-rail`,ref:"tabsRailElRef"},R?v.map((g,d)=>(u.value.push(g.props.name),c(oe,Object.assign({},g.props,{internalCreatedByPane:!0,internalLeftPadded:d!==0}),g.children?{default:g.children.tab}:void 0))):w.map((g,d)=>(u.value.push(g.props.name),d===0?g:Se(g)))):c(ve,{onResize:this.handleNavResize},{default:()=>c("div",{class:`${e}-tabs-nav-scroll-wrapper`,ref:"scrollWrapperElRef"},["top","bottom"].includes(V)?c(xt,{ref:"xScrollInstRef",onScroll:this.handleScroll},{default:_}):c("div",{class:`${e}-tabs-nav-y-scroll`,onScroll:this.handleScroll},_()))}),b&&f&&T?Ce(f,!0):null,xe(h,g=>g&&c("div",{class:`${e}-tabs-nav__suffix`},g))),R&&(this.animated&&(V==="top"||V==="bottom")?c("div",{ref:"tabsPaneWrapperRef",style:x,class:[`${e}-tabs-pane-wrapper`,m]},ye(v,this.mergedValue,this.renderedNames,this.onAnimationBeforeLeave,this.onAnimationEnter,this.onAnimationAfterEnter,this.animationDirection)):ye(v,this.mergedValue,this.renderedNames)))}});function ye(e,r,o,b,f,y,u){const p=[];return e.forEach(m=>{const{name:x,displayDirective:C,"display-directive":S}=m.props,h=w=>C===w||S===w,v=r===x;if(m.key!==void 0&&(m.key=x),v||h("show")||h("show:lazy")&&o.has(x)){o.has(x)||o.add(x);const w=!h("if");p.push(w?ht(m,[[mt,v]]):m)}}),u?c(yt,{name:`${u}-transition`,onBeforeLeave:b,onEnter:f,onAfterEnter:y},{default:()=>p}):p}function Ce(e,r){return c(oe,{ref:"addTabInstRef",key:"__addable",name:"__addable",internalCreatedByPane:!0,internalAddable:!0,internalLeftPadded:r,disabled:typeof e=="object"&&e.disabled})}function Se(e){const r=Ct(e);return r.props?r.props.internalLeftPadded=!0:r.props={internalLeftPadded:!0},r}function ne(e){return Array.isArray(e.dynamicProps)?e.dynamicProps.includes("internalLeftPadded")||e.dynamicProps.push("internalLeftPadded"):e.dynamicProps=["internalLeftPadded"],e}export{la as N,sa as a};
