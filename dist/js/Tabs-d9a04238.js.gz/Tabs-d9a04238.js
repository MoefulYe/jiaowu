import{dS as dt,dA as J,di as bt,f as ct,k as ft,d as ie,i as we,j as pt,q as b,v as q,ay as ut,Z as gt,a5 as vt,d9 as xt,d_ as ht,d$ as mt,z as n,C as i,B as w,A as B,a4 as yt,m as Ct,K as Pe,r as W,dg as ge,M as Y,E as St,I as ee,J as te,p as wt,F,e0 as Pt,G as Tt,aa as k,bF as X,L as Rt,aF as ve,V as xe,e1 as zt,aI as K,P as Lt,Q as $t,e2 as Bt,h as Wt}from"./index-b37a15c6.js";import{A as At}from"./Add-88db2cb4.js";var _t=/\s/;function Et(e){for(var r=e.length;r--&&_t.test(e.charAt(r)););return r}var Vt=/^\s+/;function kt(e){return e&&e.slice(0,Et(e)+1).replace(Vt,"")}var he=0/0,It=/^[-+]0x[0-9a-f]+$/i,jt=/^0b[01]+$/i,Mt=/^0o[0-7]+$/i,Ft=parseInt;function me(e){if(typeof e=="number")return e;if(dt(e))return he;if(J(e)){var r=typeof e.valueOf=="function"?e.valueOf():e;e=J(r)?r+"":r}if(typeof e!="string")return e===0?e:+e;e=kt(e);var s=jt.test(e);return s||Mt.test(e)?Ft(e.slice(2),s?2:8):It.test(e)?he:+e}var Gt=function(){return bt.Date.now()};const ae=Gt;var Ht="Expected a function",Ot=Math.max,Dt=Math.min;function Nt(e,r,s){var c,p,P,u,f,m,x=0,y=!1,C=!1,h=!0;if(typeof e!="function")throw new TypeError(Ht);r=me(r)||0,J(s)&&(y=!!s.leading,C="maxWait"in s,P=C?Ot(me(s.maxWait)||0,r):P,h="trailing"in s?!!s.trailing:h);function v(d){var L=c,I=p;return c=p=void 0,x=d,u=e.apply(I,L),u}function S(d){return x=d,f=setTimeout(A,r),y?v(d):u}function R(d){var L=d-m,I=d-x,M=r-L;return C?Dt(M,P-I):M}function T(d){var L=d-m,I=d-x;return m===void 0||L>=r||L<0||C&&I>=P}function A(){var d=ae();if(T(d))return z(d);f=setTimeout(A,R(d))}function z(d){return f=void 0,h&&c?v(d):(c=p=void 0,u)}function _(){f!==void 0&&clearTimeout(f),x=0,c=m=p=f=void 0}function V(){return f===void 0?u:z(ae())}function g(){var d=ae(),L=T(d);if(c=arguments,p=this,m=d,L){if(f===void 0)return S(m);if(C)return clearTimeout(f),f=setTimeout(A,r),v(m)}return f===void 0&&(f=setTimeout(A,r)),u}return g.cancel=_,g.flush=V,g}var Ut="Expected a function";function re(e,r,s){var c=!0,p=!0;if(typeof e!="function")throw new TypeError(Ut);return J(s)&&(c="leading"in s?!!s.leading:c,p="trailing"in s?!!s.trailing:p),Nt(e,r,{leading:c,maxWait:r,trailing:p})}const Xt={tabFontSizeSmall:"14px",tabFontSizeMedium:"14px",tabFontSizeLarge:"16px",tabGapSmallLine:"36px",tabGapMediumLine:"36px",tabGapLargeLine:"36px",tabGapSmallLineVertical:"8px",tabGapMediumLineVertical:"8px",tabGapLargeLineVertical:"8px",tabPaddingSmallLine:"6px 0",tabPaddingMediumLine:"10px 0",tabPaddingLargeLine:"14px 0",tabPaddingVerticalSmallLine:"6px 12px",tabPaddingVerticalMediumLine:"8px 16px",tabPaddingVerticalLargeLine:"10px 20px",tabGapSmallBar:"36px",tabGapMediumBar:"36px",tabGapLargeBar:"36px",tabGapSmallBarVertical:"8px",tabGapMediumBarVertical:"8px",tabGapLargeBarVertical:"8px",tabPaddingSmallBar:"4px 0",tabPaddingMediumBar:"6px 0",tabPaddingLargeBar:"10px 0",tabPaddingVerticalSmallBar:"6px 12px",tabPaddingVerticalMediumBar:"8px 16px",tabPaddingVerticalLargeBar:"10px 20px",tabGapSmallCard:"4px",tabGapMediumCard:"4px",tabGapLargeCard:"4px",tabGapSmallCardVertical:"4px",tabGapMediumCardVertical:"4px",tabGapLargeCardVertical:"4px",tabPaddingSmallCard:"8px 16px",tabPaddingMediumCard:"10px 20px",tabPaddingLargeCard:"12px 24px",tabPaddingSmallSegment:"4px 0",tabPaddingMediumSegment:"6px 0",tabPaddingLargeSegment:"8px 0",tabPaddingVerticalLargeSegment:"0 8px",tabPaddingVerticalSmallCard:"8px 12px",tabPaddingVerticalMediumCard:"10px 16px",tabPaddingVerticalLargeCard:"12px 20px",tabPaddingVerticalSmallSegment:"0 4px",tabPaddingVerticalMediumSegment:"0 6px",tabGapSmallSegment:"0",tabGapMediumSegment:"0",tabGapLargeSegment:"0",tabGapSmallSegmentVertical:"0",tabGapMediumSegmentVertical:"0",tabGapLargeSegmentVertical:"0",panePaddingSmall:"8px 0 0 0",panePaddingMedium:"12px 0 0 0",panePaddingLarge:"16px 0 0 0",closeSize:"18px",closeIconSize:"14px"},Kt=e=>{const{textColor2:r,primaryColor:s,textColorDisabled:c,closeIconColor:p,closeIconColorHover:P,closeIconColorPressed:u,closeColorHover:f,closeColorPressed:m,tabColor:x,baseColor:y,dividerColor:C,fontWeight:h,textColor1:v,borderRadius:S,fontSize:R,fontWeightStrong:T}=e;return Object.assign(Object.assign({},Xt),{colorSegment:x,tabFontSizeCard:R,tabTextColorLine:v,tabTextColorActiveLine:s,tabTextColorHoverLine:s,tabTextColorDisabledLine:c,tabTextColorSegment:v,tabTextColorActiveSegment:r,tabTextColorHoverSegment:r,tabTextColorDisabledSegment:c,tabTextColorBar:v,tabTextColorActiveBar:s,tabTextColorHoverBar:s,tabTextColorDisabledBar:c,tabTextColorCard:v,tabTextColorHoverCard:v,tabTextColorActiveCard:s,tabTextColorDisabledCard:c,barColor:s,closeIconColor:p,closeIconColorHover:P,closeIconColorPressed:u,closeColorHover:f,closeColorPressed:m,closeBorderRadius:S,tabColor:x,tabColorSegment:y,tabBorderColor:C,tabFontWeightActive:h,tabFontWeight:h,tabBorderRadius:S,paneTextColor:r,fontWeightStrong:T})},qt={name:"Tabs",common:ct,self:Kt},Jt=qt,se=ft("n-tabs"),Te={tab:[String,Number,Object,Function],name:{type:[String,Number],required:!0},disabled:Boolean,displayDirective:{type:String,default:"if"},closable:{type:Boolean,default:void 0},tabProps:Object,label:[String,Number,Object,Function]},aa=ie({__TAB_PANE__:!0,name:"TabPane",alias:["TabPanel"],props:Te,setup(e){const r=we(se,null);return r||pt("tab-pane","`n-tab-pane` must be placed inside `n-tabs`."),{style:r.paneStyleRef,class:r.paneClassRef,mergedClsPrefix:r.mergedClsPrefixRef}},render(){return b("div",{class:[`${this.mergedClsPrefix}-tab-pane`,this.class],style:this.style},this.$slots)}}),Qt=Object.assign({internalLeftPadded:Boolean,internalAddable:Boolean,internalCreatedByPane:Boolean},mt(Te,["displayDirective"])),oe=ie({__TAB__:!0,inheritAttrs:!1,name:"Tab",props:Qt,setup(e){const{mergedClsPrefixRef:r,valueRef:s,typeRef:c,closableRef:p,tabStyleRef:P,tabChangeIdRef:u,onBeforeLeaveRef:f,triggerRef:m,handleAdd:x,activateTab:y,handleClose:C}=we(se);return{trigger:m,mergedClosable:q(()=>{if(e.internalAddable)return!1;const{closable:h}=e;return h===void 0?p.value:h}),style:P,clsPrefix:r,value:s,type:c,handleClose(h){h.stopPropagation(),!e.disabled&&C(e.name)},activateTab(){if(e.disabled)return;if(e.internalAddable){x();return}const{name:h}=e,v=++u.id;if(h!==s.value){const{value:S}=f;S?Promise.resolve(S(e.name,s.value)).then(R=>{R&&u.id===v&&y(h)}):y(h)}}}},render(){const{internalAddable:e,clsPrefix:r,name:s,disabled:c,label:p,tab:P,value:u,mergedClosable:f,style:m,trigger:x,$slots:{default:y}}=this,C=p??P;return b("div",{class:`${r}-tabs-tab-wrapper`},this.internalLeftPadded?b("div",{class:`${r}-tabs-tab-pad`}):null,b("div",Object.assign({key:s,"data-name":s,"data-disabled":c?!0:void 0},ut({class:[`${r}-tabs-tab`,u===s&&`${r}-tabs-tab--active`,c&&`${r}-tabs-tab--disabled`,f&&`${r}-tabs-tab--closable`,e&&`${r}-tabs-tab--addable`],onClick:x==="click"?this.activateTab:void 0,onMouseenter:x==="hover"?this.activateTab:void 0,style:e?void 0:m},this.internalCreatedByPane?this.tabProps||{}:this.$attrs)),b("span",{class:`${r}-tabs-tab__label`},e?b(gt,null,b("div",{class:`${r}-tabs-tab__height-placeholder`}," "),b(vt,{clsPrefix:r},{default:()=>b(At,null)})):y?y():typeof C=="object"?C:xt(C??s)),f&&this.type==="card"?b(ht,{clsPrefix:r,class:`${r}-tabs-tab__close`,onClick:this.handleClose,disabled:c}):null))}}),Zt=n("tabs",`
 box-sizing: border-box;
 width: 100%;
 display: flex;
 flex-direction: column;
 transition:
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
`,[i("segment-type",[n("tabs-rail",[w("&.transition-disabled","color: red;",[n("tabs-tab",`
 transition: none;
 `)])])]),i("top",[n("tab-pane",`
 padding: var(--n-pane-padding-top) var(--n-pane-padding-right) var(--n-pane-padding-bottom) var(--n-pane-padding-left);
 `)]),i("left",[n("tab-pane",`
 padding: var(--n-pane-padding-right) var(--n-pane-padding-bottom) var(--n-pane-padding-left) var(--n-pane-padding-top);
 `)]),i("left, right",`
 flex-direction: row;
 `,[n("tabs-bar",`
 width: 2px;
 right: 0;
 transition:
 top .2s var(--n-bezier),
 max-height .2s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `),n("tabs-tab",`
 padding: var(--n-tab-padding-vertical); 
 `)]),i("right",`
 flex-direction: row-reverse;
 `,[n("tab-pane",`
 padding: var(--n-pane-padding-left) var(--n-pane-padding-top) var(--n-pane-padding-right) var(--n-pane-padding-bottom);
 `),n("tabs-bar",`
 left: 0;
 `)]),i("bottom",`
 flex-direction: column-reverse;
 justify-content: flex-end;
 `,[n("tab-pane",`
 padding: var(--n-pane-padding-bottom) var(--n-pane-padding-right) var(--n-pane-padding-top) var(--n-pane-padding-left);
 `),n("tabs-bar",`
 top: 0;
 `)]),n("tabs-rail",`
 padding: 3px;
 border-radius: var(--n-tab-border-radius);
 width: 100%;
 background-color: var(--n-color-segment);
 transition: background-color .3s var(--n-bezier);
 display: flex;
 align-items: center;
 `,[n("tabs-tab-wrapper",`
 flex-basis: 0;
 flex-grow: 1;
 display: flex;
 align-items: center;
 justify-content: center;
 `,[n("tabs-tab",`
 overflow: hidden;
 border-radius: var(--n-tab-border-radius);
 width: 100%;
 display: flex;
 align-items: center;
 justify-content: center;
 `,[i("active",`
 font-weight: var(--n-font-weight-strong);
 color: var(--n-tab-text-color-active);
 background-color: var(--n-tab-color-segment);
 box-shadow: 0 1px 3px 0 rgba(0, 0, 0, .08);
 `),w("&:hover",`
 color: var(--n-tab-text-color-hover);
 `)])])]),i("flex",[n("tabs-nav",{width:"100%"},[n("tabs-wrapper",{width:"100%"},[n("tabs-tab",{marginRight:0})])])]),n("tabs-nav",`
 box-sizing: border-box;
 line-height: 1.5;
 display: flex;
 transition: border-color .3s var(--n-bezier);
 `,[B("prefix, suffix",`
 display: flex;
 align-items: center;
 `),B("prefix","padding-right: 16px;"),B("suffix","padding-left: 16px;")]),i("top, bottom",[n("tabs-nav-scroll-wrapper",[w("&::before",`
 top: 0;
 bottom: 0;
 left: 0;
 width: 20px;
 `),w("&::after",`
 top: 0;
 bottom: 0;
 right: 0;
 width: 20px;
 `),i("shadow-start",[w("&::before",`
 box-shadow: inset 10px 0 8px -8px rgba(0, 0, 0, .12);
 `)]),i("shadow-end",[w("&::after",`
 box-shadow: inset -10px 0 8px -8px rgba(0, 0, 0, .12);
 `)])])]),i("left, right",[n("tabs-nav-scroll-wrapper",[w("&::before",`
 top: 0;
 left: 0;
 right: 0;
 height: 20px;
 `),w("&::after",`
 bottom: 0;
 left: 0;
 right: 0;
 height: 20px;
 `),i("shadow-start",[w("&::before",`
 box-shadow: inset 0 10px 8px -8px rgba(0, 0, 0, .12);
 `)]),i("shadow-end",[w("&::after",`
 box-shadow: inset 0 -10px 8px -8px rgba(0, 0, 0, .12);
 `)])])]),n("tabs-nav-scroll-wrapper",`
 flex: 1;
 position: relative;
 overflow: hidden;
 `,[n("tabs-nav-y-scroll",`
 height: 100%;
 width: 100%;
 overflow-y: auto; 
 scrollbar-width: none;
 `,[w("&::-webkit-scrollbar",`
 width: 0;
 height: 0;
 `)]),w("&::before, &::after",`
 transition: box-shadow .3s var(--n-bezier);
 pointer-events: none;
 content: "";
 position: absolute;
 z-index: 1;
 `)]),n("tabs-nav-scroll-content",`
 display: flex;
 position: relative;
 min-width: 100%;
 width: fit-content;
 box-sizing: border-box;
 `),n("tabs-wrapper",`
 display: inline-flex;
 flex-wrap: nowrap;
 position: relative;
 `),n("tabs-tab-wrapper",`
 display: flex;
 flex-wrap: nowrap;
 flex-shrink: 0;
 flex-grow: 0;
 `),n("tabs-tab",`
 cursor: pointer;
 white-space: nowrap;
 flex-wrap: nowrap;
 display: inline-flex;
 align-items: center;
 color: var(--n-tab-text-color);
 font-size: var(--n-tab-font-size);
 background-clip: padding-box;
 padding: var(--n-tab-padding);
 transition:
 box-shadow .3s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[i("disabled",{cursor:"not-allowed"}),B("close",`
 margin-left: 6px;
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `),B("label",`
 display: flex;
 align-items: center;
 `)]),n("tabs-bar",`
 position: absolute;
 bottom: 0;
 height: 2px;
 border-radius: 1px;
 background-color: var(--n-bar-color);
 transition:
 left .2s var(--n-bezier),
 max-width .2s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `,[w("&.transition-disabled",`
 transition: none;
 `),i("disabled",`
 background-color: var(--n-tab-text-color-disabled)
 `)]),n("tabs-pane-wrapper",`
 position: relative;
 overflow: hidden;
 transition: max-height .2s var(--n-bezier);
 `),n("tab-pane",`
 color: var(--n-pane-text-color);
 width: 100%;
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 opacity .2s var(--n-bezier);
 left: 0;
 right: 0;
 top: 0;
 `,[w("&.next-transition-leave-active, &.prev-transition-leave-active, &.next-transition-enter-active, &.prev-transition-enter-active",`
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 transform .2s var(--n-bezier),
 opacity .2s var(--n-bezier);
 `),w("&.next-transition-leave-active, &.prev-transition-leave-active",`
 position: absolute;
 `),w("&.next-transition-enter-from, &.prev-transition-leave-to",`
 transform: translateX(32px);
 opacity: 0;
 `),w("&.next-transition-leave-to, &.prev-transition-enter-from",`
 transform: translateX(-32px);
 opacity: 0;
 `),w("&.next-transition-leave-from, &.next-transition-enter-to, &.prev-transition-leave-from, &.prev-transition-enter-to",`
 transform: translateX(0);
 opacity: 1;
 `)]),n("tabs-tab-pad",`
 box-sizing: border-box;
 width: var(--n-tab-gap);
 flex-grow: 0;
 flex-shrink: 0;
 `),i("line-type, bar-type",[n("tabs-tab",`
 font-weight: var(--n-tab-font-weight);
 box-sizing: border-box;
 vertical-align: bottom;
 `,[w("&:hover",{color:"var(--n-tab-text-color-hover)"}),i("active",`
 color: var(--n-tab-text-color-active);
 font-weight: var(--n-tab-font-weight-active);
 `),i("disabled",{color:"var(--n-tab-text-color-disabled)"})])]),n("tabs-nav",[i("line-type",[i("top",[B("prefix, suffix",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `),n("tabs-nav-scroll-content",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `),n("tabs-bar",`
 bottom: -1px;
 `)]),i("left",[B("prefix, suffix",`
 border-right: 1px solid var(--n-tab-border-color);
 `),n("tabs-nav-scroll-content",`
 border-right: 1px solid var(--n-tab-border-color);
 `),n("tabs-bar",`
 right: -1px;
 `)]),i("right",[B("prefix, suffix",`
 border-left: 1px solid var(--n-tab-border-color);
 `),n("tabs-nav-scroll-content",`
 border-left: 1px solid var(--n-tab-border-color);
 `),n("tabs-bar",`
 left: -1px;
 `)]),i("bottom",[B("prefix, suffix",`
 border-top: 1px solid var(--n-tab-border-color);
 `),n("tabs-nav-scroll-content",`
 border-top: 1px solid var(--n-tab-border-color);
 `),n("tabs-bar",`
 top: -1px;
 `)]),B("prefix, suffix",`
 transition: border-color .3s var(--n-bezier);
 `),n("tabs-nav-scroll-content",`
 transition: border-color .3s var(--n-bezier);
 `),n("tabs-bar",`
 border-radius: 0;
 `)]),i("card-type",[B("prefix, suffix",`
 transition: border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-tab-border-color);
 `),n("tabs-pad",`
 flex-grow: 1;
 transition: border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-tab-border-color);
 `),n("tabs-tab-pad",`
 transition: border-color .3s var(--n-bezier);
 `),n("tabs-tab",`
 font-weight: var(--n-tab-font-weight);
 border: 1px solid var(--n-tab-border-color);
 background-color: var(--n-tab-color);
 box-sizing: border-box;
 position: relative;
 vertical-align: bottom;
 display: flex;
 justify-content: space-between;
 font-size: var(--n-tab-font-size);
 color: var(--n-tab-text-color);
 `,[i("addable",`
 padding-left: 8px;
 padding-right: 8px;
 font-size: 16px;
 `,[B("height-placeholder",`
 width: 0;
 font-size: var(--n-tab-font-size);
 `),yt("disabled",[w("&:hover",`
 color: var(--n-tab-text-color-hover);
 `)])]),i("closable","padding-right: 8px;"),i("active",`
 background-color: #0000;
 font-weight: var(--n-tab-font-weight-active);
 color: var(--n-tab-text-color-active);
 `),i("disabled","color: var(--n-tab-text-color-disabled);")]),n("tabs-scroll-padding","border-bottom: 1px solid var(--n-tab-border-color);")]),i("left, right",[n("tabs-wrapper",`
 flex-direction: column;
 `,[n("tabs-tab-wrapper",`
 flex-direction: column;
 `,[n("tabs-tab-pad",`
 height: var(--n-tab-gap-vertical);
 width: 100%;
 `)])])]),i("top",[i("card-type",[n("tabs-tab",`
 border-top-left-radius: var(--n-tab-border-radius);
 border-top-right-radius: var(--n-tab-border-radius);
 `,[i("active",`
 border-bottom: 1px solid #0000;
 `)]),n("tabs-tab-pad",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `)])]),i("left",[i("card-type",[n("tabs-tab",`
 border-top-left-radius: var(--n-tab-border-radius);
 border-bottom-left-radius: var(--n-tab-border-radius);
 `,[i("active",`
 border-right: 1px solid #0000;
 `)]),n("tabs-tab-pad",`
 border-right: 1px solid var(--n-tab-border-color);
 `)])]),i("right",[i("card-type",[n("tabs-tab",`
 border-top-right-radius: var(--n-tab-border-radius);
 border-bottom-right-radius: var(--n-tab-border-radius);
 `,[i("active",`
 border-left: 1px solid #0000;
 `)]),n("tabs-tab-pad",`
 border-left: 1px solid var(--n-tab-border-color);
 `)])]),i("bottom",[i("card-type",[n("tabs-tab",`
 border-bottom-left-radius: var(--n-tab-border-radius);
 border-bottom-right-radius: var(--n-tab-border-radius);
 `,[i("active",`
 border-top: 1px solid #0000;
 `)]),n("tabs-tab-pad",`
 border-top: 1px solid var(--n-tab-border-color);
 `)])])])]),Yt=Object.assign(Object.assign({},Pe.props),{value:[String,Number],defaultValue:[String,Number],trigger:{type:String,default:"click"},type:{type:String,default:"bar"},closable:Boolean,justifyContent:String,size:{type:String,default:"medium"},placement:{type:String,default:"top"},tabStyle:[String,Object],barWidth:Number,paneClass:String,paneStyle:[String,Object],paneWrapperClass:String,paneWrapperStyle:[String,Object],addable:[Boolean,Object],tabsPadding:{type:Number,default:0},animated:Boolean,onBeforeLeave:Function,onAdd:Function,"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],onClose:[Function,Array],labelSize:String,activeName:[String,Number],onActiveNameChange:[Function,Array]}),ra=ie({name:"Tabs",props:Yt,setup(e,{slots:r}){var s,c,p,P;const{mergedClsPrefixRef:u,inlineThemeDisabled:f}=Ct(e),m=Pe("Tabs","-tabs",Zt,Jt,e,u),x=W(null),y=W(null),C=W(null),h=W(null),v=W(null),S=W(!0),R=W(!0),T=ge(e,["labelSize","size"]),A=ge(e,["activeName","value"]),z=W((c=(s=A.value)!==null&&s!==void 0?s:e.defaultValue)!==null&&c!==void 0?c:r.default?(P=(p=Y(r.default())[0])===null||p===void 0?void 0:p.props)===null||P===void 0?void 0:P.name:null),_=St(A,z),V={id:0},g=q(()=>{if(!(!e.justifyContent||e.type==="card"))return{display:"flex",justifyContent:e.justifyContent}});ee(_,()=>{V.id=0,M(),le()});function d(){var t;const{value:a}=_;return a===null?null:(t=x.value)===null||t===void 0?void 0:t.querySelector(`[data-name="${a}"]`)}function L(t){if(e.type==="card")return;const{value:a}=y;if(a&&t){const o=`${u.value}-tabs-bar--disabled`,{barWidth:l,placement:$}=e;if(t.dataset.disabled==="true"?a.classList.add(o):a.classList.remove(o),["top","bottom"].includes($)){if(I(["top","maxHeight","height"]),typeof l=="number"&&t.offsetWidth>=l){const E=Math.floor((t.offsetWidth-l)/2)+t.offsetLeft;a.style.left=`${E}px`,a.style.maxWidth=`${l}px`}else a.style.left=`${t.offsetLeft}px`,a.style.maxWidth=`${t.offsetWidth}px`;a.style.width="8192px",a.offsetWidth}else{if(I(["left","maxWidth","width"]),typeof l=="number"&&t.offsetHeight>=l){const E=Math.floor((t.offsetHeight-l)/2)+t.offsetTop;a.style.top=`${E}px`,a.style.maxHeight=`${l}px`}else a.style.top=`${t.offsetTop}px`,a.style.maxHeight=`${t.offsetHeight}px`;a.style.height="8192px",a.offsetHeight}}}function I(t){const{value:a}=y;if(a)for(const o of t)a.style[o]=""}function M(){if(e.type==="card")return;const t=d();t&&L(t)}function le(t){var a;const o=(a=v.value)===null||a===void 0?void 0:a.$el;if(!o)return;const l=d();if(!l)return;const{scrollLeft:$,offsetWidth:E}=o,{offsetLeft:H,offsetWidth:N}=l;$>H?o.scrollTo({top:0,left:H,behavior:"smooth"}):H+N>$+E&&o.scrollTo({top:0,left:H+N-E,behavior:"smooth"})}const O=W(null);let Q=0,j=null;function Re(t){const a=O.value;if(a){Q=t.getBoundingClientRect().height;const o=`${Q}px`,l=()=>{a.style.height=o,a.style.maxHeight=o};j?(l(),j(),j=null):j=l}}function ze(t){const a=O.value;if(a){const o=t.getBoundingClientRect().height,l=()=>{document.body.offsetHeight,a.style.maxHeight=`${o}px`,a.style.height=`${Math.max(Q,o)}px`};j?(j(),j=null,l()):j=l}}function Le(){const t=O.value;t&&(t.style.maxHeight="",t.style.height="")}const de={value:[]},be=W("next");function $e(t){const a=_.value;let o="next";for(const l of de.value){if(l===a)break;if(l===t){o="prev";break}}be.value=o,Be(t)}function Be(t){const{onActiveNameChange:a,onUpdateValue:o,"onUpdate:value":l}=e;a&&K(a,t),o&&K(o,t),l&&K(l,t),z.value=t}function We(t){const{onClose:a}=e;a&&K(a,t)}function ce(){const{value:t}=y;if(!t)return;const a="transition-disabled";t.classList.add(a),M(),t.classList.remove(a)}let fe=0;function Ae(t){var a;if(t.contentRect.width===0&&t.contentRect.height===0||fe===t.contentRect.width)return;fe=t.contentRect.width;const{type:o}=e;(o==="line"||o==="bar")&&ce(),o!=="segment"&&Z((a=v.value)===null||a===void 0?void 0:a.$el)}const _e=re(Ae,64);ee([()=>e.justifyContent,()=>e.size],()=>{te(()=>{const{type:t}=e;(t==="line"||t==="bar")&&ce()})});const D=W(!1);function Ee(t){var a;const{target:o,contentRect:{width:l}}=t,$=o.parentElement.offsetWidth;if(!D.value)$<l&&(D.value=!0);else{const{value:E}=h;if(!E)return;$-l>E.$el.offsetWidth&&(D.value=!1)}Z((a=v.value)===null||a===void 0?void 0:a.$el)}const Ve=re(Ee,64);function ke(){const{onAdd:t}=e;t&&t(),te(()=>{const a=d(),{value:o}=v;!a||!o||o.scrollTo({left:a.offsetLeft,top:0,behavior:"smooth"})})}function Z(t){if(!t)return;const{placement:a}=e;if(a==="top"||a==="bottom"){const{scrollLeft:o,scrollWidth:l,offsetWidth:$}=t;S.value=o<=0,R.value=o+$>=l}else{const{scrollTop:o,scrollHeight:l,offsetHeight:$}=t;S.value=o<=0,R.value=o+$>=l}}const Ie=re(t=>{Z(t.target)},64);wt(se,{triggerRef:F(e,"trigger"),tabStyleRef:F(e,"tabStyle"),paneClassRef:F(e,"paneClass"),paneStyleRef:F(e,"paneStyle"),mergedClsPrefixRef:u,typeRef:F(e,"type"),closableRef:F(e,"closable"),valueRef:_,tabChangeIdRef:V,onBeforeLeaveRef:F(e,"onBeforeLeave"),activateTab:$e,handleClose:We,handleAdd:ke}),Pt(()=>{M(),le()}),Tt(()=>{const{value:t}=C;if(!t)return;const{value:a}=u,o=`${a}-tabs-nav-scroll-wrapper--shadow-start`,l=`${a}-tabs-nav-scroll-wrapper--shadow-end`;S.value?t.classList.remove(o):t.classList.add(o),R.value?t.classList.remove(l):t.classList.add(l)});const pe=W(null);ee(_,()=>{if(e.type==="segment"){const t=pe.value;t&&te(()=>{t.classList.add("transition-disabled"),t.offsetWidth,t.classList.remove("transition-disabled")})}});const je={syncBarPosition:()=>{M()}},ue=q(()=>{const{value:t}=T,{type:a}=e,o={card:"Card",bar:"Bar",line:"Line",segment:"Segment"}[a],l=`${t}${o}`,{self:{barColor:$,closeIconColor:E,closeIconColorHover:H,closeIconColorPressed:N,tabColor:Me,tabBorderColor:Fe,paneTextColor:Ge,tabFontWeight:He,tabBorderRadius:Oe,tabFontWeightActive:De,colorSegment:Ne,fontWeightStrong:Ue,tabColorSegment:Xe,closeSize:Ke,closeIconSize:qe,closeColorHover:Je,closeColorPressed:Qe,closeBorderRadius:Ze,[k("panePadding",t)]:U,[k("tabPadding",l)]:Ye,[k("tabPaddingVertical",l)]:et,[k("tabGap",l)]:tt,[k("tabGap",`${l}Vertical`)]:at,[k("tabTextColor",a)]:rt,[k("tabTextColorActive",a)]:nt,[k("tabTextColorHover",a)]:ot,[k("tabTextColorDisabled",a)]:it,[k("tabFontSize",t)]:st},common:{cubicBezierEaseInOut:lt}}=m.value;return{"--n-bezier":lt,"--n-color-segment":Ne,"--n-bar-color":$,"--n-tab-font-size":st,"--n-tab-text-color":rt,"--n-tab-text-color-active":nt,"--n-tab-text-color-disabled":it,"--n-tab-text-color-hover":ot,"--n-pane-text-color":Ge,"--n-tab-border-color":Fe,"--n-tab-border-radius":Oe,"--n-close-size":Ke,"--n-close-icon-size":qe,"--n-close-color-hover":Je,"--n-close-color-pressed":Qe,"--n-close-border-radius":Ze,"--n-close-icon-color":E,"--n-close-icon-color-hover":H,"--n-close-icon-color-pressed":N,"--n-tab-color":Me,"--n-tab-font-weight":He,"--n-tab-font-weight-active":De,"--n-tab-padding":Ye,"--n-tab-padding-vertical":et,"--n-tab-gap":tt,"--n-tab-gap-vertical":at,"--n-pane-padding-left":X(U,"left"),"--n-pane-padding-right":X(U,"right"),"--n-pane-padding-top":X(U,"top"),"--n-pane-padding-bottom":X(U,"bottom"),"--n-font-weight-strong":Ue,"--n-tab-color-segment":Xe}}),G=f?Rt("tabs",q(()=>`${T.value[0]}${e.type[0]}`),ue,e):void 0;return Object.assign({mergedClsPrefix:u,mergedValue:_,renderedNames:new Set,tabsRailElRef:pe,tabsPaneWrapperRef:O,tabsElRef:x,barElRef:y,addTabInstRef:h,xScrollInstRef:v,scrollWrapperElRef:C,addTabFixed:D,tabWrapperStyle:g,handleNavResize:_e,mergedSize:T,handleScroll:Ie,handleTabsResize:Ve,cssVars:f?void 0:ue,themeClass:G==null?void 0:G.themeClass,animationDirection:be,renderNameListRef:de,onAnimationBeforeLeave:Re,onAnimationEnter:ze,onAnimationAfterEnter:Le,onRender:G==null?void 0:G.onRender},je)},render(){const{mergedClsPrefix:e,type:r,placement:s,addTabFixed:c,addable:p,mergedSize:P,renderNameListRef:u,onRender:f,paneWrapperClass:m,paneWrapperStyle:x,$slots:{default:y,prefix:C,suffix:h}}=this;f==null||f();const v=y?Y(y()).filter(g=>g.type.__TAB_PANE__===!0):[],S=y?Y(y()).filter(g=>g.type.__TAB__===!0):[],R=!S.length,T=r==="card",A=r==="segment",z=!T&&!A&&this.justifyContent;u.value=[];const _=()=>{const g=b("div",{style:this.tabWrapperStyle,class:[`${e}-tabs-wrapper`]},z?null:b("div",{class:`${e}-tabs-scroll-padding`,style:{width:`${this.tabsPadding}px`}}),R?v.map((d,L)=>(u.value.push(d.props.name),ne(b(oe,Object.assign({},d.props,{internalCreatedByPane:!0,internalLeftPadded:L!==0&&(!z||z==="center"||z==="start"||z==="end")}),d.children?{default:d.children.tab}:void 0)))):S.map((d,L)=>(u.value.push(d.props.name),ne(L!==0&&!z?Se(d):d))),!c&&p&&T?Ce(p,(R?v.length:S.length)!==0):null,z?null:b("div",{class:`${e}-tabs-scroll-padding`,style:{width:`${this.tabsPadding}px`}}));return b("div",{ref:"tabsElRef",class:`${e}-tabs-nav-scroll-content`},T&&p?b(xe,{onResize:this.handleTabsResize},{default:()=>g}):g,T?b("div",{class:`${e}-tabs-pad`}):null,T?null:b("div",{ref:"barElRef",class:`${e}-tabs-bar`}))},V=A?"top":s;return b("div",{class:[`${e}-tabs`,this.themeClass,`${e}-tabs--${r}-type`,`${e}-tabs--${P}-size`,z&&`${e}-tabs--flex`,`${e}-tabs--${V}`],style:this.cssVars},b("div",{class:[`${e}-tabs-nav--${r}-type`,`${e}-tabs-nav--${V}`,`${e}-tabs-nav`]},ve(C,g=>g&&b("div",{class:`${e}-tabs-nav__prefix`},g)),A?b("div",{class:`${e}-tabs-rail`,ref:"tabsRailElRef"},R?v.map((g,d)=>(u.value.push(g.props.name),b(oe,Object.assign({},g.props,{internalCreatedByPane:!0,internalLeftPadded:d!==0}),g.children?{default:g.children.tab}:void 0))):S.map((g,d)=>(u.value.push(g.props.name),d===0?g:Se(g)))):b(xe,{onResize:this.handleNavResize},{default:()=>b("div",{class:`${e}-tabs-nav-scroll-wrapper`,ref:"scrollWrapperElRef"},["top","bottom"].includes(V)?b(zt,{ref:"xScrollInstRef",onScroll:this.handleScroll},{default:_}):b("div",{class:`${e}-tabs-nav-y-scroll`,onScroll:this.handleScroll},_()))}),c&&p&&T?Ce(p,!0):null,ve(h,g=>g&&b("div",{class:`${e}-tabs-nav__suffix`},g))),R&&(this.animated&&(V==="top"||V==="bottom")?b("div",{ref:"tabsPaneWrapperRef",style:x,class:[`${e}-tabs-pane-wrapper`,m]},ye(v,this.mergedValue,this.renderedNames,this.onAnimationBeforeLeave,this.onAnimationEnter,this.onAnimationAfterEnter,this.animationDirection)):ye(v,this.mergedValue,this.renderedNames)))}});function ye(e,r,s,c,p,P,u){const f=[];return e.forEach(m=>{const{name:x,displayDirective:y,"display-directive":C}=m.props,h=S=>y===S||C===S,v=r===x;if(m.key!==void 0&&(m.key=x),v||h("show")||h("show:lazy")&&s.has(x)){s.has(x)||s.add(x);const S=!h("if");f.push(S?Lt(m,[[$t,v]]):m)}}),u?b(Bt,{name:`${u}-transition`,onBeforeLeave:c,onEnter:p,onAfterEnter:P},{default:()=>f}):f}function Ce(e,r){return b(oe,{ref:"addTabInstRef",key:"__addable",name:"__addable",internalCreatedByPane:!0,internalAddable:!0,internalLeftPadded:r,disabled:typeof e=="object"&&e.disabled})}function Se(e){const r=Wt(e);return r.props?r.props.internalLeftPadded=!0:r.props={internalLeftPadded:!0},r}function ne(e){return Array.isArray(e.dynamicProps)?e.dynamicProps.includes("internalLeftPadded")||e.dynamicProps.push("internalLeftPadded"):e.dynamicProps=["internalLeftPadded"],e}export{ra as N,aa as a};
