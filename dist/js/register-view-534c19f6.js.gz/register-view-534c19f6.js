import{f as K,z as u,a2 as V,A as I,C as x,d as z,m as U,K as T,v as S,L as Z,q as r,Z as J,B as q,a3 as Q,a4 as ee,a5 as re,a6 as te,a7 as ie,a8 as G,r as M,X as ne,o as D,Y as oe,a as g,w as h,b as N,u as m,l as k,a9 as le,_ as se,T as ae,c as L,aa as ce,a0 as O,a1 as B,ab as de,g as X,N as ue}from"./index-655e7691.js";import{r as ge}from"./account-2152036f.js";import{_ as pe}from"./basic-info-form.vue_vue_type_script_setup_true_lang-b1d211fa.js";import{_ as fe}from"./academic-info-form.vue_vue_type_script_setup_true_lang-55d8bd2c.js";import{N as H}from"./Tooltip-f1f05db9.js";import{f as R}from"./get-e43dadf0.js";import"./requests-48f3507b.js";import"./profile-0b40a397.js";import"./FocusDetector-a803f82c.js";import"./Input-ac72a3d6.js";import"./Suffix-f2d73d51.js";import"./Add-f83a5cce.js";import"./Popover-3d045694.js";const he=e=>{const{textColor1:i,dividerColor:n,fontWeightStrong:t}=e;return{textColor:i,color:n,fontWeight:t}},me={name:"Divider",common:K,self:he},ve=me,xe=u("divider",`
 position: relative;
 display: flex;
 width: 100%;
 box-sizing: border-box;
 font-size: 16px;
 color: var(--n-text-color);
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
`,[V("vertical",`
 margin-top: 24px;
 margin-bottom: 24px;
 `,[V("no-title",`
 display: flex;
 align-items: center;
 `)]),I("title",`
 display: flex;
 align-items: center;
 margin-left: 12px;
 margin-right: 12px;
 white-space: nowrap;
 font-weight: var(--n-font-weight);
 `),x("title-position-left",[I("line",[x("left",{width:"28px"})])]),x("title-position-right",[I("line",[x("right",{width:"28px"})])]),x("dashed",[I("line",`
 background-color: #0000;
 height: 0px;
 width: 100%;
 border-style: dashed;
 border-width: 1px 0 0;
 `)]),x("vertical",`
 display: inline-block;
 height: 1em;
 margin: 0 8px;
 vertical-align: middle;
 width: 1px;
 `),I("line",`
 border: none;
 transition: background-color .3s var(--n-bezier), border-color .3s var(--n-bezier);
 height: 1px;
 width: 100%;
 margin: 0;
 `),V("dashed",[I("line",{backgroundColor:"var(--n-color)"})]),x("dashed",[I("line",{borderColor:"var(--n-color)"})]),x("vertical",{backgroundColor:"var(--n-color)"})]),be=Object.assign(Object.assign({},T.props),{titlePlacement:{type:String,default:"center"},dashed:Boolean,vertical:Boolean}),ye=z({name:"Divider",props:be,setup(e){const{mergedClsPrefixRef:i,inlineThemeDisabled:n}=U(e),t=T("Divider","-divider",xe,ve,e,i),l=S(()=>{const{common:{cubicBezierEaseInOut:a},self:{color:o,textColor:d,fontWeight:p}}=t.value;return{"--n-bezier":a,"--n-color":o,"--n-text-color":d,"--n-font-weight":p}}),s=n?Z("divider",void 0,l,e):void 0;return{mergedClsPrefix:i,cssVars:n?void 0:l,themeClass:s==null?void 0:s.themeClass,onRender:s==null?void 0:s.onRender}},render(){var e;const{$slots:i,titlePlacement:n,vertical:t,dashed:l,cssVars:s,mergedClsPrefix:a}=this;return(e=this.onRender)===null||e===void 0||e.call(this),r("div",{role:"separator",class:[`${a}-divider`,this.themeClass,{[`${a}-divider--vertical`]:t,[`${a}-divider--no-title`]:!i.default,[`${a}-divider--dashed`]:l,[`${a}-divider--title-position-${n}`]:i.default&&n}],style:s},t?null:r("div",{class:`${a}-divider__line ${a}-divider__line--left`}),!t&&i.default?r(J,null,r("div",{class:`${a}-divider__title`},this.$slots),r("div",{class:`${a}-divider__line ${a}-divider__line--right`})):null)}}),Ce=e=>{const{infoColor:i,successColor:n,warningColor:t,errorColor:l,textColor2:s,progressRailColor:a,fontSize:o,fontWeight:d}=e;return{fontSize:o,fontSizeCircle:"28px",fontWeightCircle:d,railColor:a,railHeight:"8px",iconSizeCircle:"36px",iconSizeLine:"18px",iconColor:i,iconColorInfo:i,iconColorSuccess:n,iconColorWarning:t,iconColorError:l,textColorCircle:s,textColorLineInner:"rgb(255, 255, 255)",textColorLineOuter:s,fillColor:i,fillColorInfo:i,fillColorSuccess:n,fillColorWarning:t,fillColorError:l,lineBgProcessing:"linear-gradient(90deg, rgba(255, 255, 255, .3) 0%, rgba(255, 255, 255, .5) 100%)"}},we={name:"Progress",common:K,self:Ce},$e=we,ke=q([u("progress",{display:"inline-block"},[u("progress-icon",`
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 `),x("line",`
 width: 100%;
 display: block;
 `,[u("progress-content",`
 display: flex;
 align-items: center;
 `,[u("progress-graph",{flex:1})]),u("progress-custom-content",{marginLeft:"14px"}),u("progress-icon",`
 width: 30px;
 padding-left: 14px;
 height: var(--n-icon-size-line);
 line-height: var(--n-icon-size-line);
 font-size: var(--n-icon-size-line);
 `,[x("as-text",`
 color: var(--n-text-color-line-outer);
 text-align: center;
 width: 40px;
 font-size: var(--n-font-size);
 padding-left: 4px;
 transition: color .3s var(--n-bezier);
 `)])]),x("circle, dashboard",{width:"120px"},[u("progress-custom-content",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 `),u("progress-text",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: inherit;
 font-size: var(--n-font-size-circle);
 color: var(--n-text-color-circle);
 font-weight: var(--n-font-weight-circle);
 transition: color .3s var(--n-bezier);
 white-space: nowrap;
 `),u("progress-icon",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: var(--n-icon-color);
 font-size: var(--n-icon-size-circle);
 `)]),x("multiple-circle",`
 width: 200px;
 color: inherit;
 `,[u("progress-text",`
 font-weight: var(--n-font-weight-circle);
 color: var(--n-text-color-circle);
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `)]),u("progress-content",{position:"relative"}),u("progress-graph",{position:"relative"},[u("progress-graph-circle",[q("svg",{verticalAlign:"bottom"}),u("progress-graph-circle-fill",`
 stroke: var(--n-fill-color);
 transition:
 opacity .3s var(--n-bezier),
 stroke .3s var(--n-bezier),
 stroke-dasharray .3s var(--n-bezier);
 `,[x("empty",{opacity:0})]),u("progress-graph-circle-rail",`
 transition: stroke .3s var(--n-bezier);
 overflow: hidden;
 stroke: var(--n-rail-color);
 `)]),u("progress-graph-line",[x("indicator-inside",[u("progress-graph-line-rail",`
 height: 16px;
 line-height: 16px;
 border-radius: 10px;
 `,[u("progress-graph-line-fill",`
 height: inherit;
 border-radius: 10px;
 `),u("progress-graph-line-indicator",`
 background: #0000;
 white-space: nowrap;
 text-align: right;
 margin-left: 14px;
 margin-right: 14px;
 height: inherit;
 font-size: 12px;
 color: var(--n-text-color-line-inner);
 transition: color .3s var(--n-bezier);
 `)])]),x("indicator-inside-label",`
 height: 16px;
 display: flex;
 align-items: center;
 `,[u("progress-graph-line-rail",`
 flex: 1;
 transition: background-color .3s var(--n-bezier);
 `),u("progress-graph-line-indicator",`
 background: var(--n-fill-color);
 font-size: 12px;
 transform: translateZ(0);
 display: flex;
 vertical-align: middle;
 height: 16px;
 line-height: 16px;
 padding: 0 10px;
 border-radius: 10px;
 position: absolute;
 white-space: nowrap;
 color: var(--n-text-color-line-inner);
 transition:
 right .2s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `)]),u("progress-graph-line-rail",`
 position: relative;
 overflow: hidden;
 height: var(--n-rail-height);
 border-radius: 5px;
 background-color: var(--n-rail-color);
 transition: background-color .3s var(--n-bezier);
 `,[u("progress-graph-line-fill",`
 background: var(--n-fill-color);
 position: relative;
 border-radius: 5px;
 height: inherit;
 width: 100%;
 max-width: 0%;
 transition:
 background-color .3s var(--n-bezier),
 max-width .2s var(--n-bezier);
 `,[x("processing",[q("&::after",`
 content: "";
 background-image: var(--n-line-bg-processing);
 animation: progress-processing-animation 2s var(--n-bezier) infinite;
 `)])])])])])]),q("@keyframes progress-processing-animation",`
 0% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 100%;
 opacity: 1;
 }
 66% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 100% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 `)]),Se={success:r(ee,null),error:r(re,null),warning:r(te,null),info:r(ie,null)},Be=z({name:"ProgressLine",props:{clsPrefix:{type:String,required:!0},percentage:{type:Number,default:0},railColor:String,railStyle:[String,Object],fillColor:String,status:{type:String,required:!0},indicatorPlacement:{type:String,required:!0},indicatorTextColor:String,unit:{type:String,default:"%"},processing:{type:Boolean,required:!0},showIndicator:{type:Boolean,required:!0},height:[String,Number],railBorderRadius:[String,Number],fillBorderRadius:[String,Number]},setup(e,{slots:i}){const n=S(()=>R(e.height)),t=S(()=>e.railBorderRadius!==void 0?R(e.railBorderRadius):e.height!==void 0?R(e.height,{c:.5}):""),l=S(()=>e.fillBorderRadius!==void 0?R(e.fillBorderRadius):e.railBorderRadius!==void 0?R(e.railBorderRadius):e.height!==void 0?R(e.height,{c:.5}):"");return()=>{const{indicatorPlacement:s,railColor:a,railStyle:o,percentage:d,unit:p,indicatorTextColor:b,status:v,showIndicator:y,fillColor:c,processing:$,clsPrefix:f}=e;return r("div",{class:`${f}-progress-content`,role:"none"},r("div",{class:`${f}-progress-graph`,"aria-hidden":!0},r("div",{class:[`${f}-progress-graph-line`,{[`${f}-progress-graph-line--indicator-${s}`]:!0}]},r("div",{class:`${f}-progress-graph-line-rail`,style:[{backgroundColor:a,height:n.value,borderRadius:t.value},o]},r("div",{class:[`${f}-progress-graph-line-fill`,$&&`${f}-progress-graph-line-fill--processing`],style:{maxWidth:`${e.percentage}%`,backgroundColor:c,height:n.value,lineHeight:n.value,borderRadius:l.value}},s==="inside"?r("div",{class:`${f}-progress-graph-line-indicator`,style:{color:b}},d,p):null)))),y&&s==="outside"?r("div",null,i.default?r("div",{class:`${f}-progress-custom-content`,style:{color:b},role:"none"},i.default()):v==="default"?r("div",{role:"none",class:`${f}-progress-icon ${f}-progress-icon--as-text`,style:{color:b}},d,p):r("div",{class:`${f}-progress-icon`,"aria-hidden":!0},r(Q,{clsPrefix:f},{default:()=>Se[v]}))):null)}}}),ze={success:r(ee,null),error:r(re,null),warning:r(te,null),info:r(ie,null)},Pe=z({name:"ProgressCircle",props:{clsPrefix:{type:String,required:!0},status:{type:String,required:!0},strokeWidth:{type:Number,required:!0},fillColor:String,railColor:String,railStyle:[String,Object],percentage:{type:Number,default:0},offsetDegree:{type:Number,default:0},showIndicator:{type:Boolean,required:!0},indicatorTextColor:String,unit:String,viewBoxWidth:{type:Number,required:!0},gapDegree:{type:Number,required:!0},gapOffsetDegree:{type:Number,default:0}},setup(e,{slots:i}){function n(t,l,s){const{gapDegree:a,viewBoxWidth:o,strokeWidth:d}=e,p=50,b=0,v=p,y=0,c=2*p,$=50+d/2,f=`M ${$},${$} m ${b},${v}
      a ${p},${p} 0 1 1 ${y},${-c}
      a ${p},${p} 0 1 1 ${-y},${c}`,P=Math.PI*2*p,_={stroke:s,strokeDasharray:`${t/100*(P-a)}px ${o*8}px`,strokeDashoffset:`-${a/2}px`,transformOrigin:l?"center":void 0,transform:l?`rotate(${l}deg)`:void 0};return{pathString:f,pathStyle:_}}return()=>{const{fillColor:t,railColor:l,strokeWidth:s,offsetDegree:a,status:o,percentage:d,showIndicator:p,indicatorTextColor:b,unit:v,gapOffsetDegree:y,clsPrefix:c}=e,{pathString:$,pathStyle:f}=n(100,0,l),{pathString:P,pathStyle:_}=n(d,a,t),C=100+s;return r("div",{class:`${c}-progress-content`,role:"none"},r("div",{class:`${c}-progress-graph`,"aria-hidden":!0},r("div",{class:`${c}-progress-graph-circle`,style:{transform:y?`rotate(${y}deg)`:void 0}},r("svg",{viewBox:`0 0 ${C} ${C}`},r("g",null,r("path",{class:`${c}-progress-graph-circle-rail`,d:$,"stroke-width":s,"stroke-linecap":"round",fill:"none",style:f})),r("g",null,r("path",{class:[`${c}-progress-graph-circle-fill`,d===0&&`${c}-progress-graph-circle-fill--empty`],d:P,"stroke-width":s,"stroke-linecap":"round",fill:"none",style:_}))))),p?r("div",null,i.default?r("div",{class:`${c}-progress-custom-content`,role:"none"},i.default()):o!=="default"?r("div",{class:`${c}-progress-icon`,"aria-hidden":!0},r(Q,{clsPrefix:c},{default:()=>ze[o]})):r("div",{class:`${c}-progress-text`,style:{color:b},role:"none"},r("span",{class:`${c}-progress-text__percentage`},d),r("span",{class:`${c}-progress-text__unit`},v))):null)}}});function Y(e,i,n=100){return`m ${n/2} ${n/2-e} a ${e} ${e} 0 1 1 0 ${2*e} a ${e} ${e} 0 1 1 0 -${2*e}`}const _e=z({name:"ProgressMultipleCircle",props:{clsPrefix:{type:String,required:!0},viewBoxWidth:{type:Number,required:!0},percentage:{type:Array,default:[0]},strokeWidth:{type:Number,required:!0},circleGap:{type:Number,required:!0},showIndicator:{type:Boolean,required:!0},fillColor:{type:Array,default:()=>[]},railColor:{type:Array,default:()=>[]},railStyle:{type:Array,default:()=>[]}},setup(e,{slots:i}){const n=S(()=>e.percentage.map((l,s)=>`${Math.PI*l/100*(e.viewBoxWidth/2-e.strokeWidth/2*(1+2*s)-e.circleGap*s)*2}, ${e.viewBoxWidth*8}`));return()=>{const{viewBoxWidth:t,strokeWidth:l,circleGap:s,showIndicator:a,fillColor:o,railColor:d,railStyle:p,percentage:b,clsPrefix:v}=e;return r("div",{class:`${v}-progress-content`,role:"none"},r("div",{class:`${v}-progress-graph`,"aria-hidden":!0},r("div",{class:`${v}-progress-graph-circle`},r("svg",{viewBox:`0 0 ${t} ${t}`},b.map((y,c)=>r("g",{key:c},r("path",{class:`${v}-progress-graph-circle-rail`,d:Y(t/2-l/2*(1+2*c)-s*c,l,t),"stroke-width":l,"stroke-linecap":"round",fill:"none",style:[{strokeDashoffset:0,stroke:d[c]},p[c]]}),r("path",{class:[`${v}-progress-graph-circle-fill`,y===0&&`${v}-progress-graph-circle-fill--empty`],d:Y(t/2-l/2*(1+2*c)-s*c,l,t),"stroke-width":l,"stroke-linecap":"round",fill:"none",style:{strokeDasharray:n.value[c],strokeDashoffset:0,stroke:o[c]}})))))),a&&i.default?r("div",null,r("div",{class:`${v}-progress-text`},i.default())):null)}}}),Ie=Object.assign(Object.assign({},T.props),{processing:Boolean,type:{type:String,default:"line"},gapDegree:Number,gapOffsetDegree:Number,status:{type:String,default:"default"},railColor:[String,Array],railStyle:[String,Array],color:[String,Array],viewBoxWidth:{type:Number,default:100},strokeWidth:{type:Number,default:7},percentage:[Number,Array],unit:{type:String,default:"%"},showIndicator:{type:Boolean,default:!0},indicatorPosition:{type:String,default:"outside"},indicatorPlacement:{type:String,default:"outside"},indicatorTextColor:String,circleGap:{type:Number,default:1},height:Number,borderRadius:[String,Number],fillBorderRadius:[String,Number],offsetDegree:Number}),Ne=z({name:"Progress",props:Ie,setup(e){const i=S(()=>e.indicatorPlacement||e.indicatorPosition),n=S(()=>{if(e.gapDegree||e.gapDegree===0)return e.gapDegree;if(e.type==="dashboard")return 75}),{mergedClsPrefixRef:t,inlineThemeDisabled:l}=U(e),s=T("Progress","-progress",ke,$e,e,t),a=S(()=>{const{status:d}=e,{common:{cubicBezierEaseInOut:p},self:{fontSize:b,fontSizeCircle:v,railColor:y,railHeight:c,iconSizeCircle:$,iconSizeLine:f,textColorCircle:P,textColorLineInner:_,textColorLineOuter:C,lineBgProcessing:F,fontWeightCircle:A,[G("iconColor",d)]:j,[G("fillColor",d)]:W}}=s.value;return{"--n-bezier":p,"--n-fill-color":W,"--n-font-size":b,"--n-font-size-circle":v,"--n-font-weight-circle":A,"--n-icon-color":j,"--n-icon-size-circle":$,"--n-icon-size-line":f,"--n-line-bg-processing":F,"--n-rail-color":y,"--n-rail-height":c,"--n-text-color-circle":P,"--n-text-color-line-inner":_,"--n-text-color-line-outer":C}}),o=l?Z("progress",S(()=>e.status[0]),a,e):void 0;return{mergedClsPrefix:t,mergedIndicatorPlacement:i,gapDeg:n,cssVars:l?void 0:a,themeClass:o==null?void 0:o.themeClass,onRender:o==null?void 0:o.onRender}},render(){const{type:e,cssVars:i,indicatorTextColor:n,showIndicator:t,status:l,railColor:s,railStyle:a,color:o,percentage:d,viewBoxWidth:p,strokeWidth:b,mergedIndicatorPlacement:v,unit:y,borderRadius:c,fillBorderRadius:$,height:f,processing:P,circleGap:_,mergedClsPrefix:C,gapDeg:F,gapOffsetDegree:A,themeClass:j,$slots:W,onRender:E}=this;return E==null||E(),r("div",{class:[j,`${C}-progress`,`${C}-progress--${e}`,`${C}-progress--${l}`],style:i,"aria-valuemax":100,"aria-valuemin":0,"aria-valuenow":d,role:e==="circle"||e==="line"||e==="dashboard"?"progressbar":"none"},e==="circle"||e==="dashboard"?r(Pe,{clsPrefix:C,status:l,showIndicator:t,indicatorTextColor:n,railColor:s,fillColor:o,railStyle:a,offsetDegree:this.offsetDegree,percentage:d,viewBoxWidth:p,strokeWidth:b,gapDegree:F===void 0?e==="dashboard"?75:0:F,gapOffsetDegree:A,unit:y},W):e==="line"?r(Be,{clsPrefix:C,status:l,showIndicator:t,indicatorTextColor:n,railColor:s,fillColor:o,railStyle:a,percentage:d,processing:P,indicatorPlacement:v,unit:y,fillBorderRadius:$,railBorderRadius:c,height:f},W):e==="multiple-circle"?r(_e,{clsPrefix:C,strokeWidth:b,railColor:s,fillColor:o,railStyle:a,viewBoxWidth:p,percentage:d,showIndicator:t,circleGap:_},W):null)}}),Re=z({__name:"register-form",emits:["login","success"],setup(e,{emit:i}){const n=M({phone:"",password:"",password2:""}),t=ne(),l=async()=>{try{await t.value.validate();const a=await ge(n.value),o=se();o.username=`用户${n.value.phone}`,o.token=a,i("success")}catch{}},s={phone:[{required:!0,message:"请输入手机号码"},{message:"手机号码不合法",trigger:"blur",validator:(a,o)=>o!==""&&!/^\d{11}$/.test(o)?new Error("手机号码必须是 11 位数字"):!0}],password:[{required:!0,message:"请输入密码"},{min:6,max:20,message:"长度在 6 到 20 个字符",trigger:"blur"}],password2:[{required:!0,message:"请再次输入密码"},{min:6,max:20,message:"长度在 6 到 20 个字符",trigger:"blur"},{validator:(a,o)=>o!==n.value.password?new Error("两次输入密码不一致"):!0,trigger:["blur","input"]}]};return(a,o)=>(D(),oe(J,null,[g(m(k.NButton),{class:"w-full mt-4",onClick:o[0]||(o[0]=()=>i("login"))},{default:h(()=>[N("登录账号")]),_:1}),g(m(ye),{class:"text-[#4c566a] opacity-90"},{default:h(()=>[N("或者")]),_:1}),g(m(k.NForm),{ref_key:"formRef",ref:t,"label-width":80,model:n.value,rules:s},{default:h(()=>[g(m(k.NFormItem),{label:"手机",path:"phone"},{default:h(()=>[g(m(k.NInput),{value:n.value.phone,"onUpdate:value":o[1]||(o[1]=d=>n.value.phone=d),placeholder:"请输入手机"},null,8,["value"])]),_:1}),g(m(k.NFormItem),{label:"密码",path:"password"},{default:h(()=>[g(m(k.NInput),{value:n.value.password,"onUpdate:value":o[2]||(o[2]=d=>n.value.password=d),placeholder:"请输入密码",type:"password","show-password-on":"click"},null,8,["value"])]),_:1}),g(m(k.NFormItem),{label:"确认密码",path:"password2"},{default:h(()=>[g(m(k.NInput),{value:n.value.password2,"onUpdate:value":o[3]||(o[3]=d=>n.value.password2=d),placeholder:"请再次输入密码",type:"password",onKeydown:le(l,["enter"])},null,8,["value","onKeydown"])]),_:1}),g(m(k.NButton),{type:"primary",class:"w-full mt-4",onClick:l},{default:h(()=>[N("注册")]),_:1})]),_:1},8,["model"])],64))}}),De={class:"w-full h-full flex flex-col items-center justify-center bg-[url('/img/register-bg.avif')] bg-center bg-cover"},We=B("div",{class:"flex justify-center"},"注册账号",-1),Fe={class:"flex relative items-center"},qe=B("span",{class:"flex grow justify-center"},"填写基本信息",-1),Le={class:"flex relative items-center"},Oe=B("span",{class:"flex justify-center"},"填写学业信息",-1),Te=B("div",{class:"flex justify-center"},"注册成功",-1);var w=function(e){return e[e.Register=0]="Register",e[e.FillBasicInfo=1]="FillBasicInfo",e[e.FillAcademicInfo=2]="FillAcademicInfo",e[e.Complete=3]="Complete",e}(w||{});const Ae=z({name:"GuidetoWelcome",setup:()=>{const e=M(5),i=setInterval(()=>{e.value--,e.value===0&&(clearInterval(i),X())},1e3);return()=>g("div",{class:"flex flex-col items-center gap-4"},[g("div",null,[e.value,N(" 秒后跳转到主页 ")]),g("div",null,[g(ue,{onClick:()=>{clearInterval(i),X()}},{default:()=>[N("不想等待? 点此跳转")]})])])}}),er=z({__name:"register-view",setup(e){const i=M(w.Register);return(n,t)=>(D(),oe("div",De,[g(ae,{"enter-from-class":"opacity-0","leave-to-class":"opacity-0","enter-active-class":"transition-opacity ease-in-out","leave-active-class":"transition-opacity ease-in-out"},{default:h(()=>[i.value===w.Register?(D(),L(m(O),{key:0,class:"w-fit h-fit m-12 shadow-sm"},{header:h(()=>[We]),default:h(()=>[g(Re,{onLogin:m(ce),onSuccess:t[0]||(t[0]=()=>i.value=w.FillBasicInfo)},null,8,["onLogin"])]),_:1})):i.value===w.FillBasicInfo?(D(),L(m(O),{key:1,class:"w-fit h-fit m-12 shadow-sm"},{header:h(()=>[B("div",Fe,[qe,g(m(H),null,{trigger:h(()=>[B("span",{class:"icon-[material-symbols--skip-next-rounded] absolute right-2 hover:text-[#81a1c1] text-[#434c5e]",onClick:t[1]||(t[1]=l=>i.value=w.FillAcademicInfo)})]),default:h(()=>[N(" 不想填写？ 点此跳过 ")]),_:1})])]),default:h(()=>[g(pe,{onComplete:t[2]||(t[2]=()=>i.value=w.FillAcademicInfo)})]),_:1})):i.value===w.FillAcademicInfo?(D(),L(m(O),{key:2,class:"w-fit h-fit m-12 shadow-sm"},{header:h(()=>[B("div",Le,[Oe,g(m(H),null,{trigger:h(()=>[B("span",{class:"icon-[material-symbols--skip-next-rounded] absolute right-2 hover:text-[#81a1c1] text-[#434c5e]",onClick:t[3]||(t[3]=l=>i.value=w.Complete)})]),default:h(()=>[N(" 不想填写？ 点此跳过 ")]),_:1})])]),default:h(()=>[g(fe,{onComplete:t[4]||(t[4]=()=>i.value=w.Complete)})]),_:1})):i.value===w.Complete?(D(),L(m(O),{key:3,class:"w-fit h-fit m-12 shadow-sm"},{header:h(()=>[Te]),default:h(()=>[g(m(Ae))]),_:1})):de("",!0)]),_:1}),g(m(Ne),{class:"fixed bottom-0","show-indicator":!1,percentage:7+i.value*31,height:4,"border-radius":0},null,8,["percentage"])]))}});export{er as default};
