import{e as Ct,t as _t,f as Rt,h as He,p as Pt,i as zt,j as kt,k as It,d as Z,m as he,r as A,n as Nt,q as y,s as Dt,v as p,x as qe,y as Ge,z as Vt,A as c,B as $,C as d,D as Oe,E as $t,F as Tt,G as Et,H as At,I as de,J as Le,K as Je,L as jt,M as Mt,V as Fe,O as Xe,P as Bt,Q as Ot,T as Lt,R as Ft,S as Xt,U as Q,W as ee,X as Ut,o as Qe,Y as et,a as T,w as B,b as ze,u as E,l as L,Z as Yt,_ as Kt,g as Wt,$ as Zt,a0 as Ht,a1 as pe}from"./index-a8223b55.js";import{l as qt}from"./account-8c910ab9.js";import{c as Gt}from"./_createCompounder-703b8b27.js";import"./requests-237772f0.js";function Jt(e){return Ct(_t(e).toLowerCase())}var Qt=Gt(function(e,a,o){return a=a.toLowerCase(),e+(o?Jt(a):a)});const Ue=Qt,en=e=>({dotSize:"8px",dotColor:"rgba(255, 255, 255, .3)",dotColorActive:"rgba(255, 255, 255, 1)",dotColorFocus:"rgba(255, 255, 255, .5)",dotLineWidth:"16px",dotLineWidthActive:"24px",arrowColor:"#eee"}),tn={name:"Carousel",common:Rt,self:en},nn=tn;function on(e){const{length:a}=e;return a>1&&(e.push(Ye(e[0],0,"append")),e.unshift(Ye(e[a-1],a-1,"prepend"))),e}function Ye(e,a,o){return He(e,{key:`carousel-item-duplicate-${a}-${o}`})}function Ke(e,a,o){return o?e===0?a-3:e===a-1?0:e-1:e}function ke(e,a){return a?e+1:e}function an(e,a,o){return e<0?null:e===0?o?a-1:null:e-1}function sn(e,a,o){return e>a-1?null:e===a-1?o?0:null:e+1}function ln(e,a){return a&&e>3?e-2:e}function We(e){return window.TouchEvent&&e instanceof window.TouchEvent}function Ze(e,a){let{offsetWidth:o,offsetHeight:r}=e;if(a){const f=getComputedStyle(e);o=o-parseFloat(f.getPropertyValue("padding-left"))-parseFloat(f.getPropertyValue("padding-right")),r=r-parseFloat(f.getPropertyValue("padding-top"))-parseFloat(f.getPropertyValue("padding-bottom"))}return{width:o,height:r}}function fe(e,a,o){return e<a?a:e>o?o:e}function rn(e){if(e===void 0)return 0;if(typeof e=="number")return e;const a=/^((\d+)?\.?\d+?)(ms|s)?$/,o=e.match(a);if(o){const[,r,,f="ms"]=o;return Number(r)*(f==="ms"?1:1e3)}return 0}const tt=It("n-carousel-methods"),un=e=>{Pt(tt,e)},Ne=(e="unknown",a="component")=>{const o=zt(tt);return o||kt(e,`\`${a}\` must be placed inside \`n-carousel\`.`),o},cn={total:{type:Number,default:0},currentIndex:{type:Number,default:0},dotType:{type:String,default:"dot"},trigger:{type:String,default:"click"},keyboard:Boolean},dn=Z({name:"CarouselDots",props:cn,setup(e){const{mergedClsPrefixRef:a}=he(e),o=A([]),r=Ne();function f(x,v){switch(x.key){case"Enter":case" ":x.preventDefault(),r.to(v);return}e.keyboard&&h(x)}function m(x){e.trigger==="hover"&&r.to(x)}function C(x){e.trigger==="click"&&r.to(x)}function h(x){var v;if(x.shiftKey||x.altKey||x.ctrlKey||x.metaKey)return;const b=(v=document.activeElement)===null||v===void 0?void 0:v.nodeName.toLowerCase();if(b==="input"||b==="textarea")return;const{code:R}=x,O=R==="PageUp"||R==="ArrowUp",F=R==="PageDown"||R==="ArrowDown",_=R==="PageUp"||R==="ArrowRight",P=R==="PageDown"||R==="ArrowLeft",z=r.isVertical(),j=z?O:_,H=z?F:P;!j&&!H||(x.preventDefault(),j&&!r.isNextDisabled()?(r.next(),S(r.currentIndexRef.value)):H&&!r.isPrevDisabled()&&(r.prev(),S(r.currentIndexRef.value)))}function S(x){var v;(v=o.value[x])===null||v===void 0||v.focus()}return Nt(()=>o.value.length=0),{mergedClsPrefix:a,dotEls:o,handleKeydown:f,handleMouseenter:m,handleClick:C}},render(){const{mergedClsPrefix:e,dotEls:a}=this;return y("div",{class:[`${e}-carousel__dots`,`${e}-carousel__dots--${this.dotType}`],role:"tablist"},Dt(this.total,o=>{const r=o===this.currentIndex;return y("div",{"aria-selected":r,ref:f=>a.push(f),role:"button",tabindex:"0",class:[`${e}-carousel__dot`,r&&`${e}-carousel__dot--active`],key:o,onClick:()=>{this.handleClick(o)},onMouseenter:()=>{this.handleMouseenter(o)},onKeydown:f=>{this.handleKeydown(f,o)}})}))}}),fn=y("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},y("g",{fill:"none"},y("path",{d:"M10.26 3.2a.75.75 0 0 1 .04 1.06L6.773 8l3.527 3.74a.75.75 0 1 1-1.1 1.02l-4-4.25a.75.75 0 0 1 0-1.02l4-4.25a.75.75 0 0 1 1.06-.04z",fill:"currentColor"}))),vn=y("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},y("g",{fill:"none"},y("path",{d:"M5.74 3.2a.75.75 0 0 0-.04 1.06L9.227 8L5.7 11.74a.75.75 0 1 0 1.1 1.02l4-4.25a.75.75 0 0 0 0-1.02l-4-4.25a.75.75 0 0 0-1.06-.04z",fill:"currentColor"}))),hn=Z({name:"CarouselArrow",setup(e){const{mergedClsPrefixRef:a}=he(e),{isVertical:o,isPrevDisabled:r,isNextDisabled:f,prev:m,next:C}=Ne();return{mergedClsPrefix:a,isVertical:o,isPrevDisabled:r,isNextDisabled:f,prev:m,next:C}},render(){const{mergedClsPrefix:e}=this;return y("div",{class:`${e}-carousel__arrow-group`},y("div",{class:[`${e}-carousel__arrow`,this.isPrevDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.prev},fn),y("div",{class:[`${e}-carousel__arrow`,this.isNextDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.next},vn))}}),ve="CarouselItem",pn=e=>{var a;return((a=e.type)===null||a===void 0?void 0:a.name)===ve},gn=Z({name:ve,setup(e){const{mergedClsPrefixRef:a}=he(e),o=Ne(Ue(ve),`n-${Ue(ve)}`),r=A(),f=p(()=>{const{value:v}=r;return v?o.getSlideIndex(v):-1}),m=p(()=>o.isPrev(f.value)),C=p(()=>o.isNext(f.value)),h=p(()=>o.isActive(f.value)),S=p(()=>o.getSlideStyle(f.value));qe(()=>{o.addSlide(r.value)}),Ge(()=>{o.removeSlide(r.value)});function x(v){const{value:b}=f;b!==void 0&&(o==null||o.onCarouselItemClick(b,v))}return{mergedClsPrefix:a,selfElRef:r,isPrev:m,isNext:C,isActive:h,index:f,style:S,handleClick:x}},render(){var e;const{$slots:a,mergedClsPrefix:o,isPrev:r,isNext:f,isActive:m,index:C,style:h}=this,S=[`${o}-carousel__slide`,{[`${o}-carousel__slide--current`]:m,[`${o}-carousel__slide--prev`]:r,[`${o}-carousel__slide--next`]:f}];return y("div",{ref:"selfElRef",class:S,role:"option",tabindex:"-1","data-index":C,"aria-hidden":!m,style:h,onClickCapture:this.handleClick},(e=a.default)===null||e===void 0?void 0:e.call(a,{isPrev:r,isNext:f,isActive:m,index:C}))}}),mn=Vt("carousel",`
 position: relative;
 width: 100%;
 height: 100%;
 touch-action: pan-y;
 overflow: hidden;
`,[c("slides",`
 display: flex;
 width: 100%;
 height: 100%;
 transition-timing-function: var(--n-bezier);
 transition-property: transform;
 `,[c("slide",`
 flex-shrink: 0;
 position: relative;
 width: 100%;
 height: 100%;
 outline: none;
 overflow: hidden;
 `,[$("> img",`
 display: block;
 `)])]),c("dots",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `,[d("dot",[c("dot",`
 height: var(--n-dot-size);
 width: var(--n-dot-size);
 background-color: var(--n-dot-color);
 border-radius: 50%;
 cursor: pointer;
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[$("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),d("active",`
 background-color: var(--n-dot-color-active);
 `)])]),d("line",[c("dot",`
 border-radius: 9999px;
 width: var(--n-dot-line-width);
 height: 4px;
 background-color: var(--n-dot-color);
 cursor: pointer;
 transition:
 width .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[$("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),d("active",`
 width: var(--n-dot-line-width-active);
 background-color: var(--n-dot-color-active);
 `)])])]),c("arrow",`
 transition: background-color .3s var(--n-bezier);
 cursor: pointer;
 height: 28px;
 width: 28px;
 display: flex;
 align-items: center;
 justify-content: center;
 background-color: rgba(255, 255, 255, .2);
 color: var(--n-arrow-color);
 border-radius: 8px;
 user-select: none;
 -webkit-user-select: none;
 font-size: 18px;
 `,[$("svg",`
 height: 1em;
 width: 1em;
 `),$("&:hover",`
 background-color: rgba(255, 255, 255, .3);
 `)]),d("vertical",`
 touch-action: pan-x;
 `,[c("slides",`
 flex-direction: column;
 `),d("fade",[c("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%);
 `)]),d("card",[c("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%) translateZ(-400px);
 `,[d("current",`
 transform: translateY(-50%) translateZ(0);
 `),d("prev",`
 transform: translateY(-100%) translateZ(-200px);
 `),d("next",`
 transform: translateY(0%) translateZ(-200px);
 `)])])]),d("usercontrol",[c("slides",[$(">",[$("div",`
 position: absolute;
 top: 50%;
 left: 50%;
 width: 100%;
 height: 100%;
 transform: translate(-50%, -50%);
 `)])])]),d("left",[c("dots",`
 transform: translateY(-50%);
 top: 50%;
 left: 12px;
 flex-direction: column;
 `,[d("line",[c("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[d("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),c("dot",`
 margin: 4px 0;
 `)]),c("arrow-group",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `),d("vertical",[c("arrow",`
 transform: rotate(90deg);
 `)]),d("show-arrow",[d("bottom",[c("dots",`
 transform: translateX(0);
 bottom: 18px;
 left: 18px;
 `)]),d("top",[c("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),d("left",[c("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),d("right",[c("dots",`
 transform: translateX(0);
 top: 18px;
 right: 18px;
 `)])]),d("left",[c("arrow-group",`
 bottom: 12px;
 left: 12px;
 flex-direction: column;
 `,[$("> *:first-child",`
 margin-bottom: 12px;
 `)])]),d("right",[c("dots",`
 transform: translateY(-50%);
 top: 50%;
 right: 12px;
 flex-direction: column;
 `,[d("line",[c("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[d("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),c("dot",`
 margin: 4px 0;
 `),c("arrow-group",`
 bottom: 12px;
 right: 12px;
 flex-direction: column;
 `,[$("> *:first-child",`
 margin-bottom: 12px;
 `)])]),d("top",[c("dots",`
 transform: translateX(-50%);
 top: 12px;
 left: 50%;
 `,[d("line",[c("dot",`
 margin: 0 4px;
 `)])]),c("dot",`
 margin: 0 4px;
 `),c("arrow-group",`
 top: 12px;
 right: 12px;
 `,[$("> *:first-child",`
 margin-right: 12px;
 `)])]),d("bottom",[c("dots",`
 transform: translateX(-50%);
 bottom: 12px;
 left: 50%;
 `,[d("line",[c("dot",`
 margin: 0 4px;
 `)])]),c("dot",`
 margin: 0 4px;
 `),c("arrow-group",`
 bottom: 12px;
 right: 12px;
 `,[$("> *:first-child",`
 margin-right: 12px;
 `)])]),d("fade",[c("slide",`
 position: absolute;
 opacity: 0;
 transition-property: opacity;
 pointer-events: none;
 `,[d("current",`
 opacity: 1;
 pointer-events: auto;
 `)])]),d("card",[c("slides",`
 perspective: 1000px;
 `),c("slide",`
 position: absolute;
 left: 50%;
 opacity: 0;
 transform: translateX(-50%) translateZ(-400px);
 transition-property: opacity, transform;
 `,[d("current",`
 opacity: 1;
 transform: translateX(-50%) translateZ(0);
 z-index: 1;
 `),d("prev",`
 opacity: 0.4;
 transform: translateX(-100%) translateZ(-200px);
 `),d("next",`
 opacity: 0.4;
 transform: translateX(0%) translateZ(-200px);
 `)])])]),xn=["transitionDuration","transitionTimingFunction"],wn=Object.assign(Object.assign({},Je.props),{defaultIndex:{type:Number,default:0},currentIndex:Number,showArrow:Boolean,dotType:{type:String,default:"dot"},dotPlacement:{type:String,default:"bottom"},slidesPerView:{type:[Number,String],default:1},spaceBetween:{type:Number,default:0},centeredSlides:Boolean,direction:{type:String,default:"horizontal"},autoplay:Boolean,interval:{type:Number,default:5e3},loop:{type:Boolean,default:!0},effect:{type:String,default:"slide"},showDots:{type:Boolean,default:!0},trigger:{type:String,default:"click"},transitionStyle:{type:Object,default:()=>({transitionDuration:"300ms"})},transitionProps:Object,draggable:Boolean,prevSlideStyle:[Object,String],nextSlideStyle:[Object,String],touchable:{type:Boolean,default:!0},mousewheel:Boolean,keyboard:Boolean,"onUpdate:currentIndex":Function,onUpdateCurrentIndex:Function});let Ie=!1;const bn=Z({name:"Carousel",props:wn,setup(e){const{mergedClsPrefixRef:a,inlineThemeDisabled:o}=he(e),r=A(null),f=A(null),m=A([]),C={value:[]},h=p(()=>e.direction==="vertical"),S=p(()=>h.value?"height":"width"),x=p(()=>h.value?"bottom":"right"),v=p(()=>e.effect==="slide"),b=p(()=>e.loop&&e.slidesPerView===1&&v.value),R=p(()=>e.effect==="custom"),O=p(()=>!v.value||e.centeredSlides?1:e.slidesPerView),F=p(()=>R.value?1:e.slidesPerView),_=p(()=>O.value==="auto"||e.slidesPerView==="auto"&&e.centeredSlides),P=A({width:0,height:0}),z=p(()=>{const{value:t}=m;if(!t.length)return[];const{value:n}=_;if(n)return t.map(w=>Ze(w));const{value:s}=F,{value:i}=P,{value:u}=S;let l=i[u];if(s!=="auto"){const{spaceBetween:w}=e,k=l-(s-1)*w,ce=1/Math.max(1,s);l=k*ce}const g=Object.assign(Object.assign({},i),{[u]:l});return t.map(()=>g)}),j=p(()=>{const{value:t}=z;if(!t.length)return[];const{centeredSlides:n,spaceBetween:s}=e,{value:i}=S,{[i]:u}=P.value;let l=0;return t.map(({[i]:g})=>{let w=l;return n&&(w+=(g-u)/2),l+=g+s,w})}),H=A(!1),ge=p(()=>{const{transitionStyle:t}=e;return t?Oe(t,xn):{}}),me=p(()=>R.value?0:rn(ge.value.transitionDuration)),De=p(()=>{const{value:t}=m;if(!t.length)return[];const n=!(_.value||F.value===1),s=g=>{if(n){const{value:w}=S;return{[w]:`${z.value[g][w]}px`}}};if(R.value)return t.map((g,w)=>s(w));const{effect:i,spaceBetween:u}=e,{value:l}=x;return t.reduce((g,w,k)=>{const ce=Object.assign(Object.assign({},s(k)),{[`margin-${l}`]:`${u}px`});return g.push(ce),H.value&&(i==="fade"||i==="card")&&Object.assign(ce,ge.value),g},[])}),I=p(()=>{const{value:t}=O,{length:n}=m.value;if(t!=="auto")return Math.max(n-t,0)+1;{const{value:s}=z,{length:i}=s;if(!i)return n;const{value:u}=j,{value:l}=S,g=P.value[l];let w=s[s.length-1][l],k=i;for(;k>1&&w<g;)k--,w+=u[k]-u[k-1];return fe(k+1,1,i)}}),te=p(()=>ln(I.value,b.value)),nt=ke(e.defaultIndex,b.value),xe=A(Ke(nt,I.value,b.value)),N=$t(Tt(e,"currentIndex"),xe),D=p(()=>ke(N.value,b.value));function q(t){var n,s;t=fe(t,0,I.value-1);const i=Ke(t,I.value,b.value),{value:u}=N;i!==N.value&&(xe.value=i,(n=e["onUpdate:currentIndex"])===null||n===void 0||n.call(e,i,u),(s=e.onUpdateCurrentIndex)===null||s===void 0||s.call(e,i,u))}function ne(t=D.value){return an(t,I.value,e.loop)}function oe(t=D.value){return sn(t,I.value,e.loop)}function ot(t){const n=U(t);return n!==null&&ne()===n}function at(t){const n=U(t);return n!==null&&oe()===n}function Ve(t){return D.value===U(t)}function st(t){return N.value===t}function $e(){return ne()===null}function Te(){return oe()===null}function we(t){const n=fe(ke(t,b.value),0,I.value);(t!==N.value||n!==D.value)&&q(n)}function be(){const t=ne();t!==null&&q(t)}function ae(){const t=oe();t!==null&&q(t)}function lt(){(!V||!b.value)&&be()}function rt(){(!V||!b.value)&&ae()}let V=!1,X=0;const ye=A({});function se(t,n=0){ye.value=Object.assign({},ge.value,{transform:h.value?`translateY(${-t}px)`:`translateX(${-t}px)`,transitionDuration:`${n}ms`})}function G(t=0){v.value?Se(D.value,t):X!==0&&(!V&&t>0&&(V=!0),se(X=0,t))}function Se(t,n){const s=Ee(t);s!==X&&n>0&&(V=!0),X=Ee(D.value),se(s,n)}function Ee(t){let n;return t>=I.value-1?n=Ae():n=j.value[t]||0,n}function Ae(){if(O.value==="auto"){const{value:t}=S,{[t]:n}=P.value,{value:s}=j,i=s[s.length-1];let u;if(i===void 0)u=n;else{const{value:l}=z;u=i+l[l.length-1][t]}return u-n}else{const{value:t}=j;return t[I.value-1]||0}}const J={currentIndexRef:N,to:we,prev:lt,next:rt,isVertical:()=>h.value,isHorizontal:()=>!h.value,isPrev:ot,isNext:at,isActive:Ve,isPrevDisabled:$e,isNextDisabled:Te,getSlideIndex:U,getSlideStyle:ct,addSlide:it,removeSlide:ut,onCarouselItemClick:dt};un(J);function it(t){t&&m.value.push(t)}function ut(t){if(!t)return;const n=U(t);n!==-1&&m.value.splice(n,1)}function U(t){return typeof t=="number"?t:t?m.value.indexOf(t):-1}function ct(t){const n=U(t);if(n!==-1){const s=[De.value[n]],i=J.isPrev(n),u=J.isNext(n);return i&&s.push(e.prevSlideStyle||""),u&&s.push(e.nextSlideStyle||""),Ft(s)}}function dt(t,n){let s=!V&&!ie&&!Pe;e.effect==="card"&&s&&!Ve(t)&&(we(t),s=!1),s||(n.preventDefault(),n.stopPropagation())}let le=null;function re(){le&&(clearInterval(le),le=null)}function Y(){re(),!e.autoplay||te.value<2||(le=window.setInterval(ae,e.interval))}let Ce=0,_e=0,M=0,Re=0,ie=!1,Pe=!1;function je(t){var n;if(Ie||!(!((n=f.value)===null||n===void 0)&&n.contains(Xt(t))))return;Ie=!0,ie=!0,Pe=!1,Re=Date.now(),re(),t.type!=="touchstart"&&!t.target.isContentEditable&&t.preventDefault();const s=We(t)?t.touches[0]:t;h.value?_e=s.clientY:Ce=s.clientX,e.touchable&&(Q("touchmove",document,ue,{passive:!0}),Q("touchend",document,K),Q("touchcancel",document,K)),e.draggable&&(Q("mousemove",document,ue),Q("mouseup",document,K))}function ue(t){const{value:n}=h,{value:s}=S,i=We(t)?t.touches[0]:t,u=n?i.clientY-_e:i.clientX-Ce,l=P.value[s];M=fe(u,-l,l),t.cancelable&&t.preventDefault(),v.value&&se(X-M,0)}function K(){const{value:t}=D;let n=t;if(!V&&M!==0&&v.value){const s=X-M,i=[...j.value.slice(0,I.value-1),Ae()];let u=null;for(let l=0;l<i.length;l++){const g=Math.abs(i[l]-s);if(u!==null&&u<g)break;u=g,n=l}}if(n===t){const s=Date.now()-Re,{value:i}=S,u=P.value[i];M>u/2||M/s>.4?n=ne(t):(M<-u/2||M/s<-.4)&&(n=oe(t))}n!==null&&n!==t?(Pe=!0,q(n),Le(()=>{(!b.value||xe.value!==N.value)&&G(me.value)})):G(me.value),Me(),Y()}function Me(){ie&&(Ie=!1),ie=!1,Ce=0,_e=0,M=0,Re=0,ee("touchmove",document,ue),ee("touchend",document,K),ee("touchcancel",document,K),ee("mousemove",document,ue),ee("mouseup",document,K)}function ft(){if(v.value&&V){const{value:t}=D;Se(t,0)}else Y();v.value&&(ye.value.transitionDuration="0ms"),V=!1}function vt(t){if(t.preventDefault(),V)return;let{deltaX:n,deltaY:s}=t;t.shiftKey&&!n&&(n=s);const i=-1,u=1,l=(n||s)>0?u:i;let g=0,w=0;h.value?w=l:g=l;const k=10;(w*s>=k||g*n>=k)&&(l===u&&!Te()?ae():l===i&&!$e()&&be())}function ht(){P.value=Ze(r.value,!0),Y()}function pt(){var t,n;_.value&&((n=(t=z.effect).scheduler)===null||n===void 0||n.call(t),z.effect.run())}function gt(){e.autoplay&&re()}function mt(){e.autoplay&&Y()}qe(()=>{Et(Y),requestAnimationFrame(()=>H.value=!0)}),Ge(()=>{Me(),re()}),At(()=>{const{value:t}=m,{value:n}=C,s=new Map,i=l=>s.has(l)?s.get(l):-1;let u=!1;for(let l=0;l<t.length;l++){const g=n.findIndex(w=>w.el===t[l]);g!==l&&(u=!0),s.set(t[l],g)}u&&t.sort((l,g)=>i(l)-i(g))}),de(D,(t,n)=>{if(t!==n)if(Y(),v.value){if(b.value&&te.value>2){const{value:s}=I;t===s-2&&n===1?t=0:t===1&&n===s-2&&(t=s-1)}Se(t,me.value)}else G()},{immediate:!0}),de([b,O],()=>void Le(()=>{q(D.value)})),de(j,()=>{v.value&&G()},{deep:!0}),de(v,t=>{t?G():(V=!1,se(X=0))});const xt=p(()=>({onTouchstartPassive:e.touchable?je:void 0,onMousedown:e.draggable?je:void 0,onWheel:e.mousewheel?vt:void 0})),wt=p(()=>Object.assign(Object.assign({},Oe(J,["to","prev","next","isPrevDisabled","isNextDisabled"])),{total:te.value,currentIndex:N.value})),bt=p(()=>({total:te.value,currentIndex:N.value,to:J.to})),yt={getCurrentIndex:()=>N.value,to:we,prev:be,next:ae},St=Je("Carousel","-carousel",mn,nn,e,a),Be=p(()=>{const{common:{cubicBezierEaseInOut:t},self:{dotSize:n,dotColor:s,dotColorActive:i,dotColorFocus:u,dotLineWidth:l,dotLineWidthActive:g,arrowColor:w}}=St.value;return{"--n-bezier":t,"--n-dot-color":s,"--n-dot-color-focus":u,"--n-dot-color-active":i,"--n-dot-size":n,"--n-dot-line-width":l,"--n-dot-line-width-active":g,"--n-arrow-color":w}}),W=o?jt("carousel",void 0,Be,e):void 0;return Object.assign(Object.assign({mergedClsPrefix:a,selfElRef:r,slidesElRef:f,slideVNodes:C,duplicatedable:b,userWantsControl:R,autoSlideSize:_,displayIndex:N,realIndex:D,slideStyles:De,translateStyle:ye,slidesControlListeners:xt,handleTransitionEnd:ft,handleResize:ht,handleSlideResize:pt,handleMouseenter:gt,handleMouseleave:mt,isActive:st,arrowSlotProps:wt,dotSlotProps:bt},yt),{cssVars:o?void 0:Be,themeClass:W==null?void 0:W.themeClass,onRender:W==null?void 0:W.onRender})},render(){var e;const{mergedClsPrefix:a,showArrow:o,userWantsControl:r,slideStyles:f,dotType:m,dotPlacement:C,slidesControlListeners:h,transitionProps:S={},arrowSlotProps:x,dotSlotProps:v,$slots:{default:b,dots:R,arrow:O}}=this,F=b&&Mt(b())||[];let _=yn(F);return _.length||(_=F.map(P=>y(gn,null,{default:()=>He(P)}))),this.duplicatedable&&(_=on(_)),this.slideVNodes.value=_,this.autoSlideSize&&(_=_.map(P=>y(Fe,{onResize:this.handleSlideResize},{default:()=>P}))),(e=this.onRender)===null||e===void 0||e.call(this),y("div",Object.assign({ref:"selfElRef",class:[this.themeClass,`${a}-carousel`,this.direction==="vertical"&&`${a}-carousel--vertical`,this.showArrow&&`${a}-carousel--show-arrow`,`${a}-carousel--${C}`,`${a}-carousel--${this.direction}`,`${a}-carousel--${this.effect}`,r&&`${a}-carousel--usercontrol`],style:this.cssVars},h,{onMouseenter:this.handleMouseenter,onMouseleave:this.handleMouseleave}),y(Fe,{onResize:this.handleResize},{default:()=>y("div",{ref:"slidesElRef",class:`${a}-carousel__slides`,role:"listbox",style:this.translateStyle,onTransitionend:this.handleTransitionEnd},r?_.map((P,z)=>y("div",{style:f[z],key:z},Bt(y(Lt,Object.assign({},S),{default:()=>P}),[[Ot,this.isActive(z)]]))):_)}),this.showDots&&v.total>1&&Xe(R,v,()=>[y(dn,{key:m+C,total:v.total,currentIndex:v.currentIndex,dotType:m,trigger:this.trigger,keyboard:this.keyboard})]),o&&Xe(O,x,()=>[y(hn,null)]))}});function yn(e){return e.reduce((a,o)=>(pn(o)&&a.push(o),a),[])}const Sn="/jiaowu/img/login-bg/1.avif",Cn="/jiaowu/img/login-bg/2.avif",_n="/jiaowu/img/login-bg/3.avif",Rn=Z({__name:"login-form",emits:["register"],setup(e,{emit:a}){const o=A({phone:"",password:""}),r=Ut(),f=async()=>{try{await r.value.validate();const C=await qt(o.value),h=Kt();h.username=`用户${o.value.phone}`,h.login(C),Wt()}catch{}},m={phone:[{required:!0,message:"请输入手机号码"},{message:"手机号码不合法",trigger:"blur",validator:(C,h)=>h!==""&&!/^\d{11}$/.test(h)?new Error("手机号码必须是 11 位数字"):!0}],password:[{required:!0,message:"请输入密码"},{min:6,max:20,message:"长度在 6 到 20 个字符",trigger:"blur"}]};return(C,h)=>(Qe(),et(Yt,null,[T(E(L.NButton),{class:"w-full mt-4",onClick:h[0]||(h[0]=()=>a("register"))},{default:B(()=>[ze("注册账号")]),_:1}),T(E(L.NDivider),{class:"text-[#4c566a] opacity-90"},{default:B(()=>[ze("或者")]),_:1}),T(E(L.NForm),{ref_key:"formRef",ref:r,"label-width":80,model:o.value,rules:m},{default:B(()=>[T(E(L.NFormItem),{label:"手机号码",path:"phone"},{default:B(()=>[T(E(L.NInput),{value:o.value.phone,"onUpdate:value":h[1]||(h[1]=S=>o.value.phone=S),placeholder:"请输入手机号码"},null,8,["value"])]),_:1}),T(E(L.NFormItem),{label:"密码",path:"password"},{default:B(()=>[T(E(L.NInput),{value:o.value.password,"onUpdate:value":h[2]||(h[2]=S=>o.value.password=S),placeholder:"请输入密码",type:"password","show-password-on":"click"},null,8,["value"])]),_:1}),T(E(L.NButton),{type:"primary",class:"w-full mt-4",onClick:f},{default:B(()=>[ze("登录")]),_:1})]),_:1},8,["model"])],64))}}),Pn={class:"w-full h-full flex justify-end items-center"},zn=pe("img",{src:Sn,class:"w-full h-full"},null,-1),kn=pe("img",{src:Cn,class:"w-full h-full"},null,-1),In=pe("img",{src:_n,class:"w-full h-full"},null,-1),Nn=pe("div",{class:"flex justify-center"},"欢迎来到个性化学习与职业规划系统",-1),En=Z({__name:"login-view",setup(e){return(a,o)=>(Qe(),et("div",Pn,[T(E(bn),{autoplay:!0,"show-dots":!1,class:"absolute -z-10"},{default:B(()=>[zn,kn,In]),_:1}),T(E(Ht),{class:"w-fit h-fit m-12 shadow-2xl","header-style":"font-size: 1rem; line-height: 1.75rem;"},{header:B(()=>[Nn]),default:B(()=>[T(Rn,{onRegister:E(Zt)},null,8,["onRegister"])]),_:1})]))}});export{En as default};
