import{ax as le,f as X,a3 as V,k as ce,z as y,dW as de,B as P,dX as ue,A as O,d as N,m as q,r as L,i as U,v as S,K as k,I as fe,aa as ne,L as Z,dY as ve,x as he,G as me,y as pe,aG as ge,aF as j,q as u,V as be,dZ as xe,C as Q,at as ye,dg as ze,dc as _e,T as Se,aD as we,ar as Ce,Y as ee,a as _,w as $,u as b,ac as $e,o as I,a1 as v,ag as T,a0 as te,b as se,Z as Re,ap as Te,cd as oe,cf as Le,c as Oe}from"./index-b37a15c6.js";import{t as ke,N as je}from"./Tag-03952c6c.js";import{u as Pe,a as Ee,b as Fe,c as Ne,e as Be,f as We,d as Me}from"./installCanvasRenderer-aed07e2a.js";import{i as He}from"./install-a7cd663e.js";import{N as Ve,a as A}from"./Tabs-d9a04238.js";import"./Add-88db2cb4.js";const K=le&&"loading"in document.createElement("img"),Ie=(e={})=>{var o;const{root:t=null}=e;return{hash:`${e.rootMargin||"0px 0px 0px 0px"}-${Array.isArray(e.threshold)?e.threshold.join(","):(o=e.threshold)!==null&&o!==void 0?o:"0"}`,options:Object.assign(Object.assign({},e),{root:(typeof t=="string"?document.querySelector(t):t)||document.documentElement})}},D=new WeakMap,G=new WeakMap,Y=new WeakMap,Ae=(e,o,t)=>{if(!e)return()=>{};const n=Ie(o),{root:l}=n.options;let a;const s=D.get(l);s?a=s:(a=new Map,D.set(l,a));let i,c;a.has(n.hash)?(c=a.get(n.hash),c[1].has(e)||(i=c[0],c[1].add(e),i.observe(e))):(i=new IntersectionObserver(m=>{m.forEach(p=>{if(p.isIntersecting){const w=G.get(p.target),z=Y.get(p.target);w&&w(),z&&(z.value=!0)}})},n.options),i.observe(e),c=[i,new Set([e])],a.set(n.hash,c));let h=!1;const g=()=>{h||(G.delete(e),Y.delete(e),h=!0,c[1].has(e)&&(c[0].unobserve(e),c[1].delete(e)),c[1].size<=0&&a.delete(n.hash),a.size||D.delete(l))};return G.set(e,g),Y.set(e,t),g},Ke=e=>{const{borderRadius:o,avatarColor:t,cardColor:n,fontSize:l,heightTiny:a,heightSmall:s,heightMedium:i,heightLarge:c,heightHuge:h,modalColor:g,popoverColor:m}=e;return{borderRadius:o,fontSize:l,border:`2px solid ${n}`,heightTiny:a,heightSmall:s,heightMedium:i,heightLarge:c,heightHuge:h,color:V(n,t),colorModal:V(g,t),colorPopover:V(m,t)}},De={name:"Avatar",common:X,self:Ke},Ge=De,Ye=ce("n-avatar-group"),Xe=y("avatar",`
 width: var(--n-merged-size);
 height: var(--n-merged-size);
 color: #FFF;
 font-size: var(--n-font-size);
 display: inline-flex;
 position: relative;
 overflow: hidden;
 text-align: center;
 border: var(--n-border);
 border-radius: var(--n-border-radius);
 --n-merged-color: var(--n-color);
 background-color: var(--n-merged-color);
 transition:
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
`,[de(P("&","--n-merged-color: var(--n-color-modal);")),ue(P("&","--n-merged-color: var(--n-color-popover);")),P("img",`
 width: 100%;
 height: 100%;
 `),O("text",`
 white-space: nowrap;
 display: inline-block;
 position: absolute;
 left: 50%;
 top: 50%;
 `),y("icon",`
 vertical-align: bottom;
 font-size: calc(var(--n-merged-size) - 6px);
 `),O("text","line-height: 1.25")]),qe=Object.assign(Object.assign({},k.props),{size:[String,Number],src:String,circle:{type:Boolean,default:void 0},objectFit:String,round:{type:Boolean,default:void 0},bordered:{type:Boolean,default:void 0},onError:Function,fallbackSrc:String,intersectionObserverOptions:Object,lazy:Boolean,onLoad:Function,renderPlaceholder:Function,renderFallback:Function,imgProps:Object,color:String}),Ze=N({name:"Avatar",props:qe,setup(e){const{mergedClsPrefixRef:o,inlineThemeDisabled:t}=q(e),n=L(!1);let l=null;const a=L(null),s=L(null),i=()=>{const{value:r}=a;if(r&&(l===null||l!==r.innerHTML)){l=r.innerHTML;const{value:d}=s;if(d){const{offsetWidth:x,offsetHeight:f}=d,{offsetWidth:C,offsetHeight:W}=r,F=.9,M=Math.min(x/C*F,f/W*F,1);r.style.transform=`translateX(-50%) translateY(-50%) scale(${M})`}}},c=U(Ye,null),h=S(()=>{const{size:r}=e;if(r)return r;const{size:d}=c||{};return d||"medium"}),g=k("Avatar","-avatar",Xe,Ge,e,o),m=U(ke,null),p=S(()=>{if(c)return!0;const{round:r,circle:d}=e;return r!==void 0||d!==void 0?r||d:m?m.roundRef.value:!1}),w=S(()=>c?!0:e.bordered||!1),z=r=>{var d;if(!B.value)return;n.value=!0;const{onError:x,imgProps:f}=e;(d=f==null?void 0:f.onError)===null||d===void 0||d.call(f,r),x&&x(r)};fe(()=>e.src,()=>n.value=!1);const E=S(()=>{const r=h.value,d=p.value,x=w.value,{color:f}=e,{self:{borderRadius:C,fontSize:W,color:F,border:M,colorModal:ae,colorPopover:ie},common:{cubicBezierEaseInOut:re}}=g.value;let H;return typeof r=="number"?H=`${r}px`:H=g.value.self[ne("height",r)],{"--n-font-size":W,"--n-border":x?M:"none","--n-border-radius":d?"50%":C,"--n-color":f||F,"--n-color-modal":f||ae,"--n-color-popover":f||ie,"--n-bezier":re,"--n-merged-size":`var(--n-avatar-size-override, ${H})`}}),R=t?Z("avatar",S(()=>{const r=h.value,d=p.value,x=w.value,{color:f}=e;let C="";return r&&(typeof r=="number"?C+=`a${r}`:C+=r[0]),d&&(C+="b"),x&&(C+="c"),f&&(C+=ve(f)),C}),E,e):void 0,B=L(!e.lazy);he(()=>{if(K)return;let r;const d=me(()=>{r==null||r(),r=void 0,e.lazy&&(r=Ae(s.value,e.intersectionObserverOptions,B))});pe(()=>{d(),r==null||r()})});const J=L(!e.lazy);return{textRef:a,selfRef:s,mergedRoundRef:p,mergedClsPrefix:o,fitTextTransform:i,cssVars:t?void 0:E,themeClass:R==null?void 0:R.themeClass,onRender:R==null?void 0:R.onRender,hasLoadError:n,handleError:z,shouldStartLoading:B,loaded:J,mergedOnLoad:r=>{var d;const{onLoad:x,imgProps:f}=e;x==null||x(r),(d=f==null?void 0:f.onLoad)===null||d===void 0||d.call(f,r),J.value=!0}}},render(){var e,o;const{$slots:t,src:n,mergedClsPrefix:l,lazy:a,onRender:s,mergedOnLoad:i,shouldStartLoading:c,loaded:h,hasLoadError:g}=this;s==null||s();let m;const p=!h&&!g&&(this.renderPlaceholder?this.renderPlaceholder():(o=(e=this.$slots).placeholder)===null||o===void 0?void 0:o.call(e));return this.hasLoadError?m=this.renderFallback?this.renderFallback():ge(t.fallback,()=>[u("img",{src:this.fallbackSrc,style:{objectFit:this.objectFit}})]):m=j(t.default,w=>{if(w)return u(be,{onResize:this.fitTextTransform},{default:()=>u("span",{ref:"textRef",class:`${l}-avatar__text`},w)});if(n){const{imgProps:z}=this;return u("img",Object.assign(Object.assign({},z),{loading:K&&!this.intersectionObserverOptions&&a?"lazy":"eager",src:K||c||h?n:void 0,onLoad:i,"data-image-src":n,onError:this.handleError,style:[z==null?void 0:z.style,{objectFit:this.objectFit},p?{height:"0",width:"0",visibility:"hidden",position:"absolute"}:""]}))}}),u("span",{ref:"selfRef",class:[`${l}-avatar`,this.themeClass],style:this.cssVars},m,a&&p)}}),Je=e=>{const{opacityDisabled:o,heightTiny:t,heightSmall:n,heightMedium:l,heightLarge:a,heightHuge:s,primaryColor:i,fontSize:c}=e;return{fontSize:c,textColor:i,sizeTiny:t,sizeSmall:n,sizeMedium:l,sizeLarge:a,sizeHuge:s,color:i,opacitySpinning:o}},Ue={name:"Spin",common:X,self:Je},Qe=Ue,et=e=>{const{textColor2:o,textColor3:t,fontSize:n,fontWeight:l}=e;return{labelFontSize:n,labelFontWeight:l,valueFontWeight:l,valueFontSize:"24px",labelTextColor:t,valuePrefixTextColor:o,valueSuffixTextColor:o,valueTextColor:o}},tt={name:"Statistic",common:X,self:et},st=tt,ot=P([P("@keyframes spin-rotate",`
 from {
 transform: rotate(0);
 }
 to {
 transform: rotate(360deg);
 }
 `),y("spin-container",{position:"relative"},[y("spin-body",`
 position: absolute;
 top: 50%;
 left: 50%;
 transform: translateX(-50%) translateY(-50%);
 `,[xe()])]),y("spin-body",`
 display: inline-flex;
 align-items: center;
 justify-content: center;
 flex-direction: column;
 `),y("spin",`
 display: inline-flex;
 height: var(--n-size);
 width: var(--n-size);
 font-size: var(--n-size);
 color: var(--n-color);
 `,[Q("rotate",`
 animation: spin-rotate 2s linear infinite;
 `)]),y("spin-description",`
 display: inline-block;
 font-size: var(--n-font-size);
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 margin-top: 8px;
 `),y("spin-content",`
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 pointer-events: all;
 `,[Q("spinning",`
 user-select: none;
 -webkit-user-select: none;
 pointer-events: none;
 opacity: var(--n-opacity-spinning);
 `)])]),nt={small:20,medium:18,large:16},at=Object.assign(Object.assign({},k.props),{description:String,stroke:String,size:{type:[String,Number],default:"medium"},show:{type:Boolean,default:!0},strokeWidth:Number,rotate:{type:Boolean,default:!0},spinning:{type:Boolean,validator:()=>!0,default:void 0}}),it=N({name:"Spin",props:at,setup(e){const{mergedClsPrefixRef:o,inlineThemeDisabled:t}=q(e),n=k("Spin","-spin",ot,Qe,e,o),l=S(()=>{const{size:s}=e,{common:{cubicBezierEaseInOut:i},self:c}=n.value,{opacitySpinning:h,color:g,textColor:m}=c,p=typeof s=="number"?ye(s):c[ne("size",s)];return{"--n-bezier":i,"--n-opacity-spinning":h,"--n-size":p,"--n-color":g,"--n-text-color":m}}),a=t?Z("spin",S(()=>{const{size:s}=e;return typeof s=="number"?String(s):s[0]}),l,e):void 0;return{mergedClsPrefix:o,compitableShow:ze(e,["spinning","show"]),mergedStrokeWidth:S(()=>{const{strokeWidth:s}=e;if(s!==void 0)return s;const{size:i}=e;return nt[typeof i=="number"?"medium":i]}),cssVars:t?void 0:l,themeClass:a==null?void 0:a.themeClass,onRender:a==null?void 0:a.onRender}},render(){var e,o;const{$slots:t,mergedClsPrefix:n,description:l}=this,a=t.icon&&this.rotate,s=(l||t.description)&&u("div",{class:`${n}-spin-description`},l||((e=t.description)===null||e===void 0?void 0:e.call(t))),i=t.icon?u("div",{class:[`${n}-spin-body`,this.themeClass]},u("div",{class:[`${n}-spin`,a&&`${n}-spin--rotate`],style:t.default?"":this.cssVars},t.icon()),s):u("div",{class:[`${n}-spin-body`,this.themeClass]},u(_e,{clsPrefix:n,style:t.default?"":this.cssVars,stroke:this.stroke,"stroke-width":this.mergedStrokeWidth,class:`${n}-spin`}),s);return(o=this.onRender)===null||o===void 0||o.call(this),t.default?u("div",{class:[`${n}-spin-container`,this.themeClass],style:this.cssVars},u("div",{class:[`${n}-spin-content`,this.compitableShow&&`${n}-spin-content--spinning`]},t),u(Se,{name:"fade-in-transition"},{default:()=>this.compitableShow?i:null})):i}}),rt=y("statistic",[O("label",`
 font-weight: var(--n-label-font-weight);
 transition: .3s color var(--n-bezier);
 font-size: var(--n-label-font-size);
 color: var(--n-label-text-color);
 `),y("statistic-value",`
 margin-top: 4px;
 font-weight: var(--n-value-font-weight);
 `,[O("prefix",`
 margin: 0 4px 0 0;
 font-size: var(--n-value-font-size);
 transition: .3s color var(--n-bezier);
 color: var(--n-value-prefix-text-color);
 `,[y("icon",{verticalAlign:"-0.125em"})]),O("content",`
 font-size: var(--n-value-font-size);
 transition: .3s color var(--n-bezier);
 color: var(--n-value-text-color);
 `),O("suffix",`
 margin: 0 0 0 4px;
 font-size: var(--n-value-font-size);
 transition: .3s color var(--n-bezier);
 color: var(--n-value-suffix-text-color);
 `,[y("icon",{verticalAlign:"-0.125em"})])])]),lt=Object.assign(Object.assign({},k.props),{tabularNums:Boolean,label:String,value:[String,Number]}),ct=N({name:"Statistic",props:lt,setup(e){const{mergedClsPrefixRef:o,inlineThemeDisabled:t,mergedRtlRef:n}=q(e),l=k("Statistic","-statistic",rt,st,e,o),a=we("Statistic",n,o),s=S(()=>{const{self:{labelFontWeight:c,valueFontSize:h,valueFontWeight:g,valuePrefixTextColor:m,labelTextColor:p,valueSuffixTextColor:w,valueTextColor:z,labelFontSize:E},common:{cubicBezierEaseInOut:R}}=l.value;return{"--n-bezier":R,"--n-label-font-size":E,"--n-label-font-weight":c,"--n-label-text-color":p,"--n-value-font-weight":g,"--n-value-font-size":h,"--n-value-prefix-text-color":m,"--n-value-suffix-text-color":w,"--n-value-text-color":z}}),i=t?Z("statistic",void 0,s,e):void 0;return{rtlEnabled:a,mergedClsPrefix:o,cssVars:t?void 0:s,themeClass:i==null?void 0:i.themeClass,onRender:i==null?void 0:i.onRender}},render(){var e;const{mergedClsPrefix:o,$slots:{default:t,label:n,prefix:l,suffix:a}}=this;return(e=this.onRender)===null||e===void 0||e.call(this),u("div",{class:[`${o}-statistic`,this.themeClass,this.rtlEnabled&&`${o}-statistic--rtl`],style:this.cssVars},j(n,s=>u("div",{class:`${o}-statistic__label`},this.label||s)),u("div",{class:`${o}-statistic-value`,style:{fontVariantNumeric:this.tabularNums?"tabular-nums":""}},j(l,s=>s&&u("span",{class:`${o}-statistic-value__prefix`},s)),this.value!==void 0?u("span",{class:`${o}-statistic-value__content`},this.value):j(t,s=>s&&u("span",{class:`${o}-statistic-value__content`},s)),j(a,s=>s&&u("span",{class:`${o}-statistic-value__suffix`},s))))}}),dt=async e=>(window.$loading.start(),await new Promise(o=>setTimeout(()=>{window.$loading.finish(),o({name:e,description:"华为创立于1987年，是全球领先的ICT（信息与通信）基础设施和智能终端提供商，我们致力于把数字世界带入每个人、每个家庭、每个组织，构建万物互联的智能世界：让无处不在的联接，成为人人平等的权利；为世界提供最强算力，让云无处不在，让智能无所不及；所有的行业和组织，因强大的数字平台而变得敏捷、高效、生机勃勃；通过AI重新定义体验，让消费者在家居、办公、出行等全场景获得极致的个性化体验。目前华为约有19.4万员工，业务遍及170多个国家和地区，服务30多亿人口。",url:"https://www.baidu.com",tech:[{name:"Java",rate:.5},{name:"Python",rate:.3},{name:"C++",rate:.2}],salary:{min:10,avg:15,max:20,unit:"K"},jobCnt:100,workTime:"上午09:00 - 下午05:30",welfare:["五险一金","年终奖","带薪年假"],updateTime:"2021-07-01",logo:"https://img.bosszhipin.com/beijin/mcs/bar/20200430/4204e9c9f200b00b77fb59d093acd281be1bd4a3bd2a63f070bdbdada9aad826.jpg?x-oss-process=image/resize,w_120,limit_0"})},100))),ut={key:0,class:"sm:p-2 grow flex flex-col"},ft=v("span",{class:"font-bold text-lg"},"企业详情：",-1),vt={class:"flex justify-center items-center w-full h-full"},ht={class:"text-sm"},mt={class:"text-lg"},pt=v("span",{class:"grow"},null,-1),gt=v("span",null,"个",-1),bt=v("h2",null,"企业简介",-1),xt={class:"whitespace-pre-wrap"},yt=v("h2",null,"工作时间及福利",-1),zt={class:"px-2 flex flex-col gap-2"},_t={class:"flex items-center gap-4"},St=v("span",{class:"icon-[ri--time-line]"},null,-1),wt={class:"flex items-center gap-4"},Ct=v("span",{class:"icon-[uil--favorite]"},null,-1),$t=v("h2",null,"相关连接",-1),Rt=v("span",null,"招聘网址：",-1),Tt=["href"],Ft=N({__name:"company-view",props:{company:{}},setup(e){const o=e;Pe([Ee,He,Fe,Ne,Be,We,Me]);const t=L();Ce(()=>dt(o.company).then(a=>t.value=a));const n=S(()=>{var a;return{title:{text:"技术占比",left:"center"},grid:[{left:"5%",width:"40%"},{right:"5%",width:"40%"}],legend:{orient:"vertical",left:"left"},tooltip:{trigger:"item"},series:[{type:"pie",name:"技术占比",radius:["40%","70%"],avoidLabelOverlap:!1,itemStyle:{borderRadius:10,borderWidth:2,borderColor:"#fff"},label:{show:!1,position:"center"},tooltip:{formatter:({value:s,name:i})=>`技术: ${i}<br/>占比: ${(s*100).toFixed(2)}%`},emphasis:{label:{show:!0,fontSize:30,fontWeight:"bold"}},labelLine:{show:!1},data:(a=t.value)==null?void 0:a.tech.sort(({rate:s},{rate:i})=>s-i).map(s=>({name:s.name,value:s.rate}))}]}}),l=S(()=>({title:{text:"薪资分布",left:"center"},tooltip:{trigger:"item"},xAxis:{axisLabel:{formatter:"{value}K"}},yAxis:{type:"category"},series:[{type:"bar",name:"薪资分布",colorBy:"data",data:t.value===void 0?void 0:[[t.value.salary.min,"最少"],[t.value.salary.avg,"平均"],[t.value.salary.max,"最多"]],label:{show:!0,formatter:({value:a})=>`${a[0]}K`,color:"#ffffff"}}]}));return(a,s)=>t.value!==void 0?(I(),ee("div",ut,[_(b(te),{class:"bg-white shadow-sm","content-style":"display: flex; align-items: center; gap: 0.25rem;"},{default:$(()=>[ft,_(b(Ze),{src:t.value.logo,round:"",size:"small"},{placeholder:$(()=>[_(b(it))]),fallback:$(()=>[v("div",vt,[v("span",ht,T(t.value.name.slice(0,1)),1)])]),_:1},8,["src"]),v("span",mt,T(t.value.name),1),pt,_(b(ct),{label:"岗位数量",value:t.value.jobCnt,class:"inline-block"},{suffix:$(()=>[gt]),_:1},8,["value"])]),_:1}),_(b(te),{class:"grow bg-white mt-2 shadow-sm relative"},{default:$(()=>[_(b(Ve),null,{default:$(()=>[_(b(A),{name:"基本情况"},{default:$(()=>[bt,v("p",xt,T(t.value.description),1),yt,v("div",zt,[v("div",_t,[St,se(" "+T(t.value.workTime),1)]),v("div",wt,[Ct,(I(!0),ee(Re,null,Te(t.value.welfare,i=>(I(),Oe(b(je),{key:i,type:"primary"},{default:$(()=>[se(T(i),1)]),_:2},1024))),128))])]),$t,v("div",null,[Rt,v("a",{href:t.value.url,class:"text-cyan-950 hover:text-cyan-700"},T(t.value.url),9,Tt)])]),_:1}),_(b(A),{name:"技术需求"},{default:$(()=>[_(b(oe),{class:"h-96",option:n.value,autoresize:"",onMousedown:s[0]||(s[0]=({name:i})=>b(Le)(i))},null,8,["option"])]),_:1}),_(b(A),{name:"薪资情况"},{default:$(()=>[_(b(oe),{class:"h-96",option:l.value,autoresize:""},null,8,["option"])]),_:1})]),_:1})]),_:1})])):$e("",!0)}});export{Ft as default};
