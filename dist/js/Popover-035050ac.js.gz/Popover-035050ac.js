import{eO as re,dg as ne,eP as Ze,eQ as Ve,eR as ge,eS as er,eT as W,eU as G,eV as We,eW as ue,eX as rr,eY as me,eZ as nr,e_ as Se,e$ as $e,f0 as Y,f1 as tr,f2 as Ae,df as or,f3 as ar,f4 as ir,f5 as sr,f6 as lr,f7 as dr,f8 as ur,f as fr,B as D,z as B,a2 as te,A as oe,C as Z,f9 as cr,d as Ge,m as vr,K as pe,r as L,i as hr,G as Ke,v as j,bp as Oe,fa as gr,Q as pr,L as wr,y as br,I as yr,F as J,S as _e,p as Q,q as S,T as mr,bo as Sr,fb as $r,fc as Ar,fd as Or,fe as Te,ff as _r,aT as Tr,P as Ue,aq as ae,Z as Pr,fg as xr,aE as Cr,E as Er,an as Pe,dk as Mr,fh as xe,h as Rr,fi as Br,aG as Ir,bn as Dr,D as Lr,bm as Fr,au as X}from"./index-a8223b55.js";import{c as zr,t as we,b as ke,g as Nr,d as Hr,f as ie,u as V}from"./get-b412ef1c.js";let se;function Wr(){return se===void 0&&(se=navigator.userAgent.includes("Node.js")||navigator.userAgent.includes("jsdom")),se}var Gr=re(ne,"WeakMap");const fe=Gr;var Kr=Ze(Object.keys,Object);const Ur=Kr;var kr=Object.prototype,jr=kr.hasOwnProperty;function Xr(e){if(!Ve(e))return Ur(e);var r=[];for(var n in Object(e))jr.call(e,n)&&n!="constructor"&&r.push(n);return r}function be(e){return ge(e)?er(e):Xr(e)}function qr(e,r){for(var n=-1,t=r.length,a=e.length;++n<t;)e[a+n]=r[n];return e}function Yr(e,r){for(var n=-1,t=e==null?0:e.length,a=0,o=[];++n<t;){var s=e[n];r(s,n,e)&&(o[a++]=s)}return o}function Jr(){return[]}var Qr=Object.prototype,Zr=Qr.propertyIsEnumerable,Ce=Object.getOwnPropertySymbols,Vr=Ce?function(e){return e==null?[]:(e=Object(e),Yr(Ce(e),function(r){return Zr.call(e,r)}))}:Jr;const en=Vr;function rn(e,r,n){var t=r(e);return W(e)?t:qr(t,n(e))}function Ee(e){return rn(e,be,en)}var nn=re(ne,"DataView");const ce=nn;var tn=re(ne,"Promise");const ve=tn;var on=re(ne,"Set");const he=on;var Me="[object Map]",an="[object Object]",Re="[object Promise]",Be="[object Set]",Ie="[object WeakMap]",De="[object DataView]",sn=G(ce),ln=G(ue),dn=G(ve),un=G(he),fn=G(fe),F=We;(ce&&F(new ce(new ArrayBuffer(1)))!=De||ue&&F(new ue)!=Me||ve&&F(ve.resolve())!=Re||he&&F(new he)!=Be||fe&&F(new fe)!=Ie)&&(F=function(e){var r=We(e),n=r==an?e.constructor:void 0,t=n?G(n):"";if(t)switch(t){case sn:return De;case ln:return Me;case dn:return Re;case un:return Be;case fn:return Ie}return r});const Le=F;var cn="__lodash_hash_undefined__";function vn(e){return this.__data__.set(e,cn),this}function hn(e){return this.__data__.has(e)}function ee(e){var r=-1,n=e==null?0:e.length;for(this.__data__=new rr;++r<n;)this.add(e[r])}ee.prototype.add=ee.prototype.push=vn;ee.prototype.has=hn;function gn(e,r){for(var n=-1,t=e==null?0:e.length;++n<t;)if(r(e[n],n,e))return!0;return!1}function pn(e,r){return e.has(r)}var wn=1,bn=2;function je(e,r,n,t,a,o){var s=n&wn,i=e.length,l=r.length;if(i!=l&&!(s&&l>i))return!1;var u=o.get(e),c=o.get(r);if(u&&c)return u==r&&c==e;var p=-1,v=!0,y=n&bn?new ee:void 0;for(o.set(e,r),o.set(r,e);++p<i;){var m=e[p],f=r[p];if(t)var P=s?t(f,m,p,r,e,o):t(m,f,p,e,r,o);if(P!==void 0){if(P)continue;v=!1;break}if(y){if(!gn(r,function(A,O){if(!pn(y,O)&&(m===A||a(m,A,n,t,o)))return y.push(O)})){v=!1;break}}else if(!(m===f||a(m,f,n,t,o))){v=!1;break}}return o.delete(e),o.delete(r),v}function yn(e){var r=-1,n=Array(e.size);return e.forEach(function(t,a){n[++r]=[a,t]}),n}function mn(e){var r=-1,n=Array(e.size);return e.forEach(function(t){n[++r]=t}),n}var Sn=1,$n=2,An="[object Boolean]",On="[object Date]",_n="[object Error]",Tn="[object Map]",Pn="[object Number]",xn="[object RegExp]",Cn="[object Set]",En="[object String]",Mn="[object Symbol]",Rn="[object ArrayBuffer]",Bn="[object DataView]",Fe=me?me.prototype:void 0,le=Fe?Fe.valueOf:void 0;function In(e,r,n,t,a,o,s){switch(n){case Bn:if(e.byteLength!=r.byteLength||e.byteOffset!=r.byteOffset)return!1;e=e.buffer,r=r.buffer;case Rn:return!(e.byteLength!=r.byteLength||!o(new Se(e),new Se(r)));case An:case On:case Pn:return nr(+e,+r);case _n:return e.name==r.name&&e.message==r.message;case xn:case En:return e==r+"";case Tn:var i=yn;case Cn:var l=t&Sn;if(i||(i=mn),e.size!=r.size&&!l)return!1;var u=s.get(e);if(u)return u==r;t|=$n,s.set(e,r);var c=je(i(e),i(r),t,a,o,s);return s.delete(e),c;case Mn:if(le)return le.call(e)==le.call(r)}return!1}var Dn=1,Ln=Object.prototype,Fn=Ln.hasOwnProperty;function zn(e,r,n,t,a,o){var s=n&Dn,i=Ee(e),l=i.length,u=Ee(r),c=u.length;if(l!=c&&!s)return!1;for(var p=l;p--;){var v=i[p];if(!(s?v in r:Fn.call(r,v)))return!1}var y=o.get(e),m=o.get(r);if(y&&m)return y==r&&m==e;var f=!0;o.set(e,r),o.set(r,e);for(var P=s;++p<l;){v=i[p];var A=e[v],O=r[v];if(t)var z=s?t(O,A,v,r,e,o):t(A,O,v,e,r,o);if(!(z===void 0?A===O||a(A,O,n,t,o):z)){f=!1;break}P||(P=v=="constructor")}if(f&&!P){var E=e.constructor,C=r.constructor;E!=C&&"constructor"in e&&"constructor"in r&&!(typeof E=="function"&&E instanceof E&&typeof C=="function"&&C instanceof C)&&(f=!1)}return o.delete(e),o.delete(r),f}var Nn=1,ze="[object Arguments]",Ne="[object Array]",q="[object Object]",Hn=Object.prototype,He=Hn.hasOwnProperty;function Wn(e,r,n,t,a,o){var s=W(e),i=W(r),l=s?Ne:Le(e),u=i?Ne:Le(r);l=l==ze?q:l,u=u==ze?q:u;var c=l==q,p=u==q,v=l==u;if(v&&$e(e)){if(!$e(r))return!1;s=!0,c=!1}if(v&&!c)return o||(o=new Y),s||tr(e)?je(e,r,n,t,a,o):In(e,r,l,n,t,a,o);if(!(n&Nn)){var y=c&&He.call(e,"__wrapped__"),m=p&&He.call(r,"__wrapped__");if(y||m){var f=y?e.value():e,P=m?r.value():r;return o||(o=new Y),a(f,P,n,t,o)}}return v?(o||(o=new Y),zn(e,r,n,t,a,o)):!1}function ye(e,r,n,t,a){return e===r?!0:e==null||r==null||!Ae(e)&&!Ae(r)?e!==e&&r!==r:Wn(e,r,n,t,ye,a)}var Gn=1,Kn=2;function Un(e,r,n,t){var a=n.length,o=a,s=!t;if(e==null)return!o;for(e=Object(e);a--;){var i=n[a];if(s&&i[2]?i[1]!==e[i[0]]:!(i[0]in e))return!1}for(;++a<o;){i=n[a];var l=i[0],u=e[l],c=i[1];if(s&&i[2]){if(u===void 0&&!(l in e))return!1}else{var p=new Y;if(t)var v=t(u,c,l,e,r,p);if(!(v===void 0?ye(c,u,Gn|Kn,t,p):v))return!1}}return!0}function Xe(e){return e===e&&!or(e)}function kn(e){for(var r=be(e),n=r.length;n--;){var t=r[n],a=e[t];r[n]=[t,a,Xe(a)]}return r}function qe(e,r){return function(n){return n==null?!1:n[e]===r&&(r!==void 0||e in Object(n))}}function jn(e){var r=kn(e);return r.length==1&&r[0][2]?qe(r[0][0],r[0][1]):function(n){return n===e||Un(n,e,r)}}function Xn(e,r){return e!=null&&r in Object(e)}function qn(e,r,n){r=zr(r,e);for(var t=-1,a=r.length,o=!1;++t<a;){var s=we(r[t]);if(!(o=e!=null&&n(e,s)))break;e=e[s]}return o||++t!=a?o:(a=e==null?0:e.length,!!a&&ar(a)&&ir(s,a)&&(W(e)||sr(e)))}function Yn(e,r){return e!=null&&qn(e,r,Xn)}var Jn=1,Qn=2;function Zn(e,r){return ke(e)&&Xe(r)?qe(we(e),r):function(n){var t=Nr(n,e);return t===void 0&&t===r?Yn(n,e):ye(r,t,Jn|Qn)}}function Vn(e){return function(r){return r==null?void 0:r[e]}}function et(e){return function(r){return Hr(r,e)}}function rt(e){return ke(e)?Vn(we(e)):et(e)}function nt(e){return typeof e=="function"?e:e==null?lr:typeof e=="object"?W(e)?Zn(e[0],e[1]):jn(e):rt(e)}function tt(e,r){return e&&dr(e,r,be)}function ot(e,r){return function(n,t){if(n==null)return n;if(!ge(n))return e(n,t);for(var a=n.length,o=r?a:-1,s=Object(n);(r?o--:++o<a)&&t(s[o],o,s)!==!1;);return n}}var at=ot(tt);const it=at;function st(e,r){var n=-1,t=ge(e)?Array(e.length):[];return it(e,function(a,o,s){t[++n]=r(a,o,s)}),t}function lt(e,r){var n=W(e)?ur:st;return n(e,nt(r))}const dt={space:"6px",spaceArrow:"10px",arrowOffset:"10px",arrowOffsetVertical:"10px",arrowHeight:"6px",padding:"8px 14px"},ut=e=>{const{boxShadow2:r,popoverColor:n,textColor2:t,borderRadius:a,fontSize:o,dividerColor:s}=e;return Object.assign(Object.assign({},dt),{fontSize:o,borderRadius:a,color:n,dividerColor:s,textColor:t,boxShadow:r})},ft={name:"Popover",common:fr,self:ut},ct=ft,de={top:"bottom",bottom:"top",left:"right",right:"left"},b="var(--n-arrow-height) * 1.414",vt=D([B("popover",`
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 position: relative;
 font-size: var(--n-font-size);
 color: var(--n-text-color);
 box-shadow: var(--n-box-shadow);
 word-break: break-word;
 `,[D(">",[B("scrollbar",`
 height: inherit;
 max-height: inherit;
 `)]),te("raw",`
 background-color: var(--n-color);
 border-radius: var(--n-border-radius);
 `,[te("scrollable",[te("show-header-or-footer","padding: var(--n-padding);")])]),oe("header",`
 padding: var(--n-padding);
 border-bottom: 1px solid var(--n-divider-color);
 transition: border-color .3s var(--n-bezier);
 `),oe("footer",`
 padding: var(--n-padding);
 border-top: 1px solid var(--n-divider-color);
 transition: border-color .3s var(--n-bezier);
 `),Z("scrollable, show-header-or-footer",[oe("content",`
 padding: var(--n-padding);
 `)])]),B("popover-shared",`
 transform-origin: inherit;
 `,[B("popover-arrow-wrapper",`
 position: absolute;
 overflow: hidden;
 pointer-events: none;
 `,[B("popover-arrow",`
 transition: background-color .3s var(--n-bezier);
 position: absolute;
 display: block;
 width: calc(${b});
 height: calc(${b});
 box-shadow: 0 0 8px 0 rgba(0, 0, 0, .12);
 transform: rotate(45deg);
 background-color: var(--n-color);
 pointer-events: all;
 `)]),D("&.popover-transition-enter-from, &.popover-transition-leave-to",`
 opacity: 0;
 transform: scale(.85);
 `),D("&.popover-transition-enter-to, &.popover-transition-leave-from",`
 transform: scale(1);
 opacity: 1;
 `),D("&.popover-transition-enter-active",`
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier),
 opacity .15s var(--n-bezier-ease-out),
 transform .15s var(--n-bezier-ease-out);
 `),D("&.popover-transition-leave-active",`
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier),
 opacity .15s var(--n-bezier-ease-in),
 transform .15s var(--n-bezier-ease-in);
 `)]),x("top-start",`
 top: calc(${b} / -2);
 left: calc(${R("top-start")} - var(--v-offset-left));
 `),x("top",`
 top: calc(${b} / -2);
 transform: translateX(calc(${b} / -2)) rotate(45deg);
 left: 50%;
 `),x("top-end",`
 top: calc(${b} / -2);
 right: calc(${R("top-end")} + var(--v-offset-left));
 `),x("bottom-start",`
 bottom: calc(${b} / -2);
 left: calc(${R("bottom-start")} - var(--v-offset-left));
 `),x("bottom",`
 bottom: calc(${b} / -2);
 transform: translateX(calc(${b} / -2)) rotate(45deg);
 left: 50%;
 `),x("bottom-end",`
 bottom: calc(${b} / -2);
 right: calc(${R("bottom-end")} + var(--v-offset-left));
 `),x("left-start",`
 left: calc(${b} / -2);
 top: calc(${R("left-start")} - var(--v-offset-top));
 `),x("left",`
 left: calc(${b} / -2);
 transform: translateY(calc(${b} / -2)) rotate(45deg);
 top: 50%;
 `),x("left-end",`
 left: calc(${b} / -2);
 bottom: calc(${R("left-end")} + var(--v-offset-top));
 `),x("right-start",`
 right: calc(${b} / -2);
 top: calc(${R("right-start")} - var(--v-offset-top));
 `),x("right",`
 right: calc(${b} / -2);
 transform: translateY(calc(${b} / -2)) rotate(45deg);
 top: 50%;
 `),x("right-end",`
 right: calc(${b} / -2);
 bottom: calc(${R("right-end")} + var(--v-offset-top));
 `),...lt({top:["right-start","left-start"],right:["top-end","bottom-end"],bottom:["right-end","left-end"],left:["top-start","bottom-start"]},(e,r)=>{const n=["right","left"].includes(r),t=n?"width":"height";return e.map(a=>{const o=a.split("-")[1]==="end",i=`calc((${`var(--v-target-${t}, 0px)`} - ${b}) / 2)`,l=R(a);return D(`[v-placement="${a}"] >`,[B("popover-shared",[Z("center-arrow",[B("popover-arrow",`${r}: calc(max(${i}, ${l}) ${o?"+":"-"} var(--v-offset-${n?"left":"top"}));`)])])])})})]);function R(e){return["top","bottom"].includes(e.split("-")[0])?"var(--n-arrow-offset)":"var(--n-arrow-offset-vertical)"}function x(e,r){const n=e.split("-")[0],t=["top","bottom"].includes(n)?"height: var(--n-space-arrow);":"width: var(--n-space-arrow);";return D(`[v-placement="${e}"] >`,[B("popover-shared",`
 margin-${de[n]}: var(--n-space);
 `,[Z("show-arrow",`
 margin-${de[n]}: var(--n-space-arrow);
 `),Z("overlap",`
 margin: 0;
 `),cr("popover-arrow-wrapper",`
 right: 0;
 left: 0;
 top: 0;
 bottom: 0;
 ${n}: 100%;
 ${de[n]}: auto;
 ${t}
 `,[B("popover-arrow",r)])])])}const Ye=Object.assign(Object.assign({},pe.props),{to:V.propTo,show:Boolean,trigger:String,showArrow:Boolean,delay:Number,duration:Number,raw:Boolean,arrowPointToCenter:Boolean,arrowStyle:[String,Object],displayDirective:String,x:Number,y:Number,flip:Boolean,overlap:Boolean,placement:String,width:[Number,String],keepAliveOnHover:Boolean,scrollable:Boolean,contentStyle:[Object,String],headerStyle:[Object,String],footerStyle:[Object,String],internalDeactivateImmediately:Boolean,animated:Boolean,onClickoutside:Function,internalTrapFocus:Boolean,internalOnAfterLeave:Function,minWidth:Number,maxWidth:Number}),ht=({arrowStyle:e,clsPrefix:r})=>S("div",{key:"__popover-arrow__",class:`${r}-popover-arrow-wrapper`},S("div",{class:`${r}-popover-arrow`,style:e})),gt=Ge({name:"PopoverBody",inheritAttrs:!1,props:Ye,setup(e,{slots:r,attrs:n}){const{namespaceRef:t,mergedClsPrefixRef:a,inlineThemeDisabled:o}=vr(e),s=pe("Popover","-popover",vt,ct,e,a),i=L(null),l=hr("NPopover"),u=L(null),c=L(e.show),p=L(!1);Ke(()=>{const{show:h}=e;h&&!Wr()&&!e.internalDeactivateImmediately&&(p.value=!0)});const v=j(()=>{const{trigger:h,onClickoutside:$}=e,_=[],{positionManuallyRef:{value:g}}=l;return g||(h==="click"&&!$&&_.push([Oe,E,void 0,{capture:!0}]),h==="hover"&&_.push([gr,z])),$&&_.push([Oe,E,void 0,{capture:!0}]),(e.displayDirective==="show"||e.animated&&p.value)&&_.push([pr,e.show]),_}),y=j(()=>{const h=e.width==="trigger"?void 0:ie(e.width),$=[];h&&$.push({width:h});const{maxWidth:_,minWidth:g}=e;return _&&$.push({maxWidth:ie(_)}),g&&$.push({maxWidth:ie(g)}),o||$.push(m.value),$}),m=j(()=>{const{common:{cubicBezierEaseInOut:h,cubicBezierEaseIn:$,cubicBezierEaseOut:_},self:{space:g,spaceArrow:U,padding:k,fontSize:I,textColor:d,dividerColor:w,color:T,boxShadow:N,borderRadius:H,arrowHeight:M,arrowOffset:Je,arrowOffsetVertical:Qe}}=s.value;return{"--n-box-shadow":N,"--n-bezier":h,"--n-bezier-ease-in":$,"--n-bezier-ease-out":_,"--n-font-size":I,"--n-text-color":d,"--n-color":T,"--n-divider-color":w,"--n-border-radius":H,"--n-arrow-height":M,"--n-arrow-offset":Je,"--n-arrow-offset-vertical":Qe,"--n-padding":k,"--n-space":g,"--n-space-arrow":U}}),f=o?wr("popover",void 0,m,e):void 0;l.setBodyInstance({syncPosition:P}),br(()=>{l.setBodyInstance(null)}),yr(J(e,"show"),h=>{e.animated||(h?c.value=!0:c.value=!1)});function P(){var h;(h=i.value)===null||h===void 0||h.syncPosition()}function A(h){e.trigger==="hover"&&e.keepAliveOnHover&&e.show&&l.handleMouseEnter(h)}function O(h){e.trigger==="hover"&&e.keepAliveOnHover&&l.handleMouseLeave(h)}function z(h){e.trigger==="hover"&&!C().contains(_e(h))&&l.handleMouseMoveOutside(h)}function E(h){(e.trigger==="click"&&!C().contains(_e(h))||e.onClickoutside)&&l.handleClickOutside(h)}function C(){return l.getTriggerElement()}Q($r,u),Q(Ar,null),Q(Or,null);function K(){if(f==null||f.onRender(),!(e.displayDirective==="show"||e.show||e.animated&&p.value))return null;let $;const _=l.internalRenderBodyRef.value,{value:g}=a;if(_)$=_([`${g}-popover-shared`,f==null?void 0:f.themeClass.value,e.overlap&&`${g}-popover-shared--overlap`,e.showArrow&&`${g}-popover-shared--show-arrow`,e.arrowPointToCenter&&`${g}-popover-shared--center-arrow`],u,y.value,A,O);else{const{value:U}=l.extraClassRef,{internalTrapFocus:k}=e,I=!Te(r.header)||!Te(r.footer),d=()=>{var w;const T=I?S(Pr,null,ae(r.header,M=>M?S("div",{class:`${g}-popover__header`,style:e.headerStyle},M):null),ae(r.default,M=>M?S("div",{class:`${g}-popover__content`,style:e.contentStyle},r):null),ae(r.footer,M=>M?S("div",{class:`${g}-popover__footer`,style:e.footerStyle},M):null)):e.scrollable?(w=r.default)===null||w===void 0?void 0:w.call(r):S("div",{class:`${g}-popover__content`,style:e.contentStyle},r),N=e.scrollable?S(xr,{contentClass:I?void 0:`${g}-popover__content`,contentStyle:I?void 0:e.contentStyle},{default:()=>T}):T,H=e.showArrow?ht({arrowStyle:e.arrowStyle,clsPrefix:g}):null;return[N,H]};$=S("div",Tr({class:[`${g}-popover`,`${g}-popover-shared`,f==null?void 0:f.themeClass.value,U.map(w=>`${g}-${w}`),{[`${g}-popover--scrollable`]:e.scrollable,[`${g}-popover--show-header-or-footer`]:I,[`${g}-popover--raw`]:e.raw,[`${g}-popover-shared--overlap`]:e.overlap,[`${g}-popover-shared--show-arrow`]:e.showArrow,[`${g}-popover-shared--center-arrow`]:e.arrowPointToCenter}],ref:u,style:y.value,onKeydown:l.handleKeydown,onMouseenter:A,onMouseleave:O},n),k?S(_r,{active:e.show,autoFocus:!0},{default:d}):d())}return Ue($,v.value)}return{displayed:p,namespace:t,isMounted:l.isMountedRef,zIndex:l.zIndexRef,followerRef:i,adjustedTo:V(e),followerEnabled:c,renderContentNode:K}},render(){return S(Sr,{ref:"followerRef",zIndex:this.zIndex,show:this.show,enabled:this.followerEnabled,to:this.adjustedTo,x:this.x,y:this.y,flip:this.flip,placement:this.placement,containerClass:this.namespace,overlap:this.overlap,width:this.width==="trigger"?"target":void 0,teleportDisabled:this.adjustedTo===V.tdkey},{default:()=>this.animated?S(mr,{name:"popover-transition",appear:this.isMounted,onEnter:()=>{this.followerEnabled=!0},onAfterLeave:()=>{var e;(e=this.internalOnAfterLeave)===null||e===void 0||e.call(this),this.followerEnabled=!1,this.displayed=!1}},{default:this.renderContentNode}):this.renderContentNode()})}}),pt=Object.keys(Ye),wt={focus:["onFocus","onBlur"],click:["onClick"],hover:["onMouseenter","onMouseleave"],manual:[],nested:["onFocus","onBlur","onMouseenter","onMouseleave","onClick"]};function bt(e,r,n){wt[r].forEach(t=>{e.props?e.props=Object.assign({},e.props):e.props={};const a=e.props[t],o=n[t];a?e.props[t]=(...s)=>{a(...s),o(...s)}:e.props[t]=o})}const yt={show:{type:Boolean,default:void 0},defaultShow:Boolean,showArrow:{type:Boolean,default:!0},trigger:{type:String,default:"hover"},delay:{type:Number,default:100},duration:{type:Number,default:100},raw:Boolean,placement:{type:String,default:"top"},x:Number,y:Number,arrowPointToCenter:Boolean,disabled:Boolean,getDisabled:Function,displayDirective:{type:String,default:"if"},arrowStyle:[String,Object],flip:{type:Boolean,default:!0},animated:{type:Boolean,default:!0},width:{type:[Number,String],default:void 0},overlap:Boolean,keepAliveOnHover:{type:Boolean,default:!0},zIndex:Number,to:V.propTo,scrollable:Boolean,contentStyle:[Object,String],headerStyle:[Object,String],footerStyle:[Object,String],onClickoutside:Function,"onUpdate:show":[Function,Array],onUpdateShow:[Function,Array],internalDeactivateImmediately:Boolean,internalSyncTargetWithParent:Boolean,internalInheritedEventHandlers:{type:Array,default:()=>[]},internalTrapFocus:Boolean,internalExtraClass:{type:Array,default:()=>[]},onShow:[Function,Array],onHide:[Function,Array],arrow:{type:Boolean,default:void 0},minWidth:Number,maxWidth:Number},mt=Object.assign(Object.assign(Object.assign({},pe.props),yt),{internalOnAfterLeave:Function,internalRenderBody:Function}),At=Ge({name:"Popover",inheritAttrs:!1,props:mt,__popover__:!0,setup(e){const r=Cr(),n=L(null),t=j(()=>e.show),a=L(e.defaultShow),o=Er(t,a),s=Pe(()=>e.disabled?!1:o.value),i=()=>{if(e.disabled)return!0;const{getDisabled:d}=e;return!!(d!=null&&d())},l=()=>i()?!1:o.value,u=Mr(e,["arrow","showArrow"]),c=j(()=>e.overlap?!1:u.value);let p=null;const v=L(null),y=L(null),m=Pe(()=>e.x!==void 0&&e.y!==void 0);function f(d){const{"onUpdate:show":w,onUpdateShow:T,onShow:N,onHide:H}=e;a.value=d,w&&X(w,d),T&&X(T,d),d&&N&&X(N,!0),d&&H&&X(H,!1)}function P(){p&&p.syncPosition()}function A(){const{value:d}=v;d&&(window.clearTimeout(d),v.value=null)}function O(){const{value:d}=y;d&&(window.clearTimeout(d),y.value=null)}function z(){const d=i();if(e.trigger==="focus"&&!d){if(l())return;f(!0)}}function E(){const d=i();if(e.trigger==="focus"&&!d){if(!l())return;f(!1)}}function C(){const d=i();if(e.trigger==="hover"&&!d){if(O(),v.value!==null||l())return;const w=()=>{f(!0),v.value=null},{delay:T}=e;T===0?w():v.value=window.setTimeout(w,T)}}function K(){const d=i();if(e.trigger==="hover"&&!d){if(A(),y.value!==null||!l())return;const w=()=>{f(!1),y.value=null},{duration:T}=e;T===0?w():y.value=window.setTimeout(w,T)}}function h(){K()}function $(d){var w;l()&&(e.trigger==="click"&&(A(),O(),f(!1)),(w=e.onClickoutside)===null||w===void 0||w.call(e,d))}function _(){if(e.trigger==="click"&&!i()){A(),O();const d=!l();f(d)}}function g(d){e.internalTrapFocus&&d.key==="Escape"&&(A(),O(),f(!1))}function U(d){a.value=d}function k(){var d;return(d=n.value)===null||d===void 0?void 0:d.targetRef}function I(d){p=d}return Q("NPopover",{getTriggerElement:k,handleKeydown:g,handleMouseEnter:C,handleMouseLeave:K,handleClickOutside:$,handleMouseMoveOutside:h,setBodyInstance:I,positionManuallyRef:m,isMountedRef:r,zIndexRef:J(e,"zIndex"),extraClassRef:J(e,"internalExtraClass"),internalRenderBodyRef:J(e,"internalRenderBody")}),Ke(()=>{o.value&&i()&&f(!1)}),{binderInstRef:n,positionManually:m,mergedShowConsideringDisabledProp:s,uncontrolledShow:a,mergedShowArrow:c,getMergedShow:l,setShow:U,handleClick:_,handleMouseEnter:C,handleMouseLeave:K,handleFocus:z,handleBlur:E,syncPosition:P}},render(){var e;const{positionManually:r,$slots:n}=this;let t,a=!1;if(!r&&(n.activator?t=xe(n,"activator"):t=xe(n,"trigger"),t)){t=Rr(t),t=t.type===Br?S("span",[t]):t;const o={onClick:this.handleClick,onMouseenter:this.handleMouseEnter,onMouseleave:this.handleMouseLeave,onFocus:this.handleFocus,onBlur:this.handleBlur};if(!((e=t.type)===null||e===void 0)&&e.__popover__)a=!0,t.props||(t.props={internalSyncTargetWithParent:!0,internalInheritedEventHandlers:[]}),t.props.internalSyncTargetWithParent=!0,t.props.internalInheritedEventHandlers?t.props.internalInheritedEventHandlers=[o,...t.props.internalInheritedEventHandlers]:t.props.internalInheritedEventHandlers=[o];else{const{internalInheritedEventHandlers:s}=this,i=[o,...s],l={onBlur:u=>{i.forEach(c=>{c.onBlur(u)})},onFocus:u=>{i.forEach(c=>{c.onFocus(u)})},onClick:u=>{i.forEach(c=>{c.onClick(u)})},onMouseenter:u=>{i.forEach(c=>{c.onMouseenter(u)})},onMouseleave:u=>{i.forEach(c=>{c.onMouseleave(u)})}};bt(t,s?"nested":r?"manual":this.trigger,l)}}return S(Fr,{ref:"binderInstRef",syncTarget:!a,syncTargetWithParent:this.internalSyncTargetWithParent},{default:()=>{this.mergedShowConsideringDisabledProp;const o=this.getMergedShow();return[this.internalTrapFocus&&o?Ue(S("div",{style:{position:"fixed",inset:0}}),[[Ir,{enabled:o,zIndex:this.zIndex}]]):null,r?null:S(Dr,null,{default:()=>t}),S(gt,Lr(this.$props,pt,Object.assign(Object.assign({},this.$attrs),{showArrow:this.mergedShowArrow,show:o})),{default:()=>{var s,i;return(i=(s=this.$slots).default)===null||i===void 0?void 0:i.call(s)},header:()=>{var s,i;return(i=(s=this.$slots).header)===null||i===void 0?void 0:i.call(s)},footer:()=>{var s,i;return(i=(s=this.$slots).footer)===null||i===void 0?void 0:i.call(s)}})]}})}});export{At as N,yt as a,ct as p};
