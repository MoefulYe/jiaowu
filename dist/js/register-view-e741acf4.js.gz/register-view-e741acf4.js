import{a2 as se,f as G,a3 as ne,d as P,m as X,K as W,r as q,v as k,q as r,z as u,a4 as V,A as R,C as b,L as Z,Z as J,B as L,a5 as Q,a6 as ee,a7 as re,a8 as te,a9 as ie,aa as H,X as le,o as D,Y as oe,a as f,w as h,b as I,u as m,l as S,ab as ae,_ as ce,c as j,ac as de,ad as ue,a0 as F,a1 as B,g as Y,N as ge}from"./index-b37a15c6.js";import{r as pe}from"./account-633ab8fe.js";import{_ as fe}from"./basic-info-form.vue_vue_type_script_setup_true_lang-36be984e.js";import{_ as he}from"./academic-info-form.vue_vue_type_script_setup_true_lang-794fcf2d.js";import{p as me,N as ve,a as be}from"./Popover-15ced32b.js";import{f as N}from"./FocusDetector-61977e59.js";import"./requests-71421ce6.js";import"./profile-aa82aac7.js";import"./Input-ebc85a91.js";import"./Suffix-f44f4662.js";import"./Add-88db2cb4.js";const xe={padding:"8px 14px"},ye=e=>{const{borderRadius:i,boxShadow2:o,baseColor:t}=e;return Object.assign(Object.assign({},xe),{borderRadius:i,boxShadow:o,color:ne(t,"rgba(0, 0, 0, .85)"),textColor:t})},Ce=se({name:"Tooltip",common:G,peers:{Popover:me},self:ye}),we=Ce,$e=Object.assign(Object.assign({},be),W.props),K=P({name:"Tooltip",props:$e,__popover__:!0,setup(e){const{mergedClsPrefixRef:i}=X(e),o=W("Tooltip","-tooltip",void 0,we,e,i),t=q(null);return Object.assign(Object.assign({},{syncPosition(){t.value.syncPosition()},setShow(l){t.value.setShow(l)}}),{popoverRef:t,mergedTheme:o,popoverThemeOverrides:k(()=>o.value.self)})},render(){const{mergedTheme:e,internalExtraClass:i}=this;return r(ve,Object.assign(Object.assign({},this.$props),{theme:e.peers.Popover,themeOverrides:e.peerOverrides.Popover,builtinThemeOverrides:this.popoverThemeOverrides,internalExtraClass:i.concat("tooltip"),ref:"popoverRef"}),this.$slots)}}),ke=e=>{const{textColor1:i,dividerColor:o,fontWeightStrong:t}=e;return{textColor:i,color:o,fontWeight:t}},Se={name:"Divider",common:G,self:ke},Pe=Se,Be=u("divider",`
 position: relative;
 display: flex;
 width: 100%;
 box-sizing: border-box;
 font-size: 16px;
 color: var(--n-text-color);
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
`,[V("vertical",`
 margin-top: 24px;
 margin-bottom: 24px;
 `,[V("no-title",`
 display: flex;
 align-items: center;
 `)]),R("title",`
 display: flex;
 align-items: center;
 margin-left: 12px;
 margin-right: 12px;
 white-space: nowrap;
 font-weight: var(--n-font-weight);
 `),b("title-position-left",[R("line",[b("left",{width:"28px"})])]),b("title-position-right",[R("line",[b("right",{width:"28px"})])]),b("dashed",[R("line",`
 background-color: #0000;
 height: 0px;
 width: 100%;
 border-style: dashed;
 border-width: 1px 0 0;
 `)]),b("vertical",`
 display: inline-block;
 height: 1em;
 margin: 0 8px;
 vertical-align: middle;
 width: 1px;
 `),R("line",`
 border: none;
 transition: background-color .3s var(--n-bezier), border-color .3s var(--n-bezier);
 height: 1px;
 width: 100%;
 margin: 0;
 `),V("dashed",[R("line",{backgroundColor:"var(--n-color)"})]),b("dashed",[R("line",{borderColor:"var(--n-color)"})]),b("vertical",{backgroundColor:"var(--n-color)"})]),_e=Object.assign(Object.assign({},W.props),{titlePlacement:{type:String,default:"center"},dashed:Boolean,vertical:Boolean}),ze=P({name:"Divider",props:_e,setup(e){const{mergedClsPrefixRef:i,inlineThemeDisabled:o}=X(e),t=W("Divider","-divider",Be,Pe,e,i),n=k(()=>{const{common:{cubicBezierEaseInOut:a},self:{color:s,textColor:d,fontWeight:g}}=t.value;return{"--n-bezier":a,"--n-color":s,"--n-text-color":d,"--n-font-weight":g}}),l=o?Z("divider",void 0,n,e):void 0;return{mergedClsPrefix:i,cssVars:o?void 0:n,themeClass:l==null?void 0:l.themeClass,onRender:l==null?void 0:l.onRender}},render(){var e;const{$slots:i,titlePlacement:o,vertical:t,dashed:n,cssVars:l,mergedClsPrefix:a}=this;return(e=this.onRender)===null||e===void 0||e.call(this),r("div",{role:"separator",class:[`${a}-divider`,this.themeClass,{[`${a}-divider--vertical`]:t,[`${a}-divider--no-title`]:!i.default,[`${a}-divider--dashed`]:n,[`${a}-divider--title-position-${o}`]:i.default&&o}],style:l},t?null:r("div",{class:`${a}-divider__line ${a}-divider__line--left`}),!t&&i.default?r(J,null,r("div",{class:`${a}-divider__title`},this.$slots),r("div",{class:`${a}-divider__line ${a}-divider__line--right`})):null)}}),Re=e=>{const{infoColor:i,successColor:o,warningColor:t,errorColor:n,textColor2:l,progressRailColor:a,fontSize:s,fontWeight:d}=e;return{fontSize:s,fontSizeCircle:"28px",fontWeightCircle:d,railColor:a,railHeight:"8px",iconSizeCircle:"36px",iconSizeLine:"18px",iconColor:i,iconColorInfo:i,iconColorSuccess:o,iconColorWarning:t,iconColorError:n,textColorCircle:l,textColorLineInner:"rgb(255, 255, 255)",textColorLineOuter:l,fillColor:i,fillColorInfo:i,fillColorSuccess:o,fillColorWarning:t,fillColorError:n,lineBgProcessing:"linear-gradient(90deg, rgba(255, 255, 255, .3) 0%, rgba(255, 255, 255, .5) 100%)"}},Ie={name:"Progress",common:G,self:Re},Ne=Ie,De=L([u("progress",{display:"inline-block"},[u("progress-icon",`
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 `),b("line",`
 width: 100%;
 display: block;
 `,[u("progress-content",`
 display: flex;
 align-items: center;
 `,[u("progress-graph",{flex:1})]),u("progress-custom-content",{marginLeft:"14px"}),u("progress-icon",`
 width: 30px;
 padding-left: 14px;
 height: var(--n-icon-size-line);
 line-height: var(--n-icon-size-line);
 font-size: var(--n-icon-size-line);
 `,[b("as-text",`
 color: var(--n-text-color-line-outer);
 text-align: center;
 width: 40px;
 font-size: var(--n-font-size);
 padding-left: 4px;
 transition: color .3s var(--n-bezier);
 `)])]),b("circle, dashboard",{width:"120px"},[u("progress-custom-content",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 `),u("progress-text",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: inherit;
 font-size: var(--n-font-size-circle);
 color: var(--n-text-color-circle);
 font-weight: var(--n-font-weight-circle);
 transition: color .3s var(--n-bezier);
 white-space: nowrap;
 `),u("progress-icon",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: var(--n-icon-color);
 font-size: var(--n-icon-size-circle);
 `)]),b("multiple-circle",`
 width: 200px;
 color: inherit;
 `,[u("progress-text",`
 font-weight: var(--n-font-weight-circle);
 color: var(--n-text-color-circle);
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `)]),u("progress-content",{position:"relative"}),u("progress-graph",{position:"relative"},[u("progress-graph-circle",[L("svg",{verticalAlign:"bottom"}),u("progress-graph-circle-fill",`
 stroke: var(--n-fill-color);
 transition:
 opacity .3s var(--n-bezier),
 stroke .3s var(--n-bezier),
 stroke-dasharray .3s var(--n-bezier);
 `,[b("empty",{opacity:0})]),u("progress-graph-circle-rail",`
 transition: stroke .3s var(--n-bezier);
 overflow: hidden;
 stroke: var(--n-rail-color);
 `)]),u("progress-graph-line",[b("indicator-inside",[u("progress-graph-line-rail",`
 height: 16px;
 line-height: 16px;
 border-radius: 10px;
 `,[u("progress-graph-line-fill",`
 height: inherit;
 border-radius: 10px;
 `),u("progress-graph-line-indicator",`
 background: #0000;
 white-space: nowrap;
 text-align: right;
 margin-left: 14px;
 margin-right: 14px;
 height: inherit;
 font-size: 12px;
 color: var(--n-text-color-line-inner);
 transition: color .3s var(--n-bezier);
 `)])]),b("indicator-inside-label",`
 height: 16px;
 display: flex;
 align-items: center;
 `,[u("progress-graph-line-rail",`
 flex: 1;
 transition: background-color .3s var(--n-bezier);
 `),u("progress-graph-line-indicator",`
 background: var(--n-fill-color);
 font-size: 12px;
 transform: translateZ(0);
 display: flex;
 vertical-align: middle;
 height: 16px;
 line-height: 16px;
 padding: 0 10px;
 border-radius: 10px;
 position: absolute;
 white-space: nowrap;
 color: var(--n-text-color-line-inner);
 transition:
 right .2s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `)]),u("progress-graph-line-rail",`
 position: relative;
 overflow: hidden;
 height: var(--n-rail-height);
 border-radius: 5px;
 background-color: var(--n-rail-color);
 transition: background-color .3s var(--n-bezier);
 `,[u("progress-graph-line-fill",`
 background: var(--n-fill-color);
 position: relative;
 border-radius: 5px;
 height: inherit;
 width: 100%;
 max-width: 0%;
 transition:
 background-color .3s var(--n-bezier),
 max-width .2s var(--n-bezier);
 `,[b("processing",[L("&::after",`
 content: "";
 background-image: var(--n-line-bg-processing);
 animation: progress-processing-animation 2s var(--n-bezier) infinite;
 `)])])])])])]),L("@keyframes progress-processing-animation",`
 0% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 100%;
 opacity: 1;
 }
 66% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 100% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 `)]),We={success:r(ee,null),error:r(re,null),warning:r(te,null),info:r(ie,null)},Oe=P({name:"ProgressLine",props:{clsPrefix:{type:String,required:!0},percentage:{type:Number,default:0},railColor:String,railStyle:[String,Object],fillColor:String,status:{type:String,required:!0},indicatorPlacement:{type:String,required:!0},indicatorTextColor:String,unit:{type:String,default:"%"},processing:{type:Boolean,required:!0},showIndicator:{type:Boolean,required:!0},height:[String,Number],railBorderRadius:[String,Number],fillBorderRadius:[String,Number]},setup(e,{slots:i}){const o=k(()=>N(e.height)),t=k(()=>e.railBorderRadius!==void 0?N(e.railBorderRadius):e.height!==void 0?N(e.height,{c:.5}):""),n=k(()=>e.fillBorderRadius!==void 0?N(e.fillBorderRadius):e.railBorderRadius!==void 0?N(e.railBorderRadius):e.height!==void 0?N(e.height,{c:.5}):"");return()=>{const{indicatorPlacement:l,railColor:a,railStyle:s,percentage:d,unit:g,indicatorTextColor:x,status:v,showIndicator:y,fillColor:c,processing:$,clsPrefix:p}=e;return r("div",{class:`${p}-progress-content`,role:"none"},r("div",{class:`${p}-progress-graph`,"aria-hidden":!0},r("div",{class:[`${p}-progress-graph-line`,{[`${p}-progress-graph-line--indicator-${l}`]:!0}]},r("div",{class:`${p}-progress-graph-line-rail`,style:[{backgroundColor:a,height:o.value,borderRadius:t.value},s]},r("div",{class:[`${p}-progress-graph-line-fill`,$&&`${p}-progress-graph-line-fill--processing`],style:{maxWidth:`${e.percentage}%`,backgroundColor:c,height:o.value,lineHeight:o.value,borderRadius:n.value}},l==="inside"?r("div",{class:`${p}-progress-graph-line-indicator`,style:{color:x}},d,g):null)))),y&&l==="outside"?r("div",null,i.default?r("div",{class:`${p}-progress-custom-content`,style:{color:x},role:"none"},i.default()):v==="default"?r("div",{role:"none",class:`${p}-progress-icon ${p}-progress-icon--as-text`,style:{color:x}},d,g):r("div",{class:`${p}-progress-icon`,"aria-hidden":!0},r(Q,{clsPrefix:p},{default:()=>We[v]}))):null)}}}),Te={success:r(ee,null),error:r(re,null),warning:r(te,null),info:r(ie,null)},Le=P({name:"ProgressCircle",props:{clsPrefix:{type:String,required:!0},status:{type:String,required:!0},strokeWidth:{type:Number,required:!0},fillColor:String,railColor:String,railStyle:[String,Object],percentage:{type:Number,default:0},offsetDegree:{type:Number,default:0},showIndicator:{type:Boolean,required:!0},indicatorTextColor:String,unit:String,viewBoxWidth:{type:Number,required:!0},gapDegree:{type:Number,required:!0},gapOffsetDegree:{type:Number,default:0}},setup(e,{slots:i}){function o(t,n,l){const{gapDegree:a,viewBoxWidth:s,strokeWidth:d}=e,g=50,x=0,v=g,y=0,c=2*g,$=50+d/2,p=`M ${$},${$} m ${x},${v}
      a ${g},${g} 0 1 1 ${y},${-c}
      a ${g},${g} 0 1 1 ${-y},${c}`,_=Math.PI*2*g,z={stroke:l,strokeDasharray:`${t/100*(_-a)}px ${s*8}px`,strokeDashoffset:`-${a/2}px`,transformOrigin:n?"center":void 0,transform:n?`rotate(${n}deg)`:void 0};return{pathString:p,pathStyle:z}}return()=>{const{fillColor:t,railColor:n,strokeWidth:l,offsetDegree:a,status:s,percentage:d,showIndicator:g,indicatorTextColor:x,unit:v,gapOffsetDegree:y,clsPrefix:c}=e,{pathString:$,pathStyle:p}=o(100,0,n),{pathString:_,pathStyle:z}=o(d,a,t),C=100+l;return r("div",{class:`${c}-progress-content`,role:"none"},r("div",{class:`${c}-progress-graph`,"aria-hidden":!0},r("div",{class:`${c}-progress-graph-circle`,style:{transform:y?`rotate(${y}deg)`:void 0}},r("svg",{viewBox:`0 0 ${C} ${C}`},r("g",null,r("path",{class:`${c}-progress-graph-circle-rail`,d:$,"stroke-width":l,"stroke-linecap":"round",fill:"none",style:p})),r("g",null,r("path",{class:[`${c}-progress-graph-circle-fill`,d===0&&`${c}-progress-graph-circle-fill--empty`],d:_,"stroke-width":l,"stroke-linecap":"round",fill:"none",style:z}))))),g?r("div",null,i.default?r("div",{class:`${c}-progress-custom-content`,role:"none"},i.default()):s!=="default"?r("div",{class:`${c}-progress-icon`,"aria-hidden":!0},r(Q,{clsPrefix:c},{default:()=>Te[s]})):r("div",{class:`${c}-progress-text`,style:{color:x},role:"none"},r("span",{class:`${c}-progress-text__percentage`},d),r("span",{class:`${c}-progress-text__unit`},v))):null)}}});function U(e,i,o=100){return`m ${o/2} ${o/2-e} a ${e} ${e} 0 1 1 0 ${2*e} a ${e} ${e} 0 1 1 0 -${2*e}`}const je=P({name:"ProgressMultipleCircle",props:{clsPrefix:{type:String,required:!0},viewBoxWidth:{type:Number,required:!0},percentage:{type:Array,default:[0]},strokeWidth:{type:Number,required:!0},circleGap:{type:Number,required:!0},showIndicator:{type:Boolean,required:!0},fillColor:{type:Array,default:()=>[]},railColor:{type:Array,default:()=>[]},railStyle:{type:Array,default:()=>[]}},setup(e,{slots:i}){const o=k(()=>e.percentage.map((n,l)=>`${Math.PI*n/100*(e.viewBoxWidth/2-e.strokeWidth/2*(1+2*l)-e.circleGap*l)*2}, ${e.viewBoxWidth*8}`));return()=>{const{viewBoxWidth:t,strokeWidth:n,circleGap:l,showIndicator:a,fillColor:s,railColor:d,railStyle:g,percentage:x,clsPrefix:v}=e;return r("div",{class:`${v}-progress-content`,role:"none"},r("div",{class:`${v}-progress-graph`,"aria-hidden":!0},r("div",{class:`${v}-progress-graph-circle`},r("svg",{viewBox:`0 0 ${t} ${t}`},x.map((y,c)=>r("g",{key:c},r("path",{class:`${v}-progress-graph-circle-rail`,d:U(t/2-n/2*(1+2*c)-l*c,n,t),"stroke-width":n,"stroke-linecap":"round",fill:"none",style:[{strokeDashoffset:0,stroke:d[c]},g[c]]}),r("path",{class:[`${v}-progress-graph-circle-fill`,y===0&&`${v}-progress-graph-circle-fill--empty`],d:U(t/2-n/2*(1+2*c)-l*c,n,t),"stroke-width":n,"stroke-linecap":"round",fill:"none",style:{strokeDasharray:o.value[c],strokeDashoffset:0,stroke:s[c]}})))))),a&&i.default?r("div",null,r("div",{class:`${v}-progress-text`},i.default())):null)}}}),Fe=Object.assign(Object.assign({},W.props),{processing:Boolean,type:{type:String,default:"line"},gapDegree:Number,gapOffsetDegree:Number,status:{type:String,default:"default"},railColor:[String,Array],railStyle:[String,Array],color:[String,Array],viewBoxWidth:{type:Number,default:100},strokeWidth:{type:Number,default:7},percentage:[Number,Array],unit:{type:String,default:"%"},showIndicator:{type:Boolean,default:!0},indicatorPosition:{type:String,default:"outside"},indicatorPlacement:{type:String,default:"outside"},indicatorTextColor:String,circleGap:{type:Number,default:1},height:Number,borderRadius:[String,Number],fillBorderRadius:[String,Number],offsetDegree:Number}),qe=P({name:"Progress",props:Fe,setup(e){const i=k(()=>e.indicatorPlacement||e.indicatorPosition),o=k(()=>{if(e.gapDegree||e.gapDegree===0)return e.gapDegree;if(e.type==="dashboard")return 75}),{mergedClsPrefixRef:t,inlineThemeDisabled:n}=X(e),l=W("Progress","-progress",De,Ne,e,t),a=k(()=>{const{status:d}=e,{common:{cubicBezierEaseInOut:g},self:{fontSize:x,fontSizeCircle:v,railColor:y,railHeight:c,iconSizeCircle:$,iconSizeLine:p,textColorCircle:_,textColorLineInner:z,textColorLineOuter:C,lineBgProcessing:T,fontWeightCircle:E,[H("iconColor",d)]:A,[H("fillColor",d)]:O}}=l.value;return{"--n-bezier":g,"--n-fill-color":O,"--n-font-size":x,"--n-font-size-circle":v,"--n-font-weight-circle":E,"--n-icon-color":A,"--n-icon-size-circle":$,"--n-icon-size-line":p,"--n-line-bg-processing":T,"--n-rail-color":y,"--n-rail-height":c,"--n-text-color-circle":_,"--n-text-color-line-inner":z,"--n-text-color-line-outer":C}}),s=n?Z("progress",k(()=>e.status[0]),a,e):void 0;return{mergedClsPrefix:t,mergedIndicatorPlacement:i,gapDeg:o,cssVars:n?void 0:a,themeClass:s==null?void 0:s.themeClass,onRender:s==null?void 0:s.onRender}},render(){const{type:e,cssVars:i,indicatorTextColor:o,showIndicator:t,status:n,railColor:l,railStyle:a,color:s,percentage:d,viewBoxWidth:g,strokeWidth:x,mergedIndicatorPlacement:v,unit:y,borderRadius:c,fillBorderRadius:$,height:p,processing:_,circleGap:z,mergedClsPrefix:C,gapDeg:T,gapOffsetDegree:E,themeClass:A,$slots:O,onRender:M}=this;return M==null||M(),r("div",{class:[A,`${C}-progress`,`${C}-progress--${e}`,`${C}-progress--${n}`],style:i,"aria-valuemax":100,"aria-valuemin":0,"aria-valuenow":d,role:e==="circle"||e==="line"||e==="dashboard"?"progressbar":"none"},e==="circle"||e==="dashboard"?r(Le,{clsPrefix:C,status:n,showIndicator:t,indicatorTextColor:o,railColor:l,fillColor:s,railStyle:a,offsetDegree:this.offsetDegree,percentage:d,viewBoxWidth:g,strokeWidth:x,gapDegree:T===void 0?e==="dashboard"?75:0:T,gapOffsetDegree:E,unit:y},O):e==="line"?r(Oe,{clsPrefix:C,status:n,showIndicator:t,indicatorTextColor:o,railColor:l,fillColor:s,railStyle:a,percentage:d,processing:_,indicatorPlacement:v,unit:y,fillBorderRadius:$,railBorderRadius:c,height:p},O):e==="multiple-circle"?r(je,{clsPrefix:C,strokeWidth:x,railColor:l,fillColor:s,railStyle:a,viewBoxWidth:g,percentage:d,showIndicator:t,circleGap:z},O):null)}}),Ee=P({__name:"register-form",emits:["login","success"],setup(e,{emit:i}){const o=q({phone:"",password:"",password2:""}),t=le(),n=async()=>{try{await t.value.validate();const a=await pe(o.value),s=ce();s.username=`用户${o.value.phone}`,s.token=a,i("success")}catch{}},l={phone:[{required:!0,message:"请输入手机号码"},{message:"手机号码不合法",trigger:"blur",validator:(a,s)=>s!==""&&!/^\d{11}$/.test(s)?new Error("手机号码必须是 11 位数字"):!0}],password:[{required:!0,message:"请输入密码"},{min:6,max:20,message:"长度在 6 到 20 个字符",trigger:"blur"}],password2:[{required:!0,message:"请再次输入密码"},{min:6,max:20,message:"长度在 6 到 20 个字符",trigger:"blur"},{validator:(a,s)=>s!==o.value.password?new Error("两次输入密码不一致"):!0,trigger:["blur","input"]}]};return(a,s)=>(D(),oe(J,null,[f(m(S.NButton),{class:"w-full mt-4",onClick:s[0]||(s[0]=()=>i("login"))},{default:h(()=>[I("登录账号")]),_:1}),f(m(ze),{class:"text-[#4c566a] opacity-90"},{default:h(()=>[I("或者")]),_:1}),f(m(S.NForm),{ref_key:"formRef",ref:t,"label-width":80,model:o.value,rules:l},{default:h(()=>[f(m(S.NFormItem),{label:"手机",path:"phone"},{default:h(()=>[f(m(S.NInput),{value:o.value.phone,"onUpdate:value":s[1]||(s[1]=d=>o.value.phone=d),placeholder:"请输入手机"},null,8,["value"])]),_:1}),f(m(S.NFormItem),{label:"密码",path:"password"},{default:h(()=>[f(m(S.NInput),{value:o.value.password,"onUpdate:value":s[2]||(s[2]=d=>o.value.password=d),placeholder:"请输入密码",type:"password","show-password-on":"click"},null,8,["value"])]),_:1}),f(m(S.NFormItem),{label:"确认密码",path:"password2"},{default:h(()=>[f(m(S.NInput),{value:o.value.password2,"onUpdate:value":s[3]||(s[3]=d=>o.value.password2=d),placeholder:"请再次输入密码",type:"password",onKeydown:ae(n,["enter"])},null,8,["value","onKeydown"])]),_:1}),f(m(S.NButton),{type:"primary",class:"w-full mt-4",onClick:n},{default:h(()=>[I("注册")]),_:1})]),_:1},8,["model"])],64))}}),Ae={class:"w-full h-full flex flex-col items-center justify-center bg-[url('/img/register-bg.avif')] bg-center bg-cover"},Me=B("div",{class:"flex justify-center"},"注册账号",-1),Ve={class:"flex relative items-center"},Ge=B("span",{class:"flex grow justify-center"},"填写基本信息",-1),Xe={class:"flex relative items-center"},He=B("span",{class:"flex justify-center"},"填写学业信息",-1),Ye=B("div",{class:"flex justify-center"},"注册成功",-1);var w=function(e){return e[e.Register=0]="Register",e[e.FillBasicInfo=1]="FillBasicInfo",e[e.FillAcademicInfo=2]="FillAcademicInfo",e[e.Complete=3]="Complete",e}(w||{});const Ke=P({name:"GuidetoWelcome",setup:()=>{const e=q(5),i=setInterval(()=>{e.value--,e.value===0&&(clearInterval(i),Y())},1e3);return()=>f("div",{class:"flex flex-col items-center gap-4"},[f("div",null,[e.value,I(" 秒后跳转到主页 ")]),f("div",null,[f(ge,{onClick:()=>{clearInterval(i),Y()}},{default:()=>[I("不想等待? 点此跳转")]})])])}}),lr=P({__name:"register-view",setup(e){const i=q(w.Register);return(o,t)=>(D(),oe("div",Ae,[i.value===w.Register?(D(),j(m(F),{key:0,class:"w-fit h-fit m-12 shadow-sm"},{header:h(()=>[Me]),default:h(()=>[f(Ee,{onLogin:m(ue),onSuccess:t[0]||(t[0]=()=>i.value=w.FillBasicInfo)},null,8,["onLogin"])]),_:1})):i.value===w.FillBasicInfo?(D(),j(m(F),{key:1,class:"w-fit h-fit m-12 shadow-sm"},{header:h(()=>[B("div",Ve,[Ge,f(m(K),null,{trigger:h(()=>[B("span",{class:"icon-[material-symbols--skip-next-rounded] absolute right-2 hover:text-[#81a1c1] text-[#434c5e]",onClick:t[1]||(t[1]=n=>i.value=w.FillAcademicInfo)})]),default:h(()=>[I(" 不想填写？ 点此跳过 ")]),_:1})])]),default:h(()=>[f(fe,{onComplete:t[2]||(t[2]=()=>i.value=w.FillAcademicInfo)})]),_:1})):i.value===w.FillAcademicInfo?(D(),j(m(F),{key:2,class:"w-fit h-fit m-12 shadow-sm"},{header:h(()=>[B("div",Xe,[He,f(m(K),null,{trigger:h(()=>[B("span",{class:"icon-[material-symbols--skip-next-rounded] absolute right-2 hover:text-[#81a1c1] text-[#434c5e]",onClick:t[3]||(t[3]=n=>i.value=w.Complete)})]),default:h(()=>[I(" 不想填写？ 点此跳过 ")]),_:1})])]),default:h(()=>[f(he,{onComplete:t[4]||(t[4]=()=>i.value=w.Complete)})]),_:1})):i.value===w.Complete?(D(),j(m(F),{key:3,class:"w-fit h-fit m-12 shadow-sm"},{header:h(()=>[Ye]),default:h(()=>[f(m(Ke))]),_:1})):de("",!0),f(m(qe),{class:"fixed bottom-0","show-indicator":!1,percentage:7+i.value*31,height:4,"border-radius":0},null,8,["percentage"])]))}});export{lr as default};
