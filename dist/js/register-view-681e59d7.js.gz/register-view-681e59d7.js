import{j as r,N as ne,d as L,r as F,m as k,J,H as le,o as I,I as Q,a as f,w as h,b as N,u as m,l as S,O as ae,K as ce,c as j,P as de,Q as ue,M as P,g as X}from"./index-007a92d3.js";import{r as ge}from"./account-3a3efc02.js";import{h as pe,c as G,u as H,f as D,a as u,i as Z,b as _,e as x,g as ee,d as T,j as Y}from"./light-b2e8c463.js";import{_ as fe}from"./basic-info-form.vue_vue_type_script_setup_true_lang-410d719b.js";import{_ as he}from"./academic-info-form.vue_vue_type_script_setup_true_lang-9915056b.js";import{p as me,N as ve,a as xe}from"./Popover-da5277ae.js";import{f as R}from"./format-length-c9d165c6.js";import{r as q,N as re}from"./Icon-3720938d.js";import{N as M}from"./Card-5ec856ea.js";import{N as Ce}from"./Button-42f001df.js";import"./requests-16019d1b.js";import"./profile-7993055f.js";import"./browser-28ce0e4a.js";import"./flatten-fc248dbf.js";import"./fade-in-scale-up.cssr-71f84e39.js";import"./Suffix-7d0414dd.js";import"./Input-b06c1b19.js";import"./keep-8a3aab3e.js";import"./Add-8c1289aa.js";import"./color-to-class-b0332f36.js";const te=q("error",r("svg",{viewBox:"0 0 48 48",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},r("g",{stroke:"none","stroke-width":"1","fill-rule":"evenodd"},r("g",{"fill-rule":"nonzero"},r("path",{d:"M24,4 C35.045695,4 44,12.954305 44,24 C44,35.045695 35.045695,44 24,44 C12.954305,44 4,35.045695 4,24 C4,12.954305 12.954305,4 24,4 Z M17.8838835,16.1161165 L17.7823881,16.0249942 C17.3266086,15.6583353 16.6733914,15.6583353 16.2176119,16.0249942 L16.1161165,16.1161165 L16.0249942,16.2176119 C15.6583353,16.6733914 15.6583353,17.3266086 16.0249942,17.7823881 L16.1161165,17.8838835 L22.233,24 L16.1161165,30.1161165 L16.0249942,30.2176119 C15.6583353,30.6733914 15.6583353,31.3266086 16.0249942,31.7823881 L16.1161165,31.8838835 L16.2176119,31.9750058 C16.6733914,32.3416647 17.3266086,32.3416647 17.7823881,31.9750058 L17.8838835,31.8838835 L24,25.767 L30.1161165,31.8838835 L30.2176119,31.9750058 C30.6733914,32.3416647 31.3266086,32.3416647 31.7823881,31.9750058 L31.8838835,31.8838835 L31.9750058,31.7823881 C32.3416647,31.3266086 32.3416647,30.6733914 31.9750058,30.2176119 L31.8838835,30.1161165 L25.767,24 L31.8838835,17.8838835 L31.9750058,17.7823881 C32.3416647,17.3266086 32.3416647,16.6733914 31.9750058,16.2176119 L31.8838835,16.1161165 L31.7823881,16.0249942 C31.3266086,15.6583353 30.6733914,15.6583353 30.2176119,16.0249942 L30.1161165,16.1161165 L24,22.233 L17.8838835,16.1161165 L17.7823881,16.0249942 L17.8838835,16.1161165 Z"}))))),oe=q("info",r("svg",{viewBox:"0 0 28 28",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},r("g",{stroke:"none","stroke-width":"1","fill-rule":"evenodd"},r("g",{"fill-rule":"nonzero"},r("path",{d:"M14,2 C20.6274,2 26,7.37258 26,14 C26,20.6274 20.6274,26 14,26 C7.37258,26 2,20.6274 2,14 C2,7.37258 7.37258,2 14,2 Z M14,11 C13.4477,11 13,11.4477 13,12 L13,12 L13,20 C13,20.5523 13.4477,21 14,21 C14.5523,21 15,20.5523 15,20 L15,20 L15,12 C15,11.4477 14.5523,11 14,11 Z M14,6.75 C13.3096,6.75 12.75,7.30964 12.75,8 C12.75,8.69036 13.3096,9.25 14,9.25 C14.6904,9.25 15.25,8.69036 15.25,8 C15.25,7.30964 14.6904,6.75 14,6.75 Z"}))))),ie=q("success",r("svg",{viewBox:"0 0 48 48",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},r("g",{stroke:"none","stroke-width":"1","fill-rule":"evenodd"},r("g",{"fill-rule":"nonzero"},r("path",{d:"M24,4 C35.045695,4 44,12.954305 44,24 C44,35.045695 35.045695,44 24,44 C12.954305,44 4,35.045695 4,24 C4,12.954305 12.954305,4 24,4 Z M32.6338835,17.6161165 C32.1782718,17.1605048 31.4584514,17.1301307 30.9676119,17.5249942 L30.8661165,17.6161165 L20.75,27.732233 L17.1338835,24.1161165 C16.6457281,23.6279612 15.8542719,23.6279612 15.3661165,24.1161165 C14.9105048,24.5717282 14.8801307,25.2915486 15.2749942,25.7823881 L15.3661165,25.8838835 L19.8661165,30.3838835 C20.3217282,30.8394952 21.0415486,30.8698693 21.5323881,30.4750058 L21.6338835,30.3838835 L32.6338835,19.3838835 C33.1220388,18.8957281 33.1220388,18.1042719 32.6338835,17.6161165 Z"}))))),se=q("warning",r("svg",{viewBox:"0 0 24 24",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},r("g",{stroke:"none","stroke-width":"1","fill-rule":"evenodd"},r("g",{"fill-rule":"nonzero"},r("path",{d:"M12,2 C17.523,2 22,6.478 22,12 C22,17.522 17.523,22 12,22 C6.477,22 2,17.522 2,12 C2,6.478 6.477,2 12,2 Z M12.0018002,15.0037242 C11.450254,15.0037242 11.0031376,15.4508407 11.0031376,16.0023869 C11.0031376,16.553933 11.450254,17.0010495 12.0018002,17.0010495 C12.5533463,17.0010495 13.0004628,16.553933 13.0004628,16.0023869 C13.0004628,15.4508407 12.5533463,15.0037242 12.0018002,15.0037242 Z M11.99964,7 C11.4868042,7.00018474 11.0642719,7.38637706 11.0066858,7.8837365 L11,8.00036004 L11.0018003,13.0012393 L11.00857,13.117858 C11.0665141,13.6151758 11.4893244,14.0010638 12.0021602,14.0008793 C12.514996,14.0006946 12.9375283,13.6145023 12.9951144,13.1171428 L13.0018002,13.0005193 L13,7.99964009 L12.9932303,7.8830214 C12.9352861,7.38570354 12.5124758,6.99981552 11.99964,7 Z"}))))),be={padding:"8px 14px"},ye=e=>{const{borderRadius:o,boxShadow2:i,baseColor:t}=e;return Object.assign(Object.assign({},be),{borderRadius:o,boxShadow:i,color:ne(t,"rgba(0, 0, 0, .85)"),textColor:t})},we=pe({name:"Tooltip",common:G,peers:{Popover:me},self:ye}),$e=we,ke=Object.assign(Object.assign({},xe),D.props),K=L({name:"Tooltip",props:ke,__popover__:!0,setup(e){const{mergedClsPrefixRef:o}=H(e),i=D("Tooltip","-tooltip",void 0,$e,e,o),t=F(null);return Object.assign(Object.assign({},{syncPosition(){t.value.syncPosition()},setShow(l){t.value.setShow(l)}}),{popoverRef:t,mergedTheme:i,popoverThemeOverrides:k(()=>i.value.self)})},render(){const{mergedTheme:e,internalExtraClass:o}=this;return r(ve,Object.assign(Object.assign({},this.$props),{theme:e.peers.Popover,themeOverrides:e.peerOverrides.Popover,builtinThemeOverrides:this.popoverThemeOverrides,internalExtraClass:o.concat("tooltip"),ref:"popoverRef"}),this.$slots)}}),Se=e=>{const{textColor1:o,dividerColor:i,fontWeightStrong:t}=e;return{textColor:o,color:i,fontWeight:t}},Le={name:"Divider",common:G,self:Se},Pe=Le,Be=u("divider",`
 position: relative;
 display: flex;
 width: 100%;
 box-sizing: border-box;
 font-size: 16px;
 color: var(--n-text-color);
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
`,[Z("vertical",`
 margin-top: 24px;
 margin-bottom: 24px;
 `,[Z("no-title",`
 display: flex;
 align-items: center;
 `)]),_("title",`
 display: flex;
 align-items: center;
 margin-left: 12px;
 margin-right: 12px;
 white-space: nowrap;
 font-weight: var(--n-font-weight);
 `),x("title-position-left",[_("line",[x("left",{width:"28px"})])]),x("title-position-right",[_("line",[x("right",{width:"28px"})])]),x("dashed",[_("line",`
 background-color: #0000;
 height: 0px;
 width: 100%;
 border-style: dashed;
 border-width: 1px 0 0;
 `)]),x("vertical",`
 display: inline-block;
 height: 1em;
 margin: 0 8px;
 vertical-align: middle;
 width: 1px;
 `),_("line",`
 border: none;
 transition: background-color .3s var(--n-bezier), border-color .3s var(--n-bezier);
 height: 1px;
 width: 100%;
 margin: 0;
 `),Z("dashed",[_("line",{backgroundColor:"var(--n-color)"})]),x("dashed",[_("line",{borderColor:"var(--n-color)"})]),x("vertical",{backgroundColor:"var(--n-color)"})]),ze=Object.assign(Object.assign({},D.props),{titlePlacement:{type:String,default:"center"},dashed:Boolean,vertical:Boolean}),_e=L({name:"Divider",props:ze,setup(e){const{mergedClsPrefixRef:o,inlineThemeDisabled:i}=H(e),t=D("Divider","-divider",Be,Pe,e,o),n=k(()=>{const{common:{cubicBezierEaseInOut:a},self:{color:s,textColor:d,fontWeight:g}}=t.value;return{"--n-bezier":a,"--n-color":s,"--n-text-color":d,"--n-font-weight":g}}),l=i?ee("divider",void 0,n,e):void 0;return{mergedClsPrefix:o,cssVars:i?void 0:n,themeClass:l==null?void 0:l.themeClass,onRender:l==null?void 0:l.onRender}},render(){var e;const{$slots:o,titlePlacement:i,vertical:t,dashed:n,cssVars:l,mergedClsPrefix:a}=this;return(e=this.onRender)===null||e===void 0||e.call(this),r("div",{role:"separator",class:[`${a}-divider`,this.themeClass,{[`${a}-divider--vertical`]:t,[`${a}-divider--no-title`]:!o.default,[`${a}-divider--dashed`]:n,[`${a}-divider--title-position-${i}`]:o.default&&i}],style:l},t?null:r("div",{class:`${a}-divider__line ${a}-divider__line--left`}),!t&&o.default?r(J,null,r("div",{class:`${a}-divider__title`},this.$slots),r("div",{class:`${a}-divider__line ${a}-divider__line--right`})):null)}}),Ne=e=>{const{infoColor:o,successColor:i,warningColor:t,errorColor:n,textColor2:l,progressRailColor:a,fontSize:s,fontWeight:d}=e;return{fontSize:s,fontSizeCircle:"28px",fontWeightCircle:d,railColor:a,railHeight:"8px",iconSizeCircle:"36px",iconSizeLine:"18px",iconColor:o,iconColorInfo:o,iconColorSuccess:i,iconColorWarning:t,iconColorError:n,textColorCircle:l,textColorLineInner:"rgb(255, 255, 255)",textColorLineOuter:l,fillColor:o,fillColorInfo:o,fillColorSuccess:i,fillColorWarning:t,fillColorError:n,lineBgProcessing:"linear-gradient(90deg, rgba(255, 255, 255, .3) 0%, rgba(255, 255, 255, .5) 100%)"}},Re={name:"Progress",common:G,self:Ne},Ie=Re,De=T([u("progress",{display:"inline-block"},[u("progress-icon",`
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 `),x("line",`
 width: 100%;
 display: block;
 `,[u("progress-content",`
 display: flex;
 align-items: center;
 `,[u("progress-graph",{flex:1})]),u("progress-custom-content",{marginLeft:"14px"}),u("progress-icon",`
 width: 30px;
 padding-left: 14px;
 height: var(--n-icon-size-line);
 line-height: var(--n-icon-size-line);
 font-size: var(--n-icon-size-line);
 `,[x("as-text",`
 color: var(--n-text-color-line-outer);
 text-align: center;
 width: 40px;
 font-size: var(--n-font-size);
 padding-left: 4px;
 transition: color .3s var(--n-bezier);
 `)])]),x("circle, dashboard",{width:"120px"},[u("progress-custom-content",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 `),u("progress-text",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: inherit;
 font-size: var(--n-font-size-circle);
 color: var(--n-text-color-circle);
 font-weight: var(--n-font-weight-circle);
 transition: color .3s var(--n-bezier);
 white-space: nowrap;
 `),u("progress-icon",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: var(--n-icon-color);
 font-size: var(--n-icon-size-circle);
 `)]),x("multiple-circle",`
 width: 200px;
 color: inherit;
 `,[u("progress-text",`
 font-weight: var(--n-font-weight-circle);
 color: var(--n-text-color-circle);
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `)]),u("progress-content",{position:"relative"}),u("progress-graph",{position:"relative"},[u("progress-graph-circle",[T("svg",{verticalAlign:"bottom"}),u("progress-graph-circle-fill",`
 stroke: var(--n-fill-color);
 transition:
 opacity .3s var(--n-bezier),
 stroke .3s var(--n-bezier),
 stroke-dasharray .3s var(--n-bezier);
 `,[x("empty",{opacity:0})]),u("progress-graph-circle-rail",`
 transition: stroke .3s var(--n-bezier);
 overflow: hidden;
 stroke: var(--n-rail-color);
 `)]),u("progress-graph-line",[x("indicator-inside",[u("progress-graph-line-rail",`
 height: 16px;
 line-height: 16px;
 border-radius: 10px;
 `,[u("progress-graph-line-fill",`
 height: inherit;
 border-radius: 10px;
 `),u("progress-graph-line-indicator",`
 background: #0000;
 white-space: nowrap;
 text-align: right;
 margin-left: 14px;
 margin-right: 14px;
 height: inherit;
 font-size: 12px;
 color: var(--n-text-color-line-inner);
 transition: color .3s var(--n-bezier);
 `)])]),x("indicator-inside-label",`
 height: 16px;
 display: flex;
 align-items: center;
 `,[u("progress-graph-line-rail",`
 flex: 1;
 transition: background-color .3s var(--n-bezier);
 `),u("progress-graph-line-indicator",`
 background: var(--n-fill-color);
 font-size: 12px;
 transform: translateZ(0);
 display: flex;
 vertical-align: middle;
 height: 16px;
 line-height: 16px;
 padding: 0 10px;
 border-radius: 10px;
 position: absolute;
 white-space: nowrap;
 color: var(--n-text-color-line-inner);
 transition:
 right .2s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `)]),u("progress-graph-line-rail",`
 position: relative;
 overflow: hidden;
 height: var(--n-rail-height);
 border-radius: 5px;
 background-color: var(--n-rail-color);
 transition: background-color .3s var(--n-bezier);
 `,[u("progress-graph-line-fill",`
 background: var(--n-fill-color);
 position: relative;
 border-radius: 5px;
 height: inherit;
 width: 100%;
 max-width: 0%;
 transition:
 background-color .3s var(--n-bezier),
 max-width .2s var(--n-bezier);
 `,[x("processing",[T("&::after",`
 content: "";
 background-image: var(--n-line-bg-processing);
 animation: progress-processing-animation 2s var(--n-bezier) infinite;
 `)])])])])])]),T("@keyframes progress-processing-animation",`
 0% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 100%;
 opacity: 1;
 }
 66% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 100% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 `)]),We={success:r(ie,null),error:r(te,null),warning:r(se,null),info:r(oe,null)},Oe=L({name:"ProgressLine",props:{clsPrefix:{type:String,required:!0},percentage:{type:Number,default:0},railColor:String,railStyle:[String,Object],fillColor:String,status:{type:String,required:!0},indicatorPlacement:{type:String,required:!0},indicatorTextColor:String,unit:{type:String,default:"%"},processing:{type:Boolean,required:!0},showIndicator:{type:Boolean,required:!0},height:[String,Number],railBorderRadius:[String,Number],fillBorderRadius:[String,Number]},setup(e,{slots:o}){const i=k(()=>R(e.height)),t=k(()=>e.railBorderRadius!==void 0?R(e.railBorderRadius):e.height!==void 0?R(e.height,{c:.5}):""),n=k(()=>e.fillBorderRadius!==void 0?R(e.fillBorderRadius):e.railBorderRadius!==void 0?R(e.railBorderRadius):e.height!==void 0?R(e.height,{c:.5}):"");return()=>{const{indicatorPlacement:l,railColor:a,railStyle:s,percentage:d,unit:g,indicatorTextColor:C,status:v,showIndicator:b,fillColor:c,processing:$,clsPrefix:p}=e;return r("div",{class:`${p}-progress-content`,role:"none"},r("div",{class:`${p}-progress-graph`,"aria-hidden":!0},r("div",{class:[`${p}-progress-graph-line`,{[`${p}-progress-graph-line--indicator-${l}`]:!0}]},r("div",{class:`${p}-progress-graph-line-rail`,style:[{backgroundColor:a,height:i.value,borderRadius:t.value},s]},r("div",{class:[`${p}-progress-graph-line-fill`,$&&`${p}-progress-graph-line-fill--processing`],style:{maxWidth:`${e.percentage}%`,backgroundColor:c,height:i.value,lineHeight:i.value,borderRadius:n.value}},l==="inside"?r("div",{class:`${p}-progress-graph-line-indicator`,style:{color:C}},d,g):null)))),b&&l==="outside"?r("div",null,o.default?r("div",{class:`${p}-progress-custom-content`,style:{color:C},role:"none"},o.default()):v==="default"?r("div",{role:"none",class:`${p}-progress-icon ${p}-progress-icon--as-text`,style:{color:C}},d,g):r("div",{class:`${p}-progress-icon`,"aria-hidden":!0},r(re,{clsPrefix:p},{default:()=>We[v]}))):null)}}}),je={success:r(ie,null),error:r(te,null),warning:r(se,null),info:r(oe,null)},Te=L({name:"ProgressCircle",props:{clsPrefix:{type:String,required:!0},status:{type:String,required:!0},strokeWidth:{type:Number,required:!0},fillColor:String,railColor:String,railStyle:[String,Object],percentage:{type:Number,default:0},offsetDegree:{type:Number,default:0},showIndicator:{type:Boolean,required:!0},indicatorTextColor:String,unit:String,viewBoxWidth:{type:Number,required:!0},gapDegree:{type:Number,required:!0},gapOffsetDegree:{type:Number,default:0}},setup(e,{slots:o}){function i(t,n,l){const{gapDegree:a,viewBoxWidth:s,strokeWidth:d}=e,g=50,C=0,v=g,b=0,c=2*g,$=50+d/2,p=`M ${$},${$} m ${C},${v}
      a ${g},${g} 0 1 1 ${b},${-c}
      a ${g},${g} 0 1 1 ${-b},${c}`,B=Math.PI*2*g,z={stroke:l,strokeDasharray:`${t/100*(B-a)}px ${s*8}px`,strokeDashoffset:`-${a/2}px`,transformOrigin:n?"center":void 0,transform:n?`rotate(${n}deg)`:void 0};return{pathString:p,pathStyle:z}}return()=>{const{fillColor:t,railColor:n,strokeWidth:l,offsetDegree:a,status:s,percentage:d,showIndicator:g,indicatorTextColor:C,unit:v,gapOffsetDegree:b,clsPrefix:c}=e,{pathString:$,pathStyle:p}=i(100,0,n),{pathString:B,pathStyle:z}=i(d,a,t),y=100+l;return r("div",{class:`${c}-progress-content`,role:"none"},r("div",{class:`${c}-progress-graph`,"aria-hidden":!0},r("div",{class:`${c}-progress-graph-circle`,style:{transform:b?`rotate(${b}deg)`:void 0}},r("svg",{viewBox:`0 0 ${y} ${y}`},r("g",null,r("path",{class:`${c}-progress-graph-circle-rail`,d:$,"stroke-width":l,"stroke-linecap":"round",fill:"none",style:p})),r("g",null,r("path",{class:[`${c}-progress-graph-circle-fill`,d===0&&`${c}-progress-graph-circle-fill--empty`],d:B,"stroke-width":l,"stroke-linecap":"round",fill:"none",style:z}))))),g?r("div",null,o.default?r("div",{class:`${c}-progress-custom-content`,role:"none"},o.default()):s!=="default"?r("div",{class:`${c}-progress-icon`,"aria-hidden":!0},r(re,{clsPrefix:c},{default:()=>je[s]})):r("div",{class:`${c}-progress-text`,style:{color:C},role:"none"},r("span",{class:`${c}-progress-text__percentage`},d),r("span",{class:`${c}-progress-text__unit`},v))):null)}}});function U(e,o,i=100){return`m ${i/2} ${i/2-e} a ${e} ${e} 0 1 1 0 ${2*e} a ${e} ${e} 0 1 1 0 -${2*e}`}const Me=L({name:"ProgressMultipleCircle",props:{clsPrefix:{type:String,required:!0},viewBoxWidth:{type:Number,required:!0},percentage:{type:Array,default:[0]},strokeWidth:{type:Number,required:!0},circleGap:{type:Number,required:!0},showIndicator:{type:Boolean,required:!0},fillColor:{type:Array,default:()=>[]},railColor:{type:Array,default:()=>[]},railStyle:{type:Array,default:()=>[]}},setup(e,{slots:o}){const i=k(()=>e.percentage.map((n,l)=>`${Math.PI*n/100*(e.viewBoxWidth/2-e.strokeWidth/2*(1+2*l)-e.circleGap*l)*2}, ${e.viewBoxWidth*8}`));return()=>{const{viewBoxWidth:t,strokeWidth:n,circleGap:l,showIndicator:a,fillColor:s,railColor:d,railStyle:g,percentage:C,clsPrefix:v}=e;return r("div",{class:`${v}-progress-content`,role:"none"},r("div",{class:`${v}-progress-graph`,"aria-hidden":!0},r("div",{class:`${v}-progress-graph-circle`},r("svg",{viewBox:`0 0 ${t} ${t}`},C.map((b,c)=>r("g",{key:c},r("path",{class:`${v}-progress-graph-circle-rail`,d:U(t/2-n/2*(1+2*c)-l*c,n,t),"stroke-width":n,"stroke-linecap":"round",fill:"none",style:[{strokeDashoffset:0,stroke:d[c]},g[c]]}),r("path",{class:[`${v}-progress-graph-circle-fill`,b===0&&`${v}-progress-graph-circle-fill--empty`],d:U(t/2-n/2*(1+2*c)-l*c,n,t),"stroke-width":n,"stroke-linecap":"round",fill:"none",style:{strokeDasharray:i.value[c],strokeDashoffset:0,stroke:s[c]}})))))),a&&o.default?r("div",null,r("div",{class:`${v}-progress-text`},o.default())):null)}}}),Fe=Object.assign(Object.assign({},D.props),{processing:Boolean,type:{type:String,default:"line"},gapDegree:Number,gapOffsetDegree:Number,status:{type:String,default:"default"},railColor:[String,Array],railStyle:[String,Array],color:[String,Array],viewBoxWidth:{type:Number,default:100},strokeWidth:{type:Number,default:7},percentage:[Number,Array],unit:{type:String,default:"%"},showIndicator:{type:Boolean,default:!0},indicatorPosition:{type:String,default:"outside"},indicatorPlacement:{type:String,default:"outside"},indicatorTextColor:String,circleGap:{type:Number,default:1},height:Number,borderRadius:[String,Number],fillBorderRadius:[String,Number],offsetDegree:Number}),qe=L({name:"Progress",props:Fe,setup(e){const o=k(()=>e.indicatorPlacement||e.indicatorPosition),i=k(()=>{if(e.gapDegree||e.gapDegree===0)return e.gapDegree;if(e.type==="dashboard")return 75}),{mergedClsPrefixRef:t,inlineThemeDisabled:n}=H(e),l=D("Progress","-progress",De,Ie,e,t),a=k(()=>{const{status:d}=e,{common:{cubicBezierEaseInOut:g},self:{fontSize:C,fontSizeCircle:v,railColor:b,railHeight:c,iconSizeCircle:$,iconSizeLine:p,textColorCircle:B,textColorLineInner:z,textColorLineOuter:y,lineBgProcessing:O,fontWeightCircle:E,[Y("iconColor",d)]:A,[Y("fillColor",d)]:W}}=l.value;return{"--n-bezier":g,"--n-fill-color":W,"--n-font-size":C,"--n-font-size-circle":v,"--n-font-weight-circle":E,"--n-icon-color":A,"--n-icon-size-circle":$,"--n-icon-size-line":p,"--n-line-bg-processing":O,"--n-rail-color":b,"--n-rail-height":c,"--n-text-color-circle":B,"--n-text-color-line-inner":z,"--n-text-color-line-outer":y}}),s=n?ee("progress",k(()=>e.status[0]),a,e):void 0;return{mergedClsPrefix:t,mergedIndicatorPlacement:o,gapDeg:i,cssVars:n?void 0:a,themeClass:s==null?void 0:s.themeClass,onRender:s==null?void 0:s.onRender}},render(){const{type:e,cssVars:o,indicatorTextColor:i,showIndicator:t,status:n,railColor:l,railStyle:a,color:s,percentage:d,viewBoxWidth:g,strokeWidth:C,mergedIndicatorPlacement:v,unit:b,borderRadius:c,fillBorderRadius:$,height:p,processing:B,circleGap:z,mergedClsPrefix:y,gapDeg:O,gapOffsetDegree:E,themeClass:A,$slots:W,onRender:V}=this;return V==null||V(),r("div",{class:[A,`${y}-progress`,`${y}-progress--${e}`,`${y}-progress--${n}`],style:o,"aria-valuemax":100,"aria-valuemin":0,"aria-valuenow":d,role:e==="circle"||e==="line"||e==="dashboard"?"progressbar":"none"},e==="circle"||e==="dashboard"?r(Te,{clsPrefix:y,status:n,showIndicator:t,indicatorTextColor:i,railColor:l,fillColor:s,railStyle:a,offsetDegree:this.offsetDegree,percentage:d,viewBoxWidth:g,strokeWidth:C,gapDegree:O===void 0?e==="dashboard"?75:0:O,gapOffsetDegree:E,unit:b},W):e==="line"?r(Oe,{clsPrefix:y,status:n,showIndicator:t,indicatorTextColor:i,railColor:l,fillColor:s,railStyle:a,percentage:d,processing:B,indicatorPlacement:v,unit:b,fillBorderRadius:$,railBorderRadius:c,height:p},W):e==="multiple-circle"?r(Me,{clsPrefix:y,strokeWidth:C,railColor:l,fillColor:s,railStyle:a,viewBoxWidth:g,percentage:d,showIndicator:t,circleGap:z},W):null)}}),Ee=L({__name:"register-form",emits:["login","success"],setup(e,{emit:o}){const i=F({phone:"",password:"",password2:""}),t=le(),n=async()=>{try{await t.value.validate();const a=await ge(i.value),s=ce();s.username=`用户${i.value.phone}`,s.token=a,o("success")}catch{}},l={phone:[{required:!0,message:"请输入手机号码"},{message:"手机号码不合法",trigger:"blur",validator:(a,s)=>s!==""&&!/^\d{11}$/.test(s)?new Error("手机号码必须是 11 位数字"):!0}],password:[{required:!0,message:"请输入密码"},{min:6,max:20,message:"长度在 6 到 20 个字符",trigger:"blur"}],password2:[{required:!0,message:"请再次输入密码"},{min:6,max:20,message:"长度在 6 到 20 个字符",trigger:"blur"},{validator:(a,s)=>s!==i.value.password?new Error("两次输入密码不一致"):!0,trigger:["blur","input"]}]};return(a,s)=>(I(),Q(J,null,[f(m(S.NButton),{class:"w-full mt-4",onClick:s[0]||(s[0]=()=>o("login"))},{default:h(()=>[N("登录账号")]),_:1}),f(m(_e),{class:"text-[#4c566a] opacity-90"},{default:h(()=>[N("或者")]),_:1}),f(m(S.NForm),{ref_key:"formRef",ref:t,"label-width":80,model:i.value,rules:l},{default:h(()=>[f(m(S.NFormItem),{label:"手机",path:"phone"},{default:h(()=>[f(m(S.NInput),{value:i.value.phone,"onUpdate:value":s[1]||(s[1]=d=>i.value.phone=d),placeholder:"请输入手机"},null,8,["value"])]),_:1}),f(m(S.NFormItem),{label:"密码",path:"password"},{default:h(()=>[f(m(S.NInput),{value:i.value.password,"onUpdate:value":s[2]||(s[2]=d=>i.value.password=d),placeholder:"请输入密码",type:"password","show-password-on":"click"},null,8,["value"])]),_:1}),f(m(S.NFormItem),{label:"确认密码",path:"password2"},{default:h(()=>[f(m(S.NInput),{value:i.value.password2,"onUpdate:value":s[3]||(s[3]=d=>i.value.password2=d),placeholder:"请再次输入密码",type:"password",onKeydown:ae(n,["enter"])},null,8,["value","onKeydown"])]),_:1}),f(m(S.NButton),{type:"primary",class:"w-full mt-4",onClick:n},{default:h(()=>[N("注册")]),_:1})]),_:1},8,["model"])],64))}}),Ae={class:"w-full h-full flex flex-col items-center justify-center bg-[url('/img/register-bg.webp')] bg-center bg-cover"},Ve=P("div",{class:"flex justify-center"},"注册账号",-1),Ze={class:"flex relative items-center"},Ge=P("span",{class:"flex grow justify-center"},"填写基本信息",-1),He={class:"flex relative items-center"},Xe=P("span",{class:"flex justify-center"},"填写学业信息",-1),Ye=P("div",{class:"flex justify-center"},"注册成功",-1);var w=function(e){return e[e.Register=0]="Register",e[e.FillBasicInfo=1]="FillBasicInfo",e[e.FillAcademicInfo=2]="FillAcademicInfo",e[e.Complete=3]="Complete",e}(w||{});const Ke=L({name:"GuidetoWelcome",setup:()=>{const e=F(5),o=setInterval(()=>{e.value--,e.value===0&&(clearInterval(o),X())},1e3);return()=>f("div",{class:"flex flex-col items-center gap-4"},[f("div",null,[e.value,N(" 秒后跳转到主页 ")]),f("div",null,[f(Ce,{onClick:()=>{clearInterval(o),X()}},{default:()=>[N("不想等待? 点此跳转")]})])])}}),vr=L({__name:"register-view",setup(e){const o=F(w.Register);return(i,t)=>(I(),Q("div",Ae,[o.value===w.Register?(I(),j(m(M),{key:0,class:"w-fit h-fit m-12 shadow-sm"},{header:h(()=>[Ve]),default:h(()=>[f(Ee,{onLogin:m(ue),onSuccess:t[0]||(t[0]=()=>o.value=w.FillBasicInfo)},null,8,["onLogin"])]),_:1})):o.value===w.FillBasicInfo?(I(),j(m(M),{key:1,class:"w-fit h-fit m-12 shadow-sm"},{header:h(()=>[P("div",Ze,[Ge,f(m(K),null,{trigger:h(()=>[P("span",{class:"icon-[material-symbols--skip-next-rounded] absolute right-2 hover:text-[#81a1c1] text-[#434c5e]",onClick:t[1]||(t[1]=n=>o.value=w.FillAcademicInfo)})]),default:h(()=>[N(" 不想填写？ 点此跳过 ")]),_:1})])]),default:h(()=>[f(fe,{onComplete:t[2]||(t[2]=()=>o.value=w.FillAcademicInfo)})]),_:1})):o.value===w.FillAcademicInfo?(I(),j(m(M),{key:2,class:"w-fit h-fit m-12 shadow-sm"},{header:h(()=>[P("div",He,[Xe,f(m(K),null,{trigger:h(()=>[P("span",{class:"icon-[material-symbols--skip-next-rounded] absolute right-2 hover:text-[#81a1c1] text-[#434c5e]",onClick:t[3]||(t[3]=n=>o.value=w.Complete)})]),default:h(()=>[N(" 不想填写？ 点此跳过 ")]),_:1})])]),default:h(()=>[f(he,{onComplete:t[4]||(t[4]=()=>o.value=w.Complete)})]),_:1})):o.value===w.Complete?(I(),j(m(M),{key:3,class:"w-fit h-fit m-12 shadow-sm"},{header:h(()=>[Ye]),default:h(()=>[f(m(Ke))]),_:1})):de("",!0),f(m(qe),{class:"fixed bottom-0","show-indicator":!1,percentage:7+o.value*31,height:4,"border-radius":0},null,8,["percentage"])]))}});export{vr as default};
