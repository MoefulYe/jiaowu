import{e as Bt,t as De,f as Zt,h as tt,p as Wt,i as Ft,j as Xt,k as Yt,d as K,m as pe,r as V,n as Ht,q as y,s as Kt,v as p,x as nt,y as ot,z as qt,A as d,B as $,C as f,D as Be,E as Gt,F as Jt,G as Qt,H as en,I as fe,J as Ze,K as at,L as tn,M as nn,V as We,O as Fe,P as on,Q as an,T as rn,R as sn,S as ln,U as ee,W as te,X as un,o as rt,Y as st,a as A,w as L,b as ke,u as T,l as U,Z as cn,_ as dn,g as fn,$ as vn,a0 as xn,a1 as he}from"./index-49d75a97.js";import{l as pn}from"./account-b59fd468.js";import"./requests-facbabb5.js";function hn(e){return Bt(De(e).toLowerCase())}function gn(e,n,a,s){var u=-1,h=e==null?0:e.length;for(s&&h&&(a=e[++u]);++u<h;)a=n(a,e[u],u,e);return a}function mn(e){return function(n){return e==null?void 0:e[n]}}var bn={À:"A",Á:"A",Â:"A",Ã:"A",Ä:"A",Å:"A",à:"a",á:"a",â:"a",ã:"a",ä:"a",å:"a",Ç:"C",ç:"c",Ð:"D",ð:"d",È:"E",É:"E",Ê:"E",Ë:"E",è:"e",é:"e",ê:"e",ë:"e",Ì:"I",Í:"I",Î:"I",Ï:"I",ì:"i",í:"i",î:"i",ï:"i",Ñ:"N",ñ:"n",Ò:"O",Ó:"O",Ô:"O",Õ:"O",Ö:"O",Ø:"O",ò:"o",ó:"o",ô:"o",õ:"o",ö:"o",ø:"o",Ù:"U",Ú:"U",Û:"U",Ü:"U",ù:"u",ú:"u",û:"u",ü:"u",Ý:"Y",ý:"y",ÿ:"y",Æ:"Ae",æ:"ae",Þ:"Th",þ:"th",ß:"ss",Ā:"A",Ă:"A",Ą:"A",ā:"a",ă:"a",ą:"a",Ć:"C",Ĉ:"C",Ċ:"C",Č:"C",ć:"c",ĉ:"c",ċ:"c",č:"c",Ď:"D",Đ:"D",ď:"d",đ:"d",Ē:"E",Ĕ:"E",Ė:"E",Ę:"E",Ě:"E",ē:"e",ĕ:"e",ė:"e",ę:"e",ě:"e",Ĝ:"G",Ğ:"G",Ġ:"G",Ģ:"G",ĝ:"g",ğ:"g",ġ:"g",ģ:"g",Ĥ:"H",Ħ:"H",ĥ:"h",ħ:"h",Ĩ:"I",Ī:"I",Ĭ:"I",Į:"I",İ:"I",ĩ:"i",ī:"i",ĭ:"i",į:"i",ı:"i",Ĵ:"J",ĵ:"j",Ķ:"K",ķ:"k",ĸ:"k",Ĺ:"L",Ļ:"L",Ľ:"L",Ŀ:"L",Ł:"L",ĺ:"l",ļ:"l",ľ:"l",ŀ:"l",ł:"l",Ń:"N",Ņ:"N",Ň:"N",Ŋ:"N",ń:"n",ņ:"n",ň:"n",ŋ:"n",Ō:"O",Ŏ:"O",Ő:"O",ō:"o",ŏ:"o",ő:"o",Ŕ:"R",Ŗ:"R",Ř:"R",ŕ:"r",ŗ:"r",ř:"r",Ś:"S",Ŝ:"S",Ş:"S",Š:"S",ś:"s",ŝ:"s",ş:"s",š:"s",Ţ:"T",Ť:"T",Ŧ:"T",ţ:"t",ť:"t",ŧ:"t",Ũ:"U",Ū:"U",Ŭ:"U",Ů:"U",Ű:"U",Ų:"U",ũ:"u",ū:"u",ŭ:"u",ů:"u",ű:"u",ų:"u",Ŵ:"W",ŵ:"w",Ŷ:"Y",ŷ:"y",Ÿ:"Y",Ź:"Z",Ż:"Z",Ž:"Z",ź:"z",ż:"z",ž:"z",Ĳ:"IJ",ĳ:"ij",Œ:"Oe",œ:"oe",ŉ:"'n",ſ:"s"},wn=mn(bn);const yn=wn;var Sn=/[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,Cn="\\u0300-\\u036f",Rn="\\ufe20-\\ufe2f",_n="\\u20d0-\\u20ff",zn=Cn+Rn+_n,Pn="["+zn+"]",kn=RegExp(Pn,"g");function In(e){return e=De(e),e&&e.replace(Sn,yn).replace(kn,"")}var Nn=/[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;function Dn(e){return e.match(Nn)||[]}var En=/[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;function $n(e){return En.test(e)}var lt="\\ud800-\\udfff",An="\\u0300-\\u036f",Tn="\\ufe20-\\ufe2f",Vn="\\u20d0-\\u20ff",Mn=An+Tn+Vn,it="\\u2700-\\u27bf",ut="a-z\\xdf-\\xf6\\xf8-\\xff",On="\\xac\\xb1\\xd7\\xf7",Ln="\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf",jn="\\u2000-\\u206f",Un=" \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",ct="A-Z\\xc0-\\xd6\\xd8-\\xde",Bn="\\ufe0e\\ufe0f",dt=On+Ln+jn+Un,ft="['’]",Xe="["+dt+"]",Zn="["+Mn+"]",vt="\\d+",Wn="["+it+"]",xt="["+ut+"]",pt="[^"+lt+dt+vt+it+ut+ct+"]",Fn="\\ud83c[\\udffb-\\udfff]",Xn="(?:"+Zn+"|"+Fn+")",Yn="[^"+lt+"]",ht="(?:\\ud83c[\\udde6-\\uddff]){2}",gt="[\\ud800-\\udbff][\\udc00-\\udfff]",H="["+ct+"]",Hn="\\u200d",Ye="(?:"+xt+"|"+pt+")",Kn="(?:"+H+"|"+pt+")",He="(?:"+ft+"(?:d|ll|m|re|s|t|ve))?",Ke="(?:"+ft+"(?:D|LL|M|RE|S|T|VE))?",mt=Xn+"?",bt="["+Bn+"]?",qn="(?:"+Hn+"(?:"+[Yn,ht,gt].join("|")+")"+bt+mt+")*",Gn="\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])",Jn="\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])",Qn=bt+mt+qn,eo="(?:"+[Wn,ht,gt].join("|")+")"+Qn,to=RegExp([H+"?"+xt+"+"+He+"(?="+[Xe,H,"$"].join("|")+")",Kn+"+"+Ke+"(?="+[Xe,H+Ye,"$"].join("|")+")",H+"?"+Ye+"+"+He,H+"+"+Ke,Jn,Gn,vt,eo].join("|"),"g");function no(e){return e.match(to)||[]}function oo(e,n,a){return e=De(e),n=a?void 0:n,n===void 0?$n(e)?no(e):Dn(e):e.match(n)||[]}var ao="['’]",ro=RegExp(ao,"g");function so(e){return function(n){return gn(oo(In(n).replace(ro,"")),e,"")}}var lo=so(function(e,n,a){return n=n.toLowerCase(),e+(a?hn(n):n)});const qe=lo,io=e=>({dotSize:"8px",dotColor:"rgba(255, 255, 255, .3)",dotColorActive:"rgba(255, 255, 255, 1)",dotColorFocus:"rgba(255, 255, 255, .5)",dotLineWidth:"16px",dotLineWidthActive:"24px",arrowColor:"#eee"}),uo={name:"Carousel",common:Zt,self:io},co=uo;function fo(e){const{length:n}=e;return n>1&&(e.push(Ge(e[0],0,"append")),e.unshift(Ge(e[n-1],n-1,"prepend"))),e}function Ge(e,n,a){return tt(e,{key:`carousel-item-duplicate-${n}-${a}`})}function Je(e,n,a){return a?e===0?n-3:e===n-1?0:e-1:e}function Ie(e,n){return n?e+1:e}function vo(e,n,a){return e<0?null:e===0?a?n-1:null:e-1}function xo(e,n,a){return e>n-1?null:e===n-1?a?0:null:e+1}function po(e,n){return n&&e>3?e-2:e}function Qe(e){return window.TouchEvent&&e instanceof window.TouchEvent}function et(e,n){let{offsetWidth:a,offsetHeight:s}=e;if(n){const u=getComputedStyle(e);a=a-parseFloat(u.getPropertyValue("padding-left"))-parseFloat(u.getPropertyValue("padding-right")),s=s-parseFloat(u.getPropertyValue("padding-top"))-parseFloat(u.getPropertyValue("padding-bottom"))}return{width:a,height:s}}function ve(e,n,a){return e<n?n:e>a?a:e}function ho(e){if(e===void 0)return 0;if(typeof e=="number")return e;const n=/^((\d+)?\.?\d+?)(ms|s)?$/,a=e.match(n);if(a){const[,s,,u="ms"]=a;return Number(s)*(u==="ms"?1:1e3)}return 0}const wt=Yt("n-carousel-methods"),go=e=>{Wt(wt,e)},Ee=(e="unknown",n="component")=>{const a=Ft(wt);return a||Xt(e,`\`${n}\` must be placed inside \`n-carousel\`.`),a},mo={total:{type:Number,default:0},currentIndex:{type:Number,default:0},dotType:{type:String,default:"dot"},trigger:{type:String,default:"click"},keyboard:Boolean},bo=K({name:"CarouselDots",props:mo,setup(e){const{mergedClsPrefixRef:n}=pe(e),a=V([]),s=Ee();function u(m,v){switch(m.key){case"Enter":case" ":m.preventDefault(),s.to(v);return}e.keyboard&&x(m)}function h(m){e.trigger==="hover"&&s.to(m)}function C(m){e.trigger==="click"&&s.to(m)}function x(m){var v;if(m.shiftKey||m.altKey||m.ctrlKey||m.metaKey)return;const w=(v=document.activeElement)===null||v===void 0?void 0:v.nodeName.toLowerCase();if(w==="input"||w==="textarea")return;const{code:_}=m,j=_==="PageUp"||_==="ArrowUp",B=_==="PageDown"||_==="ArrowDown",R=_==="PageUp"||_==="ArrowRight",z=_==="PageDown"||_==="ArrowLeft",P=s.isVertical(),M=P?j:R,q=P?B:z;!M&&!q||(m.preventDefault(),M&&!s.isNextDisabled()?(s.next(),S(s.currentIndexRef.value)):q&&!s.isPrevDisabled()&&(s.prev(),S(s.currentIndexRef.value)))}function S(m){var v;(v=a.value[m])===null||v===void 0||v.focus()}return Ht(()=>a.value.length=0),{mergedClsPrefix:n,dotEls:a,handleKeydown:u,handleMouseenter:h,handleClick:C}},render(){const{mergedClsPrefix:e,dotEls:n}=this;return y("div",{class:[`${e}-carousel__dots`,`${e}-carousel__dots--${this.dotType}`],role:"tablist"},Kt(this.total,a=>{const s=a===this.currentIndex;return y("div",{"aria-selected":s,ref:u=>n.push(u),role:"button",tabindex:"0",class:[`${e}-carousel__dot`,s&&`${e}-carousel__dot--active`],key:a,onClick:()=>{this.handleClick(a)},onMouseenter:()=>{this.handleMouseenter(a)},onKeydown:u=>{this.handleKeydown(u,a)}})}))}}),wo=y("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},y("g",{fill:"none"},y("path",{d:"M10.26 3.2a.75.75 0 0 1 .04 1.06L6.773 8l3.527 3.74a.75.75 0 1 1-1.1 1.02l-4-4.25a.75.75 0 0 1 0-1.02l4-4.25a.75.75 0 0 1 1.06-.04z",fill:"currentColor"}))),yo=y("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},y("g",{fill:"none"},y("path",{d:"M5.74 3.2a.75.75 0 0 0-.04 1.06L9.227 8L5.7 11.74a.75.75 0 1 0 1.1 1.02l4-4.25a.75.75 0 0 0 0-1.02l-4-4.25a.75.75 0 0 0-1.06-.04z",fill:"currentColor"}))),So=K({name:"CarouselArrow",setup(e){const{mergedClsPrefixRef:n}=pe(e),{isVertical:a,isPrevDisabled:s,isNextDisabled:u,prev:h,next:C}=Ee();return{mergedClsPrefix:n,isVertical:a,isPrevDisabled:s,isNextDisabled:u,prev:h,next:C}},render(){const{mergedClsPrefix:e}=this;return y("div",{class:`${e}-carousel__arrow-group`},y("div",{class:[`${e}-carousel__arrow`,this.isPrevDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.prev},wo),y("div",{class:[`${e}-carousel__arrow`,this.isNextDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.next},yo))}}),xe="CarouselItem",Co=e=>{var n;return((n=e.type)===null||n===void 0?void 0:n.name)===xe},Ro=K({name:xe,setup(e){const{mergedClsPrefixRef:n}=pe(e),a=Ee(qe(xe),`n-${qe(xe)}`),s=V(),u=p(()=>{const{value:v}=s;return v?a.getSlideIndex(v):-1}),h=p(()=>a.isPrev(u.value)),C=p(()=>a.isNext(u.value)),x=p(()=>a.isActive(u.value)),S=p(()=>a.getSlideStyle(u.value));nt(()=>{a.addSlide(s.value)}),ot(()=>{a.removeSlide(s.value)});function m(v){const{value:w}=u;w!==void 0&&(a==null||a.onCarouselItemClick(w,v))}return{mergedClsPrefix:n,selfElRef:s,isPrev:h,isNext:C,isActive:x,index:u,style:S,handleClick:m}},render(){var e;const{$slots:n,mergedClsPrefix:a,isPrev:s,isNext:u,isActive:h,index:C,style:x}=this,S=[`${a}-carousel__slide`,{[`${a}-carousel__slide--current`]:h,[`${a}-carousel__slide--prev`]:s,[`${a}-carousel__slide--next`]:u}];return y("div",{ref:"selfElRef",class:S,role:"option",tabindex:"-1","data-index":C,"aria-hidden":!h,style:x,onClickCapture:this.handleClick},(e=n.default)===null||e===void 0?void 0:e.call(n,{isPrev:s,isNext:u,isActive:h,index:C}))}}),_o=qt("carousel",`
 position: relative;
 width: 100%;
 height: 100%;
 touch-action: pan-y;
 overflow: hidden;
`,[d("slides",`
 display: flex;
 width: 100%;
 height: 100%;
 transition-timing-function: var(--n-bezier);
 transition-property: transform;
 `,[d("slide",`
 flex-shrink: 0;
 position: relative;
 width: 100%;
 height: 100%;
 outline: none;
 overflow: hidden;
 `,[$("> img",`
 display: block;
 `)])]),d("dots",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `,[f("dot",[d("dot",`
 height: var(--n-dot-size);
 width: var(--n-dot-size);
 background-color: var(--n-dot-color);
 border-radius: 50%;
 cursor: pointer;
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[$("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),f("active",`
 background-color: var(--n-dot-color-active);
 `)])]),f("line",[d("dot",`
 border-radius: 9999px;
 width: var(--n-dot-line-width);
 height: 4px;
 background-color: var(--n-dot-color);
 cursor: pointer;
 transition:
 width .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[$("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),f("active",`
 width: var(--n-dot-line-width-active);
 background-color: var(--n-dot-color-active);
 `)])])]),d("arrow",`
 transition: background-color .3s var(--n-bezier);
 cursor: pointer;
 height: 28px;
 width: 28px;
 display: flex;
 align-items: center;
 justify-content: center;
 background-color: rgba(255, 255, 255, .2);
 color: var(--n-arrow-color);
 border-radius: 8px;
 user-select: none;
 -webkit-user-select: none;
 font-size: 18px;
 `,[$("svg",`
 height: 1em;
 width: 1em;
 `),$("&:hover",`
 background-color: rgba(255, 255, 255, .3);
 `)]),f("vertical",`
 touch-action: pan-x;
 `,[d("slides",`
 flex-direction: column;
 `),f("fade",[d("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%);
 `)]),f("card",[d("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%) translateZ(-400px);
 `,[f("current",`
 transform: translateY(-50%) translateZ(0);
 `),f("prev",`
 transform: translateY(-100%) translateZ(-200px);
 `),f("next",`
 transform: translateY(0%) translateZ(-200px);
 `)])])]),f("usercontrol",[d("slides",[$(">",[$("div",`
 position: absolute;
 top: 50%;
 left: 50%;
 width: 100%;
 height: 100%;
 transform: translate(-50%, -50%);
 `)])])]),f("left",[d("dots",`
 transform: translateY(-50%);
 top: 50%;
 left: 12px;
 flex-direction: column;
 `,[f("line",[d("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[f("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),d("dot",`
 margin: 4px 0;
 `)]),d("arrow-group",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `),f("vertical",[d("arrow",`
 transform: rotate(90deg);
 `)]),f("show-arrow",[f("bottom",[d("dots",`
 transform: translateX(0);
 bottom: 18px;
 left: 18px;
 `)]),f("top",[d("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),f("left",[d("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),f("right",[d("dots",`
 transform: translateX(0);
 top: 18px;
 right: 18px;
 `)])]),f("left",[d("arrow-group",`
 bottom: 12px;
 left: 12px;
 flex-direction: column;
 `,[$("> *:first-child",`
 margin-bottom: 12px;
 `)])]),f("right",[d("dots",`
 transform: translateY(-50%);
 top: 50%;
 right: 12px;
 flex-direction: column;
 `,[f("line",[d("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[f("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),d("dot",`
 margin: 4px 0;
 `),d("arrow-group",`
 bottom: 12px;
 right: 12px;
 flex-direction: column;
 `,[$("> *:first-child",`
 margin-bottom: 12px;
 `)])]),f("top",[d("dots",`
 transform: translateX(-50%);
 top: 12px;
 left: 50%;
 `,[f("line",[d("dot",`
 margin: 0 4px;
 `)])]),d("dot",`
 margin: 0 4px;
 `),d("arrow-group",`
 top: 12px;
 right: 12px;
 `,[$("> *:first-child",`
 margin-right: 12px;
 `)])]),f("bottom",[d("dots",`
 transform: translateX(-50%);
 bottom: 12px;
 left: 50%;
 `,[f("line",[d("dot",`
 margin: 0 4px;
 `)])]),d("dot",`
 margin: 0 4px;
 `),d("arrow-group",`
 bottom: 12px;
 right: 12px;
 `,[$("> *:first-child",`
 margin-right: 12px;
 `)])]),f("fade",[d("slide",`
 position: absolute;
 opacity: 0;
 transition-property: opacity;
 pointer-events: none;
 `,[f("current",`
 opacity: 1;
 pointer-events: auto;
 `)])]),f("card",[d("slides",`
 perspective: 1000px;
 `),d("slide",`
 position: absolute;
 left: 50%;
 opacity: 0;
 transform: translateX(-50%) translateZ(-400px);
 transition-property: opacity, transform;
 `,[f("current",`
 opacity: 1;
 transform: translateX(-50%) translateZ(0);
 z-index: 1;
 `),f("prev",`
 opacity: 0.4;
 transform: translateX(-100%) translateZ(-200px);
 `),f("next",`
 opacity: 0.4;
 transform: translateX(0%) translateZ(-200px);
 `)])])]),zo=["transitionDuration","transitionTimingFunction"],Po=Object.assign(Object.assign({},at.props),{defaultIndex:{type:Number,default:0},currentIndex:Number,showArrow:Boolean,dotType:{type:String,default:"dot"},dotPlacement:{type:String,default:"bottom"},slidesPerView:{type:[Number,String],default:1},spaceBetween:{type:Number,default:0},centeredSlides:Boolean,direction:{type:String,default:"horizontal"},autoplay:Boolean,interval:{type:Number,default:5e3},loop:{type:Boolean,default:!0},effect:{type:String,default:"slide"},showDots:{type:Boolean,default:!0},trigger:{type:String,default:"click"},transitionStyle:{type:Object,default:()=>({transitionDuration:"300ms"})},transitionProps:Object,draggable:Boolean,prevSlideStyle:[Object,String],nextSlideStyle:[Object,String],touchable:{type:Boolean,default:!0},mousewheel:Boolean,keyboard:Boolean,"onUpdate:currentIndex":Function,onUpdateCurrentIndex:Function});let Ne=!1;const ko=K({name:"Carousel",props:Po,setup(e){const{mergedClsPrefixRef:n,inlineThemeDisabled:a}=pe(e),s=V(null),u=V(null),h=V([]),C={value:[]},x=p(()=>e.direction==="vertical"),S=p(()=>x.value?"height":"width"),m=p(()=>x.value?"bottom":"right"),v=p(()=>e.effect==="slide"),w=p(()=>e.loop&&e.slidesPerView===1&&v.value),_=p(()=>e.effect==="custom"),j=p(()=>!v.value||e.centeredSlides?1:e.slidesPerView),B=p(()=>_.value?1:e.slidesPerView),R=p(()=>j.value==="auto"||e.slidesPerView==="auto"&&e.centeredSlides),z=V({width:0,height:0}),P=p(()=>{const{value:t}=h;if(!t.length)return[];const{value:o}=R;if(o)return t.map(b=>et(b));const{value:r}=B,{value:i}=z,{value:c}=S;let l=i[c];if(r!=="auto"){const{spaceBetween:b}=e,k=l-(r-1)*b,de=1/Math.max(1,r);l=k*de}const g=Object.assign(Object.assign({},i),{[c]:l});return t.map(()=>g)}),M=p(()=>{const{value:t}=P;if(!t.length)return[];const{centeredSlides:o,spaceBetween:r}=e,{value:i}=S,{[i]:c}=z.value;let l=0;return t.map(({[i]:g})=>{let b=l;return o&&(b+=(g-c)/2),l+=g+r,b})}),q=V(!1),ge=p(()=>{const{transitionStyle:t}=e;return t?Be(t,zo):{}}),me=p(()=>_.value?0:ho(ge.value.transitionDuration)),$e=p(()=>{const{value:t}=h;if(!t.length)return[];const o=!(R.value||B.value===1),r=g=>{if(o){const{value:b}=S;return{[b]:`${P.value[g][b]}px`}}};if(_.value)return t.map((g,b)=>r(b));const{effect:i,spaceBetween:c}=e,{value:l}=m;return t.reduce((g,b,k)=>{const de=Object.assign(Object.assign({},r(k)),{[`margin-${l}`]:`${c}px`});return g.push(de),q.value&&(i==="fade"||i==="card")&&Object.assign(de,ge.value),g},[])}),I=p(()=>{const{value:t}=j,{length:o}=h.value;if(t!=="auto")return Math.max(o-t,0)+1;{const{value:r}=P,{length:i}=r;if(!i)return o;const{value:c}=M,{value:l}=S,g=z.value[l];let b=r[r.length-1][l],k=i;for(;k>1&&b<g;)k--,b+=c[k]-c[k-1];return ve(k+1,1,i)}}),ne=p(()=>po(I.value,w.value)),yt=Ie(e.defaultIndex,w.value),be=V(Je(yt,I.value,w.value)),N=Gt(Jt(e,"currentIndex"),be),D=p(()=>Ie(N.value,w.value));function G(t){var o,r;t=ve(t,0,I.value-1);const i=Je(t,I.value,w.value),{value:c}=N;i!==N.value&&(be.value=i,(o=e["onUpdate:currentIndex"])===null||o===void 0||o.call(e,i,c),(r=e.onUpdateCurrentIndex)===null||r===void 0||r.call(e,i,c))}function oe(t=D.value){return vo(t,I.value,e.loop)}function ae(t=D.value){return xo(t,I.value,e.loop)}function St(t){const o=W(t);return o!==null&&oe()===o}function Ct(t){const o=W(t);return o!==null&&ae()===o}function Ae(t){return D.value===W(t)}function Rt(t){return N.value===t}function Te(){return oe()===null}function Ve(){return ae()===null}function we(t){const o=ve(Ie(t,w.value),0,I.value);(t!==N.value||o!==D.value)&&G(o)}function ye(){const t=oe();t!==null&&G(t)}function re(){const t=ae();t!==null&&G(t)}function _t(){(!E||!w.value)&&ye()}function zt(){(!E||!w.value)&&re()}let E=!1,Z=0;const Se=V({});function se(t,o=0){Se.value=Object.assign({},ge.value,{transform:x.value?`translateY(${-t}px)`:`translateX(${-t}px)`,transitionDuration:`${o}ms`})}function J(t=0){v.value?Ce(D.value,t):Z!==0&&(!E&&t>0&&(E=!0),se(Z=0,t))}function Ce(t,o){const r=Me(t);r!==Z&&o>0&&(E=!0),Z=Me(D.value),se(r,o)}function Me(t){let o;return t>=I.value-1?o=Oe():o=M.value[t]||0,o}function Oe(){if(j.value==="auto"){const{value:t}=S,{[t]:o}=z.value,{value:r}=M,i=r[r.length-1];let c;if(i===void 0)c=o;else{const{value:l}=P;c=i+l[l.length-1][t]}return c-o}else{const{value:t}=M;return t[I.value-1]||0}}const Q={currentIndexRef:N,to:we,prev:_t,next:zt,isVertical:()=>x.value,isHorizontal:()=>!x.value,isPrev:St,isNext:Ct,isActive:Ae,isPrevDisabled:Te,isNextDisabled:Ve,getSlideIndex:W,getSlideStyle:It,addSlide:Pt,removeSlide:kt,onCarouselItemClick:Nt};go(Q);function Pt(t){t&&h.value.push(t)}function kt(t){if(!t)return;const o=W(t);o!==-1&&h.value.splice(o,1)}function W(t){return typeof t=="number"?t:t?h.value.indexOf(t):-1}function It(t){const o=W(t);if(o!==-1){const r=[$e.value[o]],i=Q.isPrev(o),c=Q.isNext(o);return i&&r.push(e.prevSlideStyle||""),c&&r.push(e.nextSlideStyle||""),sn(r)}}function Nt(t,o){let r=!E&&!ue&&!Pe;e.effect==="card"&&r&&!Ae(t)&&(we(t),r=!1),r||(o.preventDefault(),o.stopPropagation())}let le=null;function ie(){le&&(clearInterval(le),le=null)}function F(){ie(),!e.autoplay||ne.value<2||(le=window.setInterval(re,e.interval))}let Re=0,_e=0,O=0,ze=0,ue=!1,Pe=!1;function Le(t){var o;if(Ne||!(!((o=u.value)===null||o===void 0)&&o.contains(ln(t))))return;Ne=!0,ue=!0,Pe=!1,ze=Date.now(),ie(),t.type!=="touchstart"&&!t.target.isContentEditable&&t.preventDefault();const r=Qe(t)?t.touches[0]:t;x.value?_e=r.clientY:Re=r.clientX,e.touchable&&(ee("touchmove",document,ce,{passive:!0}),ee("touchend",document,X),ee("touchcancel",document,X)),e.draggable&&(ee("mousemove",document,ce),ee("mouseup",document,X))}function ce(t){const{value:o}=x,{value:r}=S,i=Qe(t)?t.touches[0]:t,c=o?i.clientY-_e:i.clientX-Re,l=z.value[r];O=ve(c,-l,l),t.cancelable&&t.preventDefault(),v.value&&se(Z-O,0)}function X(){const{value:t}=D;let o=t;if(!E&&O!==0&&v.value){const r=Z-O,i=[...M.value.slice(0,I.value-1),Oe()];let c=null;for(let l=0;l<i.length;l++){const g=Math.abs(i[l]-r);if(c!==null&&c<g)break;c=g,o=l}}if(o===t){const r=Date.now()-ze,{value:i}=S,c=z.value[i];O>c/2||O/r>.4?o=oe(t):(O<-c/2||O/r<-.4)&&(o=ae(t))}o!==null&&o!==t?(Pe=!0,G(o),Ze(()=>{(!w.value||be.value!==N.value)&&J(me.value)})):J(me.value),je(),F()}function je(){ue&&(Ne=!1),ue=!1,Re=0,_e=0,O=0,ze=0,te("touchmove",document,ce),te("touchend",document,X),te("touchcancel",document,X),te("mousemove",document,ce),te("mouseup",document,X)}function Dt(){if(v.value&&E){const{value:t}=D;Ce(t,0)}else F();v.value&&(Se.value.transitionDuration="0ms"),E=!1}function Et(t){if(t.preventDefault(),E)return;let{deltaX:o,deltaY:r}=t;t.shiftKey&&!o&&(o=r);const i=-1,c=1,l=(o||r)>0?c:i;let g=0,b=0;x.value?b=l:g=l;const k=10;(b*r>=k||g*o>=k)&&(l===c&&!Ve()?re():l===i&&!Te()&&ye())}function $t(){z.value=et(s.value,!0),F()}function At(){var t,o;R.value&&((o=(t=P.effect).scheduler)===null||o===void 0||o.call(t),P.effect.run())}function Tt(){e.autoplay&&ie()}function Vt(){e.autoplay&&F()}nt(()=>{Qt(F),requestAnimationFrame(()=>q.value=!0)}),ot(()=>{je(),ie()}),en(()=>{const{value:t}=h,{value:o}=C,r=new Map,i=l=>r.has(l)?r.get(l):-1;let c=!1;for(let l=0;l<t.length;l++){const g=o.findIndex(b=>b.el===t[l]);g!==l&&(c=!0),r.set(t[l],g)}c&&t.sort((l,g)=>i(l)-i(g))}),fe(D,(t,o)=>{if(t!==o)if(F(),v.value){if(w.value&&ne.value>2){const{value:r}=I;t===r-2&&o===1?t=0:t===1&&o===r-2&&(t=r-1)}Ce(t,me.value)}else J()},{immediate:!0}),fe([w,j],()=>void Ze(()=>{G(D.value)})),fe(M,()=>{v.value&&J()},{deep:!0}),fe(v,t=>{t?J():(E=!1,se(Z=0))});const Mt=p(()=>({onTouchstartPassive:e.touchable?Le:void 0,onMousedown:e.draggable?Le:void 0,onWheel:e.mousewheel?Et:void 0})),Ot=p(()=>Object.assign(Object.assign({},Be(Q,["to","prev","next","isPrevDisabled","isNextDisabled"])),{total:ne.value,currentIndex:N.value})),Lt=p(()=>({total:ne.value,currentIndex:N.value,to:Q.to})),jt={getCurrentIndex:()=>N.value,to:we,prev:ye,next:re},Ut=at("Carousel","-carousel",_o,co,e,n),Ue=p(()=>{const{common:{cubicBezierEaseInOut:t},self:{dotSize:o,dotColor:r,dotColorActive:i,dotColorFocus:c,dotLineWidth:l,dotLineWidthActive:g,arrowColor:b}}=Ut.value;return{"--n-bezier":t,"--n-dot-color":r,"--n-dot-color-focus":c,"--n-dot-color-active":i,"--n-dot-size":o,"--n-dot-line-width":l,"--n-dot-line-width-active":g,"--n-arrow-color":b}}),Y=a?tn("carousel",void 0,Ue,e):void 0;return Object.assign(Object.assign({mergedClsPrefix:n,selfElRef:s,slidesElRef:u,slideVNodes:C,duplicatedable:w,userWantsControl:_,autoSlideSize:R,displayIndex:N,realIndex:D,slideStyles:$e,translateStyle:Se,slidesControlListeners:Mt,handleTransitionEnd:Dt,handleResize:$t,handleSlideResize:At,handleMouseenter:Tt,handleMouseleave:Vt,isActive:Rt,arrowSlotProps:Ot,dotSlotProps:Lt},jt),{cssVars:a?void 0:Ue,themeClass:Y==null?void 0:Y.themeClass,onRender:Y==null?void 0:Y.onRender})},render(){var e;const{mergedClsPrefix:n,showArrow:a,userWantsControl:s,slideStyles:u,dotType:h,dotPlacement:C,slidesControlListeners:x,transitionProps:S={},arrowSlotProps:m,dotSlotProps:v,$slots:{default:w,dots:_,arrow:j}}=this,B=w&&nn(w())||[];let R=Io(B);return R.length||(R=B.map(z=>y(Ro,null,{default:()=>tt(z)}))),this.duplicatedable&&(R=fo(R)),this.slideVNodes.value=R,this.autoSlideSize&&(R=R.map(z=>y(We,{onResize:this.handleSlideResize},{default:()=>z}))),(e=this.onRender)===null||e===void 0||e.call(this),y("div",Object.assign({ref:"selfElRef",class:[this.themeClass,`${n}-carousel`,this.direction==="vertical"&&`${n}-carousel--vertical`,this.showArrow&&`${n}-carousel--show-arrow`,`${n}-carousel--${C}`,`${n}-carousel--${this.direction}`,`${n}-carousel--${this.effect}`,s&&`${n}-carousel--usercontrol`],style:this.cssVars},x,{onMouseenter:this.handleMouseenter,onMouseleave:this.handleMouseleave}),y(We,{onResize:this.handleResize},{default:()=>y("div",{ref:"slidesElRef",class:`${n}-carousel__slides`,role:"listbox",style:this.translateStyle,onTransitionend:this.handleTransitionEnd},s?R.map((z,P)=>y("div",{style:u[P],key:P},on(y(rn,Object.assign({},S),{default:()=>z}),[[an,this.isActive(P)]]))):R)}),this.showDots&&v.total>1&&Fe(_,v,()=>[y(bo,{key:h+C,total:v.total,currentIndex:v.currentIndex,dotType:h,trigger:this.trigger,keyboard:this.keyboard})]),a&&Fe(j,m,()=>[y(So,null)]))}});function Io(e){return e.reduce((n,a)=>(Co(a)&&n.push(a),n),[])}const No="/img/login-bg/1.avif",Do="/img/login-bg/2.avif",Eo="/img/login-bg/3.avif",$o=K({__name:"login-form",emits:["register"],setup(e,{emit:n}){const a=V({phone:"",password:""}),s=un(),u=async()=>{try{await s.value.validate();const C=await pn(a.value),x=dn();x.username=`用户${a.value.phone}`,x.login(C),fn()}catch{}},h={phone:[{required:!0,message:"请输入手机号码"},{message:"手机号码不合法",trigger:"blur",validator:(C,x)=>x!==""&&!/^\d{11}$/.test(x)?new Error("手机号码必须是 11 位数字"):!0}],password:[{required:!0,message:"请输入密码"},{min:6,max:20,message:"长度在 6 到 20 个字符",trigger:"blur"}]};return(C,x)=>(rt(),st(cn,null,[A(T(U.NButton),{class:"w-full mt-4",onClick:x[0]||(x[0]=()=>n("register"))},{default:L(()=>[ke("注册账号")]),_:1}),A(T(U.NDivider),{class:"text-[#4c566a] opacity-90"},{default:L(()=>[ke("或者")]),_:1}),A(T(U.NForm),{ref_key:"formRef",ref:s,"label-width":80,model:a.value,rules:h},{default:L(()=>[A(T(U.NFormItem),{label:"手机号码",path:"phone"},{default:L(()=>[A(T(U.NInput),{value:a.value.phone,"onUpdate:value":x[1]||(x[1]=S=>a.value.phone=S),placeholder:"请输入手机号码"},null,8,["value"])]),_:1}),A(T(U.NFormItem),{label:"密码",path:"password"},{default:L(()=>[A(T(U.NInput),{value:a.value.password,"onUpdate:value":x[2]||(x[2]=S=>a.value.password=S),placeholder:"请输入密码",type:"password","show-password-on":"click"},null,8,["value"])]),_:1}),A(T(U.NButton),{type:"primary",class:"w-full mt-4",onClick:u},{default:L(()=>[ke("登录")]),_:1})]),_:1},8,["model"])],64))}}),Ao={class:"w-full h-full flex justify-end items-center"},To=he("img",{src:No,class:"w-full h-full"},null,-1),Vo=he("img",{src:Do,class:"w-full h-full"},null,-1),Mo=he("img",{src:Eo,class:"w-full h-full"},null,-1),Oo=he("div",{class:"flex justify-center"},"欢迎来到个性化学习与职业规划系统",-1),Bo=K({__name:"login-view",setup(e){return(n,a)=>(rt(),st("div",Ao,[A(T(ko),{autoplay:!0,"show-dots":!1,class:"absolute -z-10"},{default:L(()=>[To,Vo,Mo]),_:1}),A(T(xn),{class:"w-fit h-fit m-12 shadow-2xl","header-style":"font-size: 1rem; line-height: 1.75rem;"},{header:L(()=>[Oo]),default:L(()=>[A($o,{onRegister:T(vn)},null,8,["onRegister"])]),_:1})]))}});export{Bo as default};
